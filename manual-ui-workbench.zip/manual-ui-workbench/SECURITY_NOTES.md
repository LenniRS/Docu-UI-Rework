# Security Notes — Manual UI Workbench

This workspace is a **sanitized** copy of the UI source for development purposes.
It intentionally contains **no** company-restricted content.

## What was excluded

The following were **not** copied from the source repository:

- `data/`, `data/projects/` — real project data, transcripts, generated manuals
- `docs/` — norms, style guides, editorial handbooks, internal documentation
- `backend/` — backend code, prompts, council logic, SMM pipeline
- `frontend/public/gateway-config.json` — contained internal gateway URLs
  (`plm-ai-gateway.cloud2.rsint.net`); replaced with a sanitized mock
- `frontend/public/rs_logo.jpg`, `frontend/src/assets/rs_logo.jpg` — corporate
  R&S logo; replaced with a generic icon
- `frontend/node_modules/`, `.npm-cache/`, `npm-offline-*.tgz` — build artifacts
- `frontend/Dockerfile*`, `nginx.conf` — container config (not UI source)
- `frontend/.npmrc` — contained the corporate npm registry URL
  (`npm.packages.rsint.net`); intentionally not copied

## What was sanitized

- `frontend/src/components/Sidebar.tsx` — corporate logo import replaced with a
  generic `FileText` icon
- `frontend/index.html` — favicon reference to the corporate logo removed
- `frontend/src/components/SettingsPage.tsx` — internal gateway URLs
  (`plm-ai-gateway.cloud2.rsint.net`, `llm-gateway-qual.cloud.rsint.net`)
  replaced with placeholder `.invalid` domains
- `frontend/src/types.ts` — internal gateway URL in default settings replaced
  with a placeholder `.invalid` domain
- `frontend/package-lock.json` — corporate npm registry URL
  (`npm.packages.rsint.net`) replaced with a placeholder registry host
- `mock-api/fixtures/gateway-config.json` — internal gateway URLs replaced with
  placeholder `.invalid` domains

## Intentional term references (not restricted content)

The scan flags a few terms that are **not** restricted content but appear in
functional UI code:

- `frontend/src/lib/api.ts` — `"RS_Docu"` is the app's own name used as the
  export filename base. Not confidential.
- `frontend/src/lib/writers.ts` — references to `S1000D`, `Redaktionshandbuch`,
  and `ASD-STE` are the **names** of documentation standards used in the writer
  profile prompts (writing-style instructions to the LLM). They are not norm
  texts or restricted content. This is core UI functionality.
- `mock-api/server.js` — the word "restricted" appears in a descriptive comment
  ("no company-restricted content"). Not actual restricted content.

## Rules for this workspace

1. **Never** copy real project data, transcripts, manuals, norms, style guides,
   editorial handbooks, screenshots, or customer data into this workspace.
2. **Never** commit or push this workspace to a remote repository.
3. **Never** upload any file from this workspace to an external tool.
4. If you are unsure whether a file contains restricted content, **do not copy it**.
5. Run the scan script before adding any new file:
   ```bash
   node scripts/scan.js
   ```

## npm registry note

The original project requires the corporate npm registry
(`npm.packages.rsint.net`) to install dependencies. This workspace does **not**
configure that registry. To build here you must either:

- be inside the corporate network and configure the corporate registry, or
- use a local/offline npm cache.

No credentials or registry URLs are stored in this workspace.
