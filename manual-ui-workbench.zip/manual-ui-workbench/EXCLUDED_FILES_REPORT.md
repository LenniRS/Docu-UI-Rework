# Excluded Files Report — Manual UI Workbench

This report documents what was intentionally **not** copied from the source
repository into the sanitized UI workspace, and why.

## Excluded directories

| Path | Reason |
|---|---|
| `data/`, `data/projects/` | Real project data, transcripts, generated manuals, personal data |
| `docs/` | Norms, style guides, editorial handbooks, internal documentation |
| `backend/` | Backend code, prompts, council logic, SMM pipeline, tests |
| `frontend/node_modules/` | Build artifacts (recreated via `npm install`) |
| `frontend/.npm-cache/` | Build cache |
| `frontend/public/` | Contained `gateway-config.json` (internal URLs) and `rs_logo.jpg` (corporate logo) |

## Excluded files

| File | Reason |
|---|---|
| `frontend/public/gateway-config.json` | Contained internal gateway URLs (`plm-ai-gateway.cloud2.rsint.net`). Replaced with sanitized mock. |
| `frontend/public/rs_logo.jpg` | Corporate R&S logo. Replaced with generic icon. |
| `frontend/src/assets/rs_logo.jpg` | Corporate R&S logo. Replaced with generic icon. |
| `frontend/.npmrc` | Contained corporate npm registry URL (`npm.packages.rsint.net`). Not copied. |
| `frontend/Dockerfile`, `Dockerfile.bak` | Container build config, not UI source. |
| `frontend/nginx.conf` | Container config, not UI source. |
| `frontend/npm-offline-node20-linux-x64.tgz` | Offline npm binary artifact. |
| `frontend/tsconfig.tsbuildinfo` | Build cache. |

## Excluded by type (never copied)

- `*.pdf`, `*.docx`, `*.doc`, `*.xlsx`, `*.xls`, `*.pptx`, `*.ppt`
- `*.zip`, `*.7z`, `*.rar`
- `*.mp4`, `*.mov`, `*.avi`, `*.mkv`
- `*.wav`, `*.mp3`
- `*.png`, `*.jpg`, `*.jpeg`, `*.tiff`, `*.bmp` (except UI-owned generic assets — none were included)

## Excluded content categories

- Real project names, product names, customer names
- Real transcript content
- Real screenshots
- Norm texts (S1000D, EAGLE, DIN, ASD-STE, etc.)
- Internal R&S data
- Style guides, editorial handbooks, redaction manuals
- Generated manuals, knowledge-base exports
