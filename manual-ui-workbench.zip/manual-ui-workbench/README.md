# Manual UI Workbench

Sanitized, self-contained UI workspace for high-quality UI rework of the RS Docu
frontend. Contains **no** company-restricted content — no norms, no style guides,
no editorial handbooks, no transcripts, no project data, no customer data, no
generated manuals, no real screenshots.

## Purpose

Develop, build, and test the React/TypeScript UI in isolation against a mock API,
without touching the company-restricted repository.

## Structure

```
manual-ui-workbench/
  frontend/          Sanitized copy of the UI source (React 19 + Vite + TipTap)
  mock-api/          Dependency-free Node mock server + synthetic fixtures
  docs/              This documentation
  scripts/           Helper scripts (sensitive-content scan, setup)
  README.md
  SECURITY_NOTES.md
  INCLUDED_FILES_MANIFEST.json
  EXCLUDED_FILES_REPORT.md
```

## Quick start

### 1. Start the mock API

```bash
node mock-api/server.js
# Mock API listening on http://127.0.0.1:8000
```

### 2. Install frontend dependencies

```bash
cd frontend
npm install
```

> Note: The original project uses a corporate npm registry. In this sanitized
> workspace the registry is intentionally **not** configured. If you are inside
> the corporate network, you may need to point npm at the corporate registry to
> install dependencies. See `SECURITY_NOTES.md`.

### 3. Run the dev server

```bash
cd frontend
npm run dev
# Vite dev server on http://127.0.0.1:5173, proxies /api to the mock server
```

### 4. Build

```bash
cd frontend
npm run build
```

## UI work targets

- **"Übernehmen" button** — verify and fix the apply logic (CouncilPanel / Workspace).
- **Layout / scroll** — ensure no content is clipped; verify at zoom 125 % and 150 %.
- **SMM areas** — SMM status, Gate Report, Open Issues, export profile selection,
  review vs. customer export, blocked exports, SMM JSON view, manual preview.

## Security

See `SECURITY_NOTES.md` for what was excluded and why. Run the scan script before
adding any new file:

```bash
node scripts/scan.js
```
