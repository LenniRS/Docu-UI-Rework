# Demo Installation Manual

## Status

Dieses Dokument ist ein Review-Entwurf.

## Procedure

1. Connect the demo cable to the demo device.

   Check: The connector is fully seated.

2. Power on the demo device.

   Check: The status LED is lit.

## Open Issues

| ID | Severity | Issue |
|---|---|---|
| issue-0001 | blocking | Risk assessment missing |
| issue-0002 | medium | Verification method missing |
