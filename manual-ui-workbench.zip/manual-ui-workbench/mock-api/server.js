/**
 * Mock API server for the sanitized UI workbench.
 *
 * Serves synthetic fixtures so the UI can be developed and tested without any
 * real backend, project data, or company-restricted content.
 *
 * No external dependencies — run with plain Node.js:
 *   node mock-api/server.js
 *
 * The Vite dev server proxies `/api` to this server (see frontend/vite.config.ts).
 */
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.MOCK_PORT || 8000;
const FIXTURES = path.join(__dirname, "fixtures");

function readJson(name) {
  return JSON.parse(fs.readFileSync(path.join(FIXTURES, name), "utf8"));
}

function readText(name) {
  return fs.readFileSync(path.join(FIXTURES, name), "utf8");
}

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(payload),
  });
  res.end(payload);
}

function sendText(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "text/plain; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        resolve({});
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;

  // --- Static sanitized gateway config (served at root, like the real app) ---
  if (p === "/gateway-config.json") {
    return sendJson(res, 200, readJson("gateway-config.json"));
  }

  // --- Config ---
  if (p === "/api/config") {
    return sendJson(res, 200, {
      parentDir: "mock-projects",
      defaultParentDir: "mock-projects",
      whisperUrl: "http://127.0.0.1:8081",
      llmBaseUrl: "http://127.0.0.1:8000",
      endpointType: "customendpoint",
    });
  }

  // --- Projects ---
  if (p === "/api/projects" && req.method === "GET") {
    return sendJson(res, 200, {
      parentDir: "mock-projects",
      reachable: true,
      projects: ["Demo", "Introduction"],
    });
  }

  // --- Project detail ---
  const projectMatch = p.match(/^\/api\/projects\/([^/]+)$/);
  if (projectMatch && req.method === "GET") {
    const name = decodeURIComponent(projectMatch[1]);
    return sendJson(res, 200, {
      name,
      path: `mock-projects/${name}`,
      title: name,
      outputName: name,
      hasVideo: false,
      videoName: null,
      manual: readText("manual-preview.md"),
      transcript: "Mock transcript for UI development.",
      files: [],
      timestamps: {},
    });
  }

  // --- SMM summary ---
  const smmMatch = p.match(/^\/api\/projects\/([^/]+)\/smm$/);
  if (smmMatch && req.method === "GET") {
    return sendJson(res, 200, readJson("smm-summary.json"));
  }

  // --- Gate report ---
  const gateMatch = p.match(/^\/api\/projects\/([^/]+)\/gate-report$/);
  if (gateMatch && req.method === "GET") {
    const report = readJson("gate-report.json");
    const summary = {
      total: report.gates.length,
      blocked: report.gates.filter((g) => g.status === "blocked").length,
      warnings: report.gates.filter((g) => g.status === "warning").length,
      passed: report.gates.filter((g) => g.status === "passed").length,
      status: report.overallStatus,
      blockedGates: report.gates.filter((g) => g.status === "blocked").map((g) => g.gateId),
      warningGates: report.gates.filter((g) => g.status === "warning").map((g) => g.gateId),
    };
    return sendJson(res, 200, { gateReport: report.gates, summary });
  }

  // --- Open issues ---
  if (p === "/api/open-issues") {
    return sendJson(res, 200, readJson("open-issues.json"));
  }

  // --- LLM models (from sanitized gateway config) ---
  if (p === "/api/llm/models") {
    const config = readJson("gateway-config.json");
    const models = [];
    for (const vendor of config) {
      if (vendor.models) models.push(...vendor.models);
    }
    return sendJson(res, 200, { models, url: "http://127.0.0.1:8000" });
  }

  // --- Health ---
  if (p === "/api/health/ffmpeg") {
    return sendJson(res, 200, { available: true, version: "mock" });
  }
  if (p === "/api/health/whisper") {
    return sendJson(res, 200, { available: true });
  }
  if (p === "/api/health/llm") {
    return sendJson(res, 200, { available: true });
  }

  // --- Fallback for unknown /api routes: return a generic 404 JSON ---
  if (p.startsWith("/api/")) {
    return sendJson(res, 404, { detail: `Mock endpoint not implemented: ${p}` });
  }

  return sendText(res, 404, "Not found");
});

server.listen(PORT, () => {
  console.log(`Mock API listening on http://127.0.0.1:${PORT}`);
  console.log(`Fixtures: ${FIXTURES}`);
});
