import { useEffect, useState } from "react";
import Modal from "./Modal";
import type { Writer } from "../types";
import {
  addWriter,
  canDeleteWriter,
  deleteWriter,
  duplicateWriter,
  MANUAL_WRITER_ID,
  resolveWriterId,
} from "../lib/writers";

type Props = {
  writers: Writer[];
  lastWriterId: string;
  onChange: (writers: Writer[]) => void;
};

export default function WritersPanel({ writers, lastWriterId, onChange }: Props) {
  const [selectedId, setSelectedId] = useState(() => {
    const resolved = resolveWriterId(writers, lastWriterId);
    return resolved === MANUAL_WRITER_ID ? (writers[0]?.id ?? "") : resolved;
  });
  const [pendingDelete, setPendingDelete] = useState(false);

  useEffect(() => {
    if (!writers.some((w) => w.id === selectedId)) {
      setSelectedId(writers[0]?.id ?? "");
    }
  }, [writers, selectedId]);

  const selected = writers.find((w) => w.id === selectedId) ?? writers[0];
  const deleteAllowed = canDeleteWriter(writers);

  function patchSelected(partial: Partial<Writer>) {
    if (!selected) return;
    onChange(writers.map((w) => (w.id === selected.id ? { ...w, ...partial } : w)));
  }

  function handleAdd() {
    const next = addWriter(writers);
    onChange(next);
    const added = next[next.length - 1];
    if (added) setSelectedId(added.id);
  }

  function handleDuplicate() {
    if (!selected) return;
    const next = duplicateWriter(writers, selected.id);
    onChange(next);
    const added = next[next.length - 1];
    if (added) setSelectedId(added.id);
  }

  function handleDelete() {
    if (!selected || !deleteAllowed) return;
    const next = deleteWriter(writers, selected.id);
    onChange(next);
    setPendingDelete(false);
    setSelectedId(next[0]?.id ?? "");
  }

  return (
    <div className="writers-panel">
      <div className="writers-list">
        <div className="writers-list-items">
          {writers.map((writer) => (
            <button
              key={writer.id}
              type="button"
              className={`writer-item ${writer.id === selected?.id ? "active" : ""}`}
              onClick={() => setSelectedId(writer.id)}
            >
              {writer.name.trim() || "Untitled"}
            </button>
          ))}
        </div>
        <div className="writers-list-actions">
          <button className="btn ghost" type="button" onClick={handleAdd}>
            Add
          </button>
          <button className="btn ghost" type="button" onClick={handleDuplicate} disabled={!selected}>
            Duplicate
          </button>
          <button
            className="btn ghost"
            type="button"
            onClick={() => setPendingDelete(true)}
            disabled={!deleteAllowed}
            title={deleteAllowed ? "Delete writer" : "At least one writer is required"}
          >
            Delete
          </button>
        </div>
      </div>
      <div className="writers-detail">
        {selected ? (
          <>
            <div className="field">
              <label>Name</label>
              <input value={selected.name} onChange={(e) => patchSelected({ name: e.target.value })} />
            </div>
            <div className="field writer-prompt">
              <label>Style prompt</label>
              <textarea
                value={selected.prompt}
                onChange={(e) => patchSelected({ prompt: e.target.value })}
              />
            </div>
            <p className="muted">
              Pipeline rules (images, timestamps, glossary) are applied by the app and are not in this prompt.
            </p>
          </>
        ) : (
          <p className="muted">Add a writer to get started.</p>
        )}
      </div>
      {pendingDelete && selected && (
        <Modal
          title="Delete writer"
          onClose={() => setPendingDelete(false)}
          onConfirm={handleDelete}
          confirmLabel="Delete"
          danger
        >
          <p>
            Delete <strong>{selected.name.trim() || "Untitled"}</strong>? This cannot be undone.
          </p>
        </Modal>
      )}
    </div>
  );
}
