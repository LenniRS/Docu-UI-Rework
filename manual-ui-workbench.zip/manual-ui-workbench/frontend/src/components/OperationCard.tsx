import { Check, Loader2, RotateCcw, X } from "lucide-react";
import type { OperationState } from "../lib/operations";
import { chatStatusText } from "../lib/operations";

type Props = {
  operation: OperationState;
  /** Whether the last applied change can be undone. */
  canUndo?: boolean;
  /** Undo the last applied change. */
  onUndo?: () => void;
  /** Retry a failed operation. */
  onRetry?: () => void;
};

/**
 * Structured operation card shown in the chat thread while an AI edit runs.
 * Replaces the generic "schreibt…" bubble for edit operations and never shows
 * raw JSON — only a clean, app-generated status.
 */
export default function OperationCard({ operation, canUndo = false, onUndo, onRetry }: Props) {
  const target =
    operation.target?.type === "section"
      ? operation.target.sectionNumber
        ? `Section ${operation.target.sectionNumber}`
        : operation.target.heading || "Abschnitt"
      : "Manual";

  const actionLabel =
    operation.step === "generating_edit"
      ? "Section neu schreiben"
      : operation.step === "resolving_target"
        ? "Zielabschnitt suchen"
        : operation.step === "validating_edit"
          ? "Änderung prüfen"
          : operation.step === "applying_edit"
            ? "Änderung anwenden"
            : operation.step === "saving"
              ? "Speichern"
              : "KI-Änderung";

  return (
    <div className={`operation-card ${operation.status}`} role="status" aria-live="polite">
      <div className="operation-card-head">
        {operation.status === "running" && <Loader2 size={14} className="spin" aria-hidden />}
        {operation.status === "success" && <Check size={14} aria-hidden />}
        {operation.status === "error" && <X size={14} aria-hidden />}
        <span className="operation-card-title">
          {operation.status === "success"
            ? "Änderung übernommen"
            : operation.status === "error"
              ? "Änderung fehlgeschlagen"
              : "Änderung läuft"}
        </span>
      </div>

      <div className="operation-card-body">
        <div className="operation-card-row">
          <span className="operation-card-key">Ziel</span>
          <span className="operation-card-value">{target}</span>
        </div>
        <div className="operation-card-row">
          <span className="operation-card-key">Aktion</span>
          <span className="operation-card-value">{actionLabel}</span>
        </div>
        <div className="operation-card-row">
          <span className="operation-card-key">Status</span>
          <span className="operation-card-value">{chatStatusText(operation)}</span>
        </div>
        {operation.status === "error" && operation.error && (
          <div className="operation-card-row">
            <span className="operation-card-key">Grund</span>
            <span className="operation-card-value operation-card-error">{operation.error}</span>
          </div>
        )}
      </div>

      {(operation.status === "success" && canUndo && onUndo) ||
      (operation.status === "error" && onRetry) ? (
        <div className="operation-card-actions">
          {operation.status === "success" && canUndo && onUndo && (
            <button type="button" className="btn ghost" onClick={onUndo}>
              <RotateCcw size={14} />
              Undo
            </button>
          )}
          {operation.status === "error" && onRetry && (
            <button type="button" className="btn ghost" onClick={onRetry}>
              Erneut versuchen
            </button>
          )}
        </div>
      ) : null}
    </div>
  );
}
