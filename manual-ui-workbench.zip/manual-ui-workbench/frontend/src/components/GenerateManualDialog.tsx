import { useState } from "react";
import type { AppSettings, GatewayModel, Writer } from "../types";
import { MANUAL_WRITER_ID, resolveWriterId } from "../lib/writers";
import { getSystemPrompt } from "../lib/api";

type Props = {
  writers: Writer[];
  lastWriterId: string;
  hasTranscript: boolean;
  settings: AppSettings;
  onClose: () => void;
  /** Select a model for this generation (persisted to settings). */
  onSelectModel: (model: string) => void;
  /** Select the manual language for this generation (persisted to settings). */
  onSelectLanguage: (language: string) => void;
  onGenerate: (result: {
    writerPrompt: string;
    lastWriterId: string;
    writers?: Writer[];
    retranscribe: boolean;
  }) => void;
};

/** Languages offered in the generate dialog (mirrors the Settings page). */
const MANUAL_LANGUAGES = ["English", "German", "Chinese", "Arabic"];

/** Short style descriptors for the known seeded writers, shown as a compact
 *  summary under the Writer select. Falls back to the writer name. */
const STYLE_SUMMARY: Record<string, string> = {
  "software-usage": "Software usage · task-based · concise",
  "hw-integration": "Hardware installation · safety-first · step-by-step",
};

function isGatewayModel(m: string | GatewayModel): m is GatewayModel {
  return typeof m === "object" && m !== null && "id" in m;
}

function promptFor(writers: Writer[], id: string): string {
  if (id === MANUAL_WRITER_ID) return "";
  return writers.find((w) => w.id === id)?.prompt ?? "";
}

function styleSummaryFor(writer: Writer | undefined, isManual: boolean): string {
  if (isManual) return "One-off prompt — not saved to a writer.";
  if (!writer) return "";
  return STYLE_SUMMARY[writer.id] || writer.name.trim() || "Writer";
}

export default function GenerateManualDialog({
  writers,
  lastWriterId,
  hasTranscript,
  settings,
  onClose,
  onSelectModel,
  onSelectLanguage,
  onGenerate,
}: Props) {
  const [selectedId, setSelectedId] = useState(() => resolveWriterId(writers, lastWriterId));
  const [prompt, setPrompt] = useState(() => promptFor(writers, resolveWriterId(writers, lastWriterId)));
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showFullPrompt, setShowFullPrompt] = useState(false);
  const [fullPrompt, setFullPrompt] = useState<string | null>(null);
  const [fullPromptLoading, setFullPromptLoading] = useState(false);
  const [fullPromptError, setFullPromptError] = useState<string | null>(null);
  const [retranscribe, setRetranscribe] = useState(false);

  const isManual = selectedId === MANUAL_WRITER_ID;
  const selectedWriter = writers.find((w) => w.id === selectedId);

  function selectWriter(id: string) {
    setSelectedId(id);
    setPrompt(promptFor(writers, id));
    setEditing(false);
    setError(null);
    setFullPrompt(null);
    setShowFullPrompt(false);
  }

  async function toggleFullPrompt() {
    if (showFullPrompt) {
      setShowFullPrompt(false);
      return;
    }
    setShowFullPrompt(true);
    if (fullPrompt) return;
    setFullPromptLoading(true);
    setFullPromptError(null);
    try {
      const res = await getSystemPrompt(prompt);
      setFullPrompt(res.systemPrompt);
    } catch (e) {
      setFullPromptError(e instanceof Error ? e.message : "Could not load the full prompt");
    } finally {
      setFullPromptLoading(false);
    }
  }

  function tryGenerate(promptValue: string, overrideGlobally: boolean) {
    const writerPrompt = promptValue.trim();
    if (!writerPrompt) {
      setError("Enter a writer prompt before generating.");
      return;
    }
    onGenerate({
      writerPrompt,
      lastWriterId: selectedId,
      writers:
        overrideGlobally && !isManual
          ? writers.map((w) => (w.id === selectedId ? { ...w, prompt: writerPrompt } : w))
          : undefined,
      retranscribe,
    });
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal wide gen-dialog" onClick={(e) => e.stopPropagation()}>
        <header className="gen-dialog-head">
          <h3>Generate manual</h3>
          <p className="gen-dialog-subtitle">
            Choose model, language, writing style and transcript source.
          </p>
        </header>

        {/* Output */}
        <section className="gen-section">
          <h4 className="gen-section-title">Output</h4>
          <div className="field">
            <label htmlFor="gen-model">Model</label>
            <select
              id="gen-model"
              value={settings.selectedModel}
              onChange={(e) => onSelectModel(e.target.value)}
              disabled={!settings.models.length}
            >
              {settings.models.length === 0 && <option value="">No models</option>}
              {settings.models.map((m) => {
                const modelId = isGatewayModel(m) ? m.id : m;
                const modelName = isGatewayModel(m) ? m.name : m;
                return (
                  <option key={modelId} value={modelId}>
                    {modelName}
                  </option>
                );
              })}
            </select>
          </div>
          <div className="field">
            <label htmlFor="gen-language">Language</label>
            <select
              id="gen-language"
              value={settings.manualLanguage || "English"}
              onChange={(e) => onSelectLanguage(e.target.value)}
            >
              {MANUAL_LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>
                  {lang}
                </option>
              ))}
            </select>
          </div>
        </section>

        {/* Writing style */}
        <section className="gen-section">
          <h4 className="gen-section-title">Writing style</h4>
          <div className="field">
            <label htmlFor="gen-writer">Writer</label>
            <select
              id="gen-writer"
              value={selectedId}
              onChange={(e) => selectWriter(e.target.value)}
            >
              {writers.map((writer) => (
                <option key={writer.id} value={writer.id}>
                  {writer.name.trim() || "Untitled"}
                </option>
              ))}
              <option value={MANUAL_WRITER_ID}>Manual</option>
            </select>
          </div>
          <div className="style-summary">
            <span className="style-summary-text">{styleSummaryFor(selectedWriter, isManual)}</span>
            {!isManual && (
              <button
                className="btn ghost btn-sm"
                type="button"
                onClick={() => setEditing((e) => !e)}
                aria-expanded={editing}
              >
                {editing ? "Done" : "Customize style"}
              </button>
            )}
          </div>
          {isManual && <p className="muted">One-off prompt — not saved to a writer.</p>}
        </section>

        {/* Style prompt, revealed via "Customize style" for saved writers; always shown for Manual. */}
        {(isManual || editing) && (
          <div className="prompt-layer">
            <div className="prompt-layer-head">
              <span className="prompt-layer-title">
                {isManual ? "Style prompt" : `Style prompt · ${selectedWriter?.name.trim() || "Writer"}`}
              </span>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => {
                setPrompt(e.target.value);
                setFullPrompt(null);
                if (error) setError(null);
              }}
              placeholder={isManual ? "Write a one-off style prompt for this generation" : undefined}
            />
          </div>
        )}

        {/* Source */}
        {hasTranscript && (
          <section className="gen-section">
            <h4 className="gen-section-title">Source</h4>
            <div className="field">
              <label>Transcript source</label>
              <div className="segmented" role="radiogroup" aria-label="Transcript source">
                <button
                  type="button"
                  role="radio"
                  aria-checked={!retranscribe}
                  className={`segmented-option${!retranscribe ? " selected" : ""}`}
                  onClick={() => setRetranscribe(false)}
                >
                  Use existing transcript
                </button>
                <button
                  type="button"
                  role="radio"
                  aria-checked={retranscribe}
                  className={`segmented-option${retranscribe ? " selected" : ""}`}
                  onClick={() => setRetranscribe(true)}
                >
                  Re-transcribe video
                </button>
              </div>
              <p className="gen-helper">
                {retranscribe
                  ? "Slower, reruns speech-to-text on the video."
                  : "Fast, skips speech-to-text."}
              </p>
            </div>
          </section>
        )}

        {/* Whisper model — always visible so it's clear which model is used. */}
        <section className="gen-section">
          <h4 className="gen-section-title">Whisper</h4>
          <p className="gen-helper whisper-model-hint">
            Model: <strong>{settings.whisperModel}</strong>
          </p>
        </section>

        {/* Advanced */}
        <section className="gen-section">
          <h4 className="gen-section-title">Advanced</h4>
          <div className="prompt-config">
            <div className="prompt-config-main">
              <span className="prompt-config-title">Prompt configuration</span>
              <span className="prompt-config-desc">
                {isManual
                  ? "One-off prompt for this generation"
                  : `${selectedWriter?.name.trim() || "Writer"} · ${styleSummaryFor(selectedWriter, false)}`}
              </span>
            </div>
            <button
              className="prompt-config-toggle"
              type="button"
              onClick={toggleFullPrompt}
              aria-expanded={showFullPrompt}
            >
              {showFullPrompt ? "Hide prompt" : "View prompt"}
            </button>
          </div>

          {showFullPrompt && (
            <div className="prompt-layer full">
              <div className="prompt-layer-head">
                <span className="prompt-layer-title">System prompt</span>
                <span className="prompt-layer-hint">
                  Controls structure, tone, language and generation rules.
                </span>
              </div>
              <div className="prompt-layer-full">
                {fullPromptLoading && <p className="muted">Loading…</p>}
                {fullPromptError && <p className="field-error">{fullPromptError}</p>}
                {fullPrompt && <pre className="prompt-pre">{fullPrompt}</pre>}
              </div>
            </div>
          )}
        </section>

        {error && <p className="field-error">{error}</p>}

        <footer className="modal-actions gen-footer">
          <button className="btn ghost" type="button" onClick={onClose}>
            Cancel
          </button>
          {!isManual && editing ? (
            <>
              <button className="btn" type="button" onClick={() => tryGenerate(prompt, false)}>
                Save only for this time
              </button>
              <button className="btn primary" type="button" onClick={() => tryGenerate(prompt, true)}>
                Save and override writer globally
              </button>
            </>
          ) : (
            <button className="btn primary" type="button" onClick={() => tryGenerate(prompt, false)}>
              Generate
            </button>
          )}
        </footer>
      </div>
    </div>
  );
}
