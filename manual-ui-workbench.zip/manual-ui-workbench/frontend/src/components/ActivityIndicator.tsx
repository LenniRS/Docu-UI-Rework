import { memo } from "react";
import { Check, Loader2, X } from "lucide-react";
import type { OperationState } from "../lib/operations";
import { operationLabel } from "../lib/operations";

type Props = {
  operation: OperationState | null;
  /** Save/dirty state. When saving and no operation is active, the indicator
   *  shows "Änderungen werden gespeichert…" so the user always sees persistence. */
  saveState?: "saved" | "dirty" | "saving" | "error";
};

/**
 * Global activity indicator shown in the toolbar area. Reflects the single
 * active operation: a spinner while running, a brief green check on success,
 * a red error pill on failure. Disappears when there is no operation.
 *
 * When no operation is active but the manual is being saved (`saveState ===
 * "saving"`), it shows a transient "Änderungen werden gespeichert…" pill so the
 * user always sees that persistence is happening.
 */
export default memo(function ActivityIndicator({ operation, saveState = "saved" }: Props) {
  // Video upload/processing and manual generation progress is shown in its own
  // box under the video panel (MediaPanel), so it is not duplicated in the
  // global indicator.
  if (
    operation &&
    (operation.type === "video_upload" ||
      operation.type === "video_processing" ||
      operation.type === "manual_generation")
  ) {
    return null;
  }

  // No operation and not currently saving → nothing to show.
  if (!operation && saveState !== "saving") return null;

  // No active operation but saving → show the save pill.
  if (!operation) {
    return (
      <div className="activity-indicator running" role="status" aria-live="polite" aria-busy>
        <Loader2 size={14} className="spin" aria-hidden />
        <span className="activity-indicator-text">Änderungen werden gespeichert…</span>
      </div>
    );
  }

  const label = operationLabel(operation);
  const target =
    operation.target?.type === "section" && operation.target.sectionNumber
      ? ` · ${operation.target.sectionNumber}`
      : "";

  return (
    <div
      className={`activity-indicator ${operation.status}`}
      role="status"
      aria-live="polite"
      aria-busy={operation.status === "running"}
    >
      {operation.status === "running" && <Loader2 size={14} className="spin" aria-hidden />}
      {operation.status === "success" && <Check size={14} aria-hidden />}
      {operation.status === "error" && <X size={14} aria-hidden />}
      <span className="activity-indicator-text">
        {operation.status === "success" ? `✓ ${label}` : label}
        {target}
      </span>
      {operation.status === "error" && operation.error && (
        <span className="activity-indicator-error" title={operation.error}>
          {operation.error}
        </span>
      )}
    </div>
  );
});
