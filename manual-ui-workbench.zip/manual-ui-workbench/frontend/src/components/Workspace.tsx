import type { MutableRefObject, PointerEvent } from "react";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Download } from "lucide-react";
import EditorPane from "./EditorPane";
import MediaPanel from "./MediaPanel";
import Modal from "./Modal";
import ThemeToggle from "./ThemeToggle";
import ChatWindow from "./ChatWindow";
import ActivityIndicator from "./ActivityIndicator";
import SaveIndicator from "./SaveIndicator";
import GateReportPanel from "./GateReportPanel";
import { applyCouncilEdit, applyCouncilRenameHeading, applyCouncilSectionBodyEdit, applyCouncilSectionEdit, applyCouncilSuggestion, clearCouncilChat, councilChatStream, getCouncil, runCouncil, undoCouncilEdit } from "../lib/api";
import { parseAssistantReply, type CouncilEdit } from "../lib/council";
import { DEFAULT_MEDIA_COL_WIDTH, loadMediaColWidth, saveMediaColWidth } from "../lib/storage";
import { timestampsFromFiles } from "../lib/time";
import type { OperationState } from "../lib/operations";
import type { AppSettings, CouncilChatMessage, CouncilData, DownloadFormat, ProjectRecord, ReferencedContext, Stage, Theme } from "../types";

const MEDIA_COL_MIN = 240;
const EDITOR_COL_MIN = 280;
// Upper bound so the media panel grows with wide windows but never dominates.
const MEDIA_COL_MAX_RATIO = 0.4;
const MEDIA_COL_MAX_ABS = 560;

const EXPORT_FORMATS: { value: DownloadFormat; label: string }[] = [
  { value: "transcript", label: "Transcript" },
  { value: "markdown", label: "Markdown" },
  { value: "cosima", label: "Cosima" },
  { value: "docx", label: "Microsoft Word" },
  { value: "pdf", label: "PDF" },
];

function clampMediaColWidth(width: number, workspaceWidth: number): number {
  const min = MEDIA_COL_MIN;
  const max = workspaceWidth > 0 ? Math.max(min, workspaceWidth - EDITOR_COL_MIN) : Infinity;
  // Cap so the media panel grows with wide windows but never dominates the editor.
  const ratioCap = workspaceWidth > 0 ? Math.max(min, workspaceWidth * MEDIA_COL_MAX_RATIO) : Infinity;
  const upper = Math.min(max, ratioCap, MEDIA_COL_MAX_ABS);
  return Math.min(Math.max(width, min), upper);
}

/**
 * Apply a council chat edit to the manual and return the new markdown plus a
 * user-facing success message. Dispatches on the edit type so each operation
 * (whole section / body-only / heading-only / inline) uses its own endpoint.
 */
async function applyEdit(
  edit: CouncilEdit,
  settings: AppSettings,
  name: string,
): Promise<{ markdown: string; message: string }> {
  switch (edit.type) {
    case "replace_section": {
      const res = await applyCouncilSectionEdit(settings.parentDir, name, edit.section, edit.new_text, settings);
      return { markdown: res.markdown, message: `Abschnitt ${edit.section} wurde übernommen.` };
    }
    case "replace_section_body": {
      const res = await applyCouncilSectionBodyEdit(settings.parentDir, name, edit.section, edit.new_body, settings);
      return { markdown: res.markdown, message: `Der Inhalt von Abschnitt ${edit.section} wurde übernommen.` };
    }
    case "rename_heading": {
      const res = await applyCouncilRenameHeading(settings.parentDir, name, edit.section, edit.new_heading, settings);
      return { markdown: res.markdown, message: `Die Überschrift von Abschnitt ${edit.section} wurde übernommen.` };
    }
    case "replace": {
      const res = await applyCouncilEdit(settings.parentDir, name, edit.old_text, edit.new_text, settings);
      return { markdown: res.markdown, message: "Die Änderung wurde übernommen." };
    }
  }
}

type Props = {
  name: string;
  record: ProjectRecord;
  settings: AppSettings;
  stage: Stage;
  error: string | null;
  videoKey: number;
  downloading: DownloadFormat | null;
  busy: boolean;
  theme: Theme;
  onToggleTheme: () => void;
  onMarkdown: (markdown: string) => void;
  onUpload: (file: File) => void;
  onGenerate: () => void;
  /** Abort the running generation pipeline (from the progress box under the video). */
  onAbort: () => void;
  /** Re-run generation after a failure (opens the generate dialog). */
  onRetry: () => void;
  onExport: (format: DownloadFormat) => void;
  videoRef: MutableRefObject<HTMLVideoElement | null>;
  onShift: (filename: string, delta: number, currentTime?: number) => Promise<string | void>;
  onDeleteImage: (filename: string) => Promise<void>;
  onSeek: (filename: string) => void;
  onReplace: (filename: string) => Promise<string | void>;
  onInsertFrame: () => Promise<{ filename: string; url: string } | null | void>;
  onHeadingNumbering: (value: boolean) => void;
  followStreaming?: boolean;
  /** Incremented after each successful manual generation (triggers council). */
  generationCount?: number;
  /** Centralized operation state (drives indicator, chat card, editor, outline). */
  operation?: OperationState | null;
  onOperationStart?: (op: Omit<OperationState, "id" | "status" | "startedAt">) => void;
  onOperationUpdate?: (patch: Partial<Pick<OperationState, "label" | "step" | "progress" | "target">>) => void;
  onOperationSucceed?: (label?: string) => void;
  onOperationFail?: (error: string) => void;
  onOperationClear?: () => void;
  /** Save/dirty state driven by the debounced save in App.tsx. */
  saveState?: "saved" | "dirty" | "saving" | "error";
};

export default function Workspace({
  name,
  record,
  settings,
  stage,
  error,
  videoKey,
  downloading,
  busy,
  theme,
  onToggleTheme,
  onMarkdown,
  onUpload,
  onGenerate,
  onAbort,
  onRetry,
  onExport,
  videoRef,
  onShift,
  onDeleteImage,
  onSeek,
  onReplace,
  onInsertFrame,
  onHeadingNumbering,
  followStreaming = false,
  generationCount = 0,
  operation = null,
  onOperationStart,
  onOperationUpdate,
  onOperationSucceed,
  onOperationFail,
  saveState = "saved",
}: Props) {
  const durationStamp = `${name}:${videoKey}:${record.hasVideo}`;
  const [durationState, setDurationState] = useState({ stamp: "", duration: 0 });
  const videoDuration = durationState.stamp === durationStamp ? durationState.duration : 0;
  // Stable callback so React.memo(MediaPanel) can skip re-renders when the
  // video duration has not actually changed (an inline arrow would be a new
  // reference every render and defeat the memo).
  const onDuration = useCallback(
    (duration: number) => setDurationState({ stamp: durationStamp, duration }),
    [durationStamp],
  );
  const timestamps = useMemo(
    () => timestampsFromFiles(record.files, record.timestamps),
    [record.files, record.timestamps],
  );
  const canGenerate = record.hasVideo && !busy && Boolean(settings.selectedModel);
  const canExport =
    Boolean(record.transcript) && Boolean(record.markdown) && !busy && !downloading;
  const [exportOpen, setExportOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<DownloadFormat>("markdown");

  // Whether the "N keyword screenshots inserted" status bar is visible. It
  // appears when the screenshot count changes and auto-dismisses after a few
  // seconds so it does not clutter the editor head permanently.
  const [showScreenshotStatus, setShowScreenshotStatus] = useState(false);
  const screenshotStatusTimer = useRef<number | null>(null);
  useEffect(() => {
    if (record.screenshotCount == null || record.screenshotCount <= 0) {
      setShowScreenshotStatus(false);
      return;
    }
    setShowScreenshotStatus(true);
    if (screenshotStatusTimer.current) window.clearTimeout(screenshotStatusTimer.current);
    screenshotStatusTimer.current = window.setTimeout(() => setShowScreenshotStatus(false), 6000);
    return () => {
      if (screenshotStatusTimer.current) window.clearTimeout(screenshotStatusTimer.current);
    };
  }, [record.screenshotCount]);

  // Council review (loaded per project; replaces the old manual checklist).
  const [council, setCouncil] = useState<CouncilData | null>(null);
  const [councilLoading, setCouncilLoading] = useState(false);
  // Chat thread + latest edit proposal, owned here so the separate ChatWindow
  // and the CouncilPanel (proposed change) share the same state.
  const [chatMessages, setChatMessages] = useState<CouncilChatMessage[]>([]);
  const [currentEdit, setCurrentEdit] = useState<CouncilEdit | null>(null);
  const [applying, setApplying] = useState(false);
  // Whether a chat-applied manual change can be undone (back button).
  const [canUndo, setCanUndo] = useState(false);
  // Referenced passages shown as visible context attachments above the chat
  // input and sent to the LLM separately from the user's own text.
  const [referencedContexts, setReferencedContexts] = useState<ReferencedContext[]>([]);
  // Whether referenced context is kept after sending (for follow-up questions).
  const [keepContext, setKeepContext] = useState(false);
  // The council point the user is currently trying to resolve via the chat
  // (set by "Daten hinzufügen"). Cleared once the point is resolved.
  const [resolvePoint, setResolvePoint] = useState<{ title: string; needsInfo?: string } | null>(null);
  // Incremented to open the chat when a reference is added.
  const [referenceOpenSignal, setReferenceOpenSignal] = useState(0);
  // Whether the chat window is expanded (so the editor can reserve space and
  // the expanded chat does not cover the bottom of the manual).
  const [chatExpanded, setChatExpanded] = useState(false);
  // A council passage to jump to + highlight in the editor.
  const [highlightPassage, setHighlightPassage] = useState<{
    passage: string;
    section?: string;
    kind?: string;
  } | null>(null);
  // Incremented on every jump so re-clicking the same passage re-triggers it.
  const [highlightNonce, setHighlightNonce] = useState(0);

  useEffect(() => {
    let cancelled = false;
    if (!name) {
      setCouncil(null);
      setChatMessages([]);
      setCurrentEdit(null);
      setCanUndo(false);
      return;
    }
    setCouncilLoading(true);
    getCouncil(settings.parentDir, name)
      .then((data) => {
        if (!cancelled) {
          setCouncil(data);
          setChatMessages(data.chat || []);
          setCanUndo(Boolean(data.canUndo));
        }
      })
      .catch(() => {
        if (!cancelled) setCouncil(null);
      })
      .finally(() => {
        if (!cancelled) setCouncilLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [name, settings.parentDir, record.markdown]);

  const [councilRunning, setCouncilRunning] = useState(false);
  const onCouncilRun = useCallback(() => {
    if (!name || councilRunning) return;
    setCouncilRunning(true);
    runCouncil(settings.parentDir, name, settings)
      .then((data) => {
        setCouncil(data);
        setChatMessages(data.chat || []);
      })
      .catch(() => {
        /* council failure is non-fatal; keep current state */
      })
      .finally(() => setCouncilRunning(false));
  }, [name, settings, councilRunning]);

  const [councilChatBusy, setCouncilChatBusy] = useState(false);
  const onCouncilSend = useCallback(
    async (messages: CouncilChatMessage[]): Promise<string> => {
      if (!name || councilChatBusy) return "";
      setCouncilChatBusy(true);
      let acc = "";
      try {
        // The referenced contexts are sent to the LLM separately from the
        // user's own text (the backend injects them as a distinct block).
        onOperationStart?.({
          type: "ai_edit",
          label: "KI bearbeitet das Manual…",
          target: { type: "manual" },
          step: "thinking",
        });
        const { resolved, council: updatedCouncil } = await councilChatStream(
          settings.parentDir,
          name,
          messages,
          referencedContexts,
          settings,
          (delta) => {
            acc += delta;
          },
          undefined,
          resolvePoint,
        );
        // Extract any edit proposal. The raw reply may be a large JSON blob —
        // we never surface it directly; we show a clean app-generated message.
        const parsed = parseAssistantReply(acc);
        let assistantContent = parsed.text || acc;
        // The user is authoritative: apply a proposed edit immediately, without
        // asking for confirmation. The back button (undo) is the safety net.
        if (parsed.edit) {
          const sectionNumber =
            parsed.edit.type === "replace_section" ||
            parsed.edit.type === "replace_section_body" ||
            parsed.edit.type === "rename_heading"
              ? parsed.edit.section
              : undefined;
          onOperationUpdate?.({
            step: "resolving_target",
            target: { type: "section", sectionNumber },
          });
          try {
            onOperationUpdate?.({ step: "applying_edit" });
            const { markdown, message } = await applyEdit(parsed.edit, settings, name);
            onMarkdown(markdown);
            setCanUndo(true);
            setCurrentEdit(null);
            assistantContent = message;
            onOperationUpdate?.({ step: "saving" });
            onOperationSucceed?.(`Section ${sectionNumber || ""} aktualisiert`);
          } catch (err) {
            // Auto-apply failed (e.g. section/passage not found, truncated
            // output). Show a clean error message, never the raw JSON.
            const reason = err instanceof Error ? err.message : String(err);
            assistantContent =
              "Die KI hat eine Änderung vorgeschlagen, aber sie konnte nicht automatisch angewendet werden.\n" +
              `Grund: ${reason}`;
            setCurrentEdit(null);
            onOperationFail?.(reason);
          }
        } else {
          setCurrentEdit(null);
          onOperationSucceed?.("Antwort fertig");
        }
        setChatMessages([...messages, { role: "assistant", content: assistantContent }]);
        // If the LLM resolved the council point the user was working on, update
        // the council so the point disappears from the review.
        if (resolved && updatedCouncil) {
          setCouncil(updatedCouncil);
          setResolvePoint(null);
        }
        // Clear the referenced context after sending unless the user chose to
        // keep it for follow-up questions on the same context.
        if (!keepContext) setReferencedContexts([]);
        return assistantContent;
      } finally {
        setCouncilChatBusy(false);
      }
    },
    [name, settings, councilChatBusy, referencedContexts, keepContext, onMarkdown, resolvePoint, onOperationStart, onOperationUpdate, onOperationSucceed, onOperationFail],
  );

  const onCouncilApplyEdit = useCallback(
    async (edit: CouncilEdit) => {
      if (!name || applying) return;
      setApplying(true);
      const sectionNumber =
        edit.type === "replace_section" ||
        edit.type === "replace_section_body" ||
        edit.type === "rename_heading"
          ? edit.section
          : undefined;
      onOperationStart?.({
        type: "section_apply",
        label: "Abschnitt wird aktualisiert…",
        target: { type: "section", sectionNumber },
        step: "applying_edit",
      });
      try {
        const { markdown } = await applyEdit(edit, settings, name);
        // Push the full new manual into the editor to avoid a lost-update race
        // with the editor's debounced save.
        onMarkdown(markdown);
        // The edit was applied; clear the proposal and enable undo.
        setCurrentEdit(null);
        setCanUndo(true);
        onOperationSucceed?.(`Section ${sectionNumber || ""} aktualisiert`);
      } catch (err) {
        onOperationFail?.(err instanceof Error ? err.message : String(err));
      } finally {
        setApplying(false);
      }
    },
    [name, settings, onMarkdown, applying, onOperationStart, onOperationSucceed, onOperationFail],
  );

  // Clear the chat thread (empties the persisted conversation in council.json).
  const onClearChat = useCallback(async () => {
    if (!name) return;
    try {
      await clearCouncilChat(settings.parentDir, name);
    } catch {
      // Clearing is best-effort; still clear the local state so the UI reacts.
    }
    setChatMessages([]);
    setCurrentEdit(null);
    setReferencedContexts([]);
  }, [name, settings.parentDir]);

  // Apply a single council suggestion to the manual.
  const onCouncilApplySuggestion = useCallback(
    async (suggestion: string, passage: string, pointTitle?: string) => {
      if (!name || applying) return;
      setApplying(true);
      try {
        const res = await applyCouncilSuggestion(
          settings.parentDir,
          name,
          suggestion,
          passage,
          settings,
          pointTitle,
        );
        onMarkdown(res.markdown);
        setCanUndo(true);
        // The applied point is removed from the council (backend), so refresh
        // the council view to drop the suggestion card.
        if (res.council) setCouncil(res.council);
      } catch (err) {
        // Surface the failure so the user sees why the suggestion was not
        // applied instead of the button silently doing nothing.
        onOperationFail?.(err instanceof Error ? err.message : String(err));
      } finally {
        setApplying(false);
      }
    },
    [name, settings, onMarkdown, applying, onOperationFail],
  );

  // Apply all council suggestions to the manual, one after another.
  const onCouncilApplyAllSuggestions = useCallback(async () => {
    if (!name || applying || !council) return;
    const withSuggestions = council.points.filter((p) => p.suggestion);
    if (withSuggestions.length === 0) return;
    setApplying(true);
    try {
      let markdown = record.markdown;
      let updatedCouncil: CouncilData | undefined;
      for (const p of withSuggestions) {
        const res = await applyCouncilSuggestion(
          settings.parentDir,
          name,
          p.suggestion || "",
          p.passage || "",
          settings,
          p.title,
        );
        markdown = res.markdown;
        if (res.council) updatedCouncil = res.council;
      }
      onMarkdown(markdown);
      // Refresh the council view so the applied points disappear.
      if (updatedCouncil) setCouncil(updatedCouncil);
    } catch (err) {
      // If one suggestion fails mid-batch, surface the error and keep the
      // suggestions already applied in the editor.
      onOperationFail?.(err instanceof Error ? err.message : String(err));
    } finally {
      setApplying(false);
    }
  }, [name, settings, applying, council, record.markdown, onMarkdown, onOperationFail]);

  // Undo the last chat-applied change to the manual (back button).
  const onCouncilUndo = useCallback(async () => {
    if (!name || applying) return;
    setApplying(true);
    onOperationStart?.({ type: "section_apply", label: "Änderung wird rückgängig gemacht…", target: { type: "manual" }, step: "applying_edit" });
    try {
      const res = await undoCouncilEdit(settings.parentDir, name, settings);
      // Push the restored manual into the editor.
      onMarkdown(res.markdown);
      setCanUndo(res.canUndo);
      // The restored manual invalidates any pending edit proposal.
      setCurrentEdit(null);
      onOperationSucceed?.("Änderung rückgängig gemacht");
    } catch (err) {
      onOperationFail?.(err instanceof Error ? err.message : String(err));
    } finally {
      setApplying(false);
    }
  }, [name, settings, onMarkdown, applying, onOperationStart, onOperationSucceed, onOperationFail]);

  // Reference the selected editor text as chat context (opens the chat).
  const onReferenceSelection = useCallback((text: string) => {
    setReferencedContexts((prev) => [...prev, { source: "manual.md", text }]);
    setReferenceOpenSignal((n) => n + 1);
  }, []);

  // Jump to a council passage in the editor and highlight it.
  const onCouncilJumpToPassage = useCallback(
    (point: { passage: string; section?: string; kind?: string }) => {
      setHighlightPassage({
        passage: point.passage || "",
        section: point.section,
        kind: point.kind,
      });
      setHighlightNonce((n) => n + 1);
    },
    [],
  );

  // Add the missing data note of a missing_info council point as chat context
  // and mark that point as the one being resolved. Once the chat resolves it,
  // the point is removed from the council.
  const onCouncilAddData = useCallback(
    (point: { title: string; needsInfo?: string }) => {
      setResolvePoint({ title: point.title, needsInfo: point.needsInfo });
      setReferencedContexts((prev) => [
        ...prev,
        { source: "council.json", text: `[Fehlende Daten]\n${point.needsInfo || ""}` },
      ]);
      setReferenceOpenSignal((n) => n + 1);
    },
    [],
  );

  // Remove a referenced context attachment by index.
  const onRemoveContext = useCallback((index: number) => {
    setReferencedContexts((prev) => prev.filter((_, i) => i !== index));
  }, []);

  // Automatically run the council review after each successful manual
  // generation. Uses a ref so the effect only fires on a new generationCount.
  const lastGenerationRef = useRef(generationCount);
  useEffect(() => {
    if (generationCount === 0 || generationCount === lastGenerationRef.current) return;
    lastGenerationRef.current = generationCount;
    if (!name) return;
    setCouncilRunning(true);
    runCouncil(settings.parentDir, name, settings)
      .then((data) => {
        setCouncil(data);
      })
      .catch(() => {
        /* council failure is non-fatal; keep current state */
      })
      .finally(() => setCouncilRunning(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generationCount, name, settings.parentDir]);

  const workspaceRef = useRef<HTMLDivElement | null>(null);
  const [preferredMediaWidth, setPreferredMediaWidth] = useState(loadMediaColWidth);
  const [workspaceWidth, setWorkspaceWidth] = useState(0);
  const [resizing, setResizing] = useState(false);
  const preferredMediaWidthRef = useRef(preferredMediaWidth);
  preferredMediaWidthRef.current = preferredMediaWidth;

  const mediaWidth = useMemo(
    () => clampMediaColWidth(preferredMediaWidth, workspaceWidth),
    [preferredMediaWidth, workspaceWidth],
  );

  // Stable style object so React.memo(MediaPanel) can skip re-renders when the
  // media column width has not actually changed.
  const mediaPanelStyle = useMemo(
    () => ({ width: mediaWidth, flexBasis: mediaWidth, flexShrink: 0 }),
    [mediaWidth],
  );

  useLayoutEffect(() => {
    const el = workspaceRef.current;
    if (!el) return;
    const sync = () => setWorkspaceWidth(el.getBoundingClientRect().width);
    sync();
    const observer = new ResizeObserver(sync);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const onSplitterPointerDown = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    setResizing(true);
  }, []);

  const onSplitterPointerMove = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
    const el = workspaceRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const next = clampMediaColWidth(rect.right - e.clientX, rect.width);
    preferredMediaWidthRef.current = next;
    setPreferredMediaWidth(next);
  }, []);

  const onSplitterPointerUp = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setResizing(false);
    saveMediaColWidth(preferredMediaWidthRef.current);
  }, []);

  const onSplitterDoubleClick = useCallback(() => {
    setPreferredMediaWidth(DEFAULT_MEDIA_COL_WIDTH);
    saveMediaColWidth(DEFAULT_MEDIA_COL_WIDTH);
  }, []);

  function openExport() {
    setExportFormat("markdown");
    setExportOpen(true);
  }

  function confirmExport() {
    setExportOpen(false);
    onExport(exportFormat);
  }

  return (
    <div className={`workspace${resizing ? " is-resizing" : ""}${chatExpanded ? " chat-expanded" : ""}`} ref={workspaceRef}>
      <div className="editor-col">
        {error && <div className="banner error">{error}</div>}
        <div className="editor-head">
          <div className="actions">
            <label className={`btn ghost ${busy ? "disabled" : ""}`} title="Upload a video to start">
              Choose file
              <input
                type="file"
                accept="video/*"
                hidden
                disabled={busy}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onUpload(file);
                  e.target.value = "";
                }}
              />
            </label>
            <button
              className="btn primary"
              type="button"
              disabled={!canGenerate}
              onClick={onGenerate}
              title={
                !record.hasVideo
                  ? "Upload a video first"
                  : busy
                    ? "Generation in progress"
                    : !settings.selectedModel
                      ? "Select a model in Settings"
                      : "Generate the manual from the video"
              }
            >
              {stage === "writing" || stage === "transcribing" ? "Generating…" : "Generate manual"}
            </button>
            <button
              className="btn ghost"
              type="button"
              disabled={!canExport}
              onClick={openExport}
              title={
                !record.transcript || !record.markdown
                  ? "Generate a manual first"
                  : busy || downloading
                    ? "Generation in progress"
                    : "Export"
              }
            >
              <Download size={16} />
              {downloading ? "Exporting…" : "Export"}
            </button>
            <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            <div className="editor-head-status">
              <ActivityIndicator operation={operation} saveState={saveState} />
              <SaveIndicator state={saveState} />
            </div>
          </div>
        </div>
        <EditorPane
          markdown={record.markdown}
          onChange={onMarkdown}
          settings={settings}
          hasVideo={record.hasVideo && !busy}
          timestamps={timestamps}
          videoDuration={videoDuration}
          onShift={onShift}
          onDeleteImage={onDeleteImage}
          onSeek={onSeek}
          onReplace={onReplace}
          onInsertFrame={onInsertFrame}
          headingNumbering={Boolean(record.headingNumbering)}
          onHeadingNumbering={onHeadingNumbering}
          followStreaming={followStreaming}
          highlightPassage={highlightPassage}
          highlightNonce={highlightNonce}
          onReferenceSelection={onReferenceSelection}
          operation={operation}
        />
        <GateReportPanel gateReport={record.gateReport} smmSummary={record.smmSummary} />
      </div>
      <div
        className="workspace-splitter"
        role="separator"
        aria-orientation="vertical"
        aria-valuenow={Math.round(mediaWidth)}
        aria-label="Resize preview"
        onPointerDown={onSplitterPointerDown}
        onPointerMove={onSplitterPointerMove}
        onPointerUp={onSplitterPointerUp}
        onPointerCancel={onSplitterPointerUp}
        onDoubleClick={onSplitterDoubleClick}
      />
      <MediaPanel
        parentDir={settings.parentDir}
        projectName={name}
        hasVideo={record.hasVideo}
        videoKey={videoKey}
        videoRef={videoRef}
        onDuration={onDuration}
        council={council}
        councilLoading={councilLoading}
        councilRunning={councilRunning}
        currentEdit={currentEdit}
        applying={applying}
        onCouncilRun={onCouncilRun}
        onCouncilApplyEdit={onCouncilApplyEdit}
        onCouncilApplySuggestion={onCouncilApplySuggestion}
        onCouncilApplyAllSuggestions={onCouncilApplyAllSuggestions}
        onCouncilJumpToPassage={onCouncilJumpToPassage}
        onCouncilAddData={onCouncilAddData}
        operation={operation}
        onAbort={onAbort}
        onRetry={onRetry}
        style={mediaPanelStyle}
      />
      <ChatWindow
        messages={chatMessages}
        chatBusy={councilChatBusy}
        onSend={onCouncilSend}
        contexts={referencedContexts}
        onRemoveContext={onRemoveContext}
        keepContext={keepContext}
        onToggleKeepContext={() => setKeepContext((k) => !k)}
        openSignal={referenceOpenSignal}
        canUndo={canUndo}
        onUndo={onCouncilUndo}
        onClear={onClearChat}
        onExpandedChange={setChatExpanded}
        operation={operation}
      />
      {exportOpen && (
        <Modal
          title="Export"
          onClose={() => setExportOpen(false)}
          onConfirm={confirmExport}
          confirmLabel="Export"
        >
          <div className="field">
            <label htmlFor="export-format">Format</label>
            <select
              id="export-format"
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as DownloadFormat)}
            >
              {EXPORT_FORMATS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </Modal>
      )}
      {showScreenshotStatus && record.screenshotCount != null && record.screenshotCount > 0 && (
        <div className="toast-container" role="status" aria-live="polite">
          <div className="toast">{record.screenshotCount} keyword screenshots inserted</div>
        </div>
      )}
    </div>
  );
}
