import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import { Mark, mergeAttributes } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import Placeholder from "@tiptap/extension-placeholder";
import { Bold, Check, ImagePlus, Italic, List, ListOrdered, ListTree, Loader2, PanelLeft, X } from "lucide-react";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type PointerEvent } from "react";
import { htmlToMarkdown, markdownToHtml } from "../lib/markdown";
import { HeadingNumbers, headingNumberLabel, type HeadingLevel } from "../lib/headingNumbers";
import {
  getNumberingMenuState,
  numberingPosFromEvent,
  OrderedListContinuity,
  type NumberingMenuState,
} from "../lib/listNumbers";
import { FrameImage, consumeSuppressedSrcUpdate, setFrameHandlers } from "./FrameImage";
import { Table } from "./TableExtension";
import Modal from "./Modal";
import type { AppSettings } from "../types";
import { rewriteSelection } from "../lib/api";
import { resolvePassage, type DocHeading, type DocWord } from "../lib/passageMatch";
import type { OperationState } from "../lib/operations";
import {
  DEFAULT_OUTLINE_COL_WIDTH,
  loadOutlineCollapsed,
  loadOutlineColWidth,
  saveOutlineCollapsed,
  saveOutlineColWidth,
} from "../lib/storage";

const OUTLINE_COL_MIN = 140;
const EDITOR_COL_MIN = 280;

/**
 * A transient highlight mark used to draw attention to a council passage.
 * Rendered as a soft yellow marker (not a text selection).
 */
const PassageHighlight = Mark.create({
  name: "passageHighlight",
  addAttributes() {
    return {
      class: { default: "passage-highlight" },
    };
  },
  parseHTML() {
    return [{ tag: "mark[data-passage-highlight]" }];
  },
  renderHTML({ HTMLAttributes }) {
    return ["mark", mergeAttributes(HTMLAttributes, { "data-passage-highlight": "true" }), 0];
  },
});

function clampOutlineColWidth(width: number, bodyWidth: number): number {
  const min = OUTLINE_COL_MIN;
  const max = bodyWidth > 0 ? Math.max(min, bodyWidth - EDITOR_COL_MIN) : Infinity;
  return Math.min(Math.max(width, min), max);
}

type Props = {
  markdown: string;
  onChange: (markdown: string) => void;
  settings: AppSettings;
  hasVideo: boolean;
  timestamps: Record<string, number>;
  videoDuration: number;
  onShift: (filename: string, delta: number, currentTime?: number) => Promise<string | void>;
  onDeleteImage: (filename: string) => Promise<void>;
  onSeek: (filename: string) => void;
  onReplace: (filename: string) => Promise<string | void>;
  onInsertFrame: () => Promise<{ filename: string; url: string } | null | void>;
  headingNumbering: boolean;
  onHeadingNumbering: (value: boolean) => void;
  followStreaming?: boolean;
  /** When set, the editor scrolls to this passage and highlights it. */
  highlightPassage?: { passage: string; section?: string; kind?: string } | null;
  /** Incremented to re-trigger the jump even for the same passage. */
  highlightNonce?: number;
  /** Called with the currently selected text when the user references it. */
  onReferenceSelection?: (text: string) => void;
  /** Centralized operation state (drives section highlight + outline badges). */
  operation?: OperationState | null;
};

type OutlineHeading = {
  level: HeadingLevel;
  text: string;
  pos: number;
};

const HEADING_LEVELS: HeadingLevel[] = [1, 2, 3, 4, 5, 6];

function collectHeadings(editor: Editor): OutlineHeading[] {
  const items: OutlineHeading[] = [];
  editor.state.doc.descendants((node, pos) => {
    if (node.type.name !== "heading") return;
    const level = node.attrs.level as HeadingLevel;
    items.push({ level, text: node.textContent.trim(), pos });
  });
  return items;
}

function headingDom(editor: Editor, pos: number): HTMLElement | null {
  const node = editor.view.nodeDOM(pos);
  if (node instanceof HTMLElement) return node;
  if (node instanceof Node) return node.parentElement;
  return null;
}

/**
 * Collect the DOM elements of a whole section: the heading plus every sibling
 * element that follows it until the next heading of the same or higher level
 * (i.e. a heading that starts a new section at this level or above). Used to
 * highlight the entire affected section, not just its heading.
 */
function sectionDom(editor: Editor, pos: number, level: number): HTMLElement[] {
  const start = headingDom(editor, pos);
  if (!start) return [];
  const parent = start.parentElement;
  if (!parent) return [start];
  const els: HTMLElement[] = [start];
  let node = start.nextElementSibling;
  while (node) {
    const tag = node.tagName;
    if (/^H[1-6]$/.test(tag)) {
      const nextLevel = Number(tag.slice(1));
      // A heading of the same or higher priority (lower number) ends this section.
      if (nextLevel <= level) break;
    }
    els.push(node as HTMLElement);
    node = node.nextElementSibling;
  }
  return els;
}

function headingNearestTop(editor: Editor, wrap: HTMLElement, items: OutlineHeading[]): number | null {
  if (!items.length) return null;
  const threshold = wrap.getBoundingClientRect().top + 12;
  let active = items[0].pos;
  for (const item of items) {
    const el = headingDom(editor, item.pos);
    if (!el) continue;
    if (el.getBoundingClientRect().top <= threshold) active = item.pos;
    else break;
  }
  return active;
}

function sameHeadings(a: OutlineHeading[], b: OutlineHeading[]): boolean {
  if (a.length !== b.length) return false;
  return a.every((h, i) => h.pos === b[i].pos && h.level === b[i].level && h.text === b[i].text);
}

/**
 * Normalize a markdown string so image `src`s are ignored when comparing. Used
 * to detect that the only difference between the editor and an incoming
 * markdown is a frame image URL refresh (timestamp nudge), which should not
 * trigger a full editor reset.
 */
function markdownIgnoringImageSrc(md: string): string {
  return md.replace(/!\[([^\]]*)\]\(([^)]*)\)/g, "![$1](SRC)");
}

function numberOutlineHeadings(items: OutlineHeading[]): string[] {
  const counters = [0, 0, 0, 0, 0, 0];
  return items.map((item) => headingNumberLabel(item.level, counters));
}

function currentBlockStyle(editor: Editor): string {
  for (const level of HEADING_LEVELS) {
    if (editor.isActive("heading", { level })) return String(level);
  }
  return "p";
}

type EditorMenu = {
  x: number;
  y: number;
  text: string;
  from: number;
  to: number;
  numbering: NumberingMenuState | null;
  numberingPos: number;
};

function mnemonicLabel(label: string, letter: string) {
  const i = label.toLowerCase().indexOf(letter.toLowerCase());
  if (i < 0) return label;
  return (
    <>
      {label.slice(0, i)}
      <span className="editor-ctx-key">{label[i]}</span>
      {label.slice(i + 1)}
    </>
  );
}

function IconRestart() {
  return (
    <svg className="editor-ctx-icon" viewBox="0 0 18 18" aria-hidden="true">
      <text x="1" y="7" fontSize="8" fontWeight="700" fill="currentColor">
        1
      </text>
      <text x="1" y="16" fontSize="8" fill="currentColor">
        2
      </text>
      <path d="M11 4v6" stroke="#c62828" strokeWidth="1.6" fill="none" />
      <path d="M8.5 8.5 11 11.5 13.5 8.5" stroke="#c62828" strokeWidth="1.6" fill="none" />
    </svg>
  );
}

function IconContinue() {
  return (
    <svg className="editor-ctx-icon" viewBox="0 0 18 18" aria-hidden="true">
      <text x="1" y="7" fontSize="7" fill="currentColor">
        9
      </text>
      <text x="1" y="16" fontSize="7" fill="currentColor">
        1
      </text>
      <path d="M10 5h5v8H8" stroke="#c62828" strokeWidth="1.5" fill="none" />
      <path d="M10 11.5 8 13.5 10 15.5" stroke="#c62828" strokeWidth="1.5" fill="none" />
    </svg>
  );
}

function IconSetValue() {
  return (
    <svg className="editor-ctx-icon" viewBox="0 0 18 18" aria-hidden="true">
      <text x="0" y="12" fontSize="7" fill="currentColor">
        123
      </text>
      <path d="M11 13.5 16 4l1 1-5 9.5H11v-1z" fill="#1565c0" />
    </svg>
  );
}

export default function EditorPane({
  markdown,
  onChange,
  settings,
  hasVideo,
  timestamps,
  videoDuration,
  onShift,
  onDeleteImage,
  onSeek,
  onReplace,
  onInsertFrame,
  headingNumbering,
  onHeadingNumbering,
  followStreaming = false,
  highlightPassage = null,
  highlightNonce = 0,
  onReferenceSelection,
  operation = null,
}: Props) {
  const skip = useRef(false);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const bodyRef = useRef<HTMLDivElement | null>(null);
  const [menu, setMenu] = useState<EditorMenu | null>(null);
  const [instruction, setInstruction] = useState("");
  // Transient status note shown when a council passage cannot be located.
  const [jumpStatus, setJumpStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [valueDialog, setValueDialog] = useState<{ pos: number; value: number } | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  // Translucent "KI fragen?" popup shown near a text selection. Stores the
  // target positions so the popup can be re-anchored to the text on scroll.
  const [refPopup, setRefPopup] = useState<{ from: number; to: number; text: string } | null>(null);
  // "KI fragen?" popup shown for a highlighted council passage, independent of
  // the text selection (so no blue selection overlay appears on the mark).
  const [forcedRefPopup, setForcedRefPopup] = useState<{ from: number; to: number; text: string } | null>(null);
  // Computed screen position of the active popup, re-derived on scroll so the
  // popup stays anchored to the text instead of drifting with the page.
  const [popupPos, setPopupPos] = useState<{ x: number; y: number } | null>(null);
  const refPopupRef = useRef<HTMLDivElement | null>(null);
  // Holds the current popup target so repositionPopup can read it without
  // depending on state (avoids a render loop).
  const popupTargetRef = useRef<{ from: number; to: number; text: string } | null>(null);
  // Tracks whether the forced (highlight) popup is active, so the selection
  // handler does not clear it.
  const forcedPopupActiveRef = useRef(false);
  // Remembers the last non-empty text selection so the context menu can still
  // reference it even if the right-click collapses the selection.
  const lastSelectionRef = useRef<{ from: number; to: number; text: string } | null>(null);
  const [inserting, setInserting] = useState(false);
  const [headings, setHeadings] = useState<OutlineHeading[]>([]);
  const [activePos, setActivePos] = useState<number | null>(null);
  const [blockStyle, setBlockStyle] = useState("p");
  const [preferredOutlineWidth, setPreferredOutlineWidth] = useState(loadOutlineColWidth);
  const [bodyWidth, setBodyWidth] = useState(0);
  const [resizing, setResizing] = useState(false);
  const [outlineCollapsed, setOutlineCollapsed] = useState(loadOutlineCollapsed);
  const preferredOutlineWidthRef = useRef(preferredOutlineWidth);
  preferredOutlineWidthRef.current = preferredOutlineWidth;

  const outlineWidth = useMemo(
    () => clampOutlineColWidth(preferredOutlineWidth, bodyWidth),
    [preferredOutlineWidth, bodyWidth],
  );

  const outlineNumbers = useMemo(
    () => (headingNumbering ? numberOutlineHeadings(headings) : null),
    [headingNumbering, headings],
  );

  // Heading positions affected by the current operation (for outline badges +
  // editor section highlight). Matches by section number (e.g. "1") or by
  // heading text against the operation target.
  const operationHeadingPos = useMemo(() => {
    const target = operation?.target;
    if (!target || target.type !== "section") return null;
    const num = target.sectionNumber;
    const heading = target.heading;
    if (!num && !heading) return null;
    const match = headings.find((h) => {
      if (num) {
        // Match "1." / "1" / "1 Scope" style prefixes in the heading text.
        const m = h.text.match(/^\s*(\d+)\s*[.\-:]?\s*/);
        if (m && m[1] === num) return true;
      }
      if (heading && h.text.toLowerCase().includes(heading.toLowerCase())) return true;
      return false;
    });
    return match ? match.pos : null;
  }, [operation, headings]);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3, 4, 5, 6] },
        orderedList: { keepAttributes: true, keepMarks: true },
      }),
      Underline,
      Placeholder.configure({ placeholder: "Transcript and manual appear here…" }),
      FrameImage,
      HeadingNumbers,
      OrderedListContinuity,
      PassageHighlight,
      Table,
    ],
    content: markdownToHtml(markdown),
    editorProps: {
      attributes: {
        class: "tiptap",
      },
    },
    onUpdate: ({ editor: ed, transaction }) => {
      if (skip.current || !transaction.docChanged) return;
      // A frame image `src` refresh (after a timestamp nudge / replace) is a
      // targeted node patch, not a document content edit. Skip the full
      // markdown re-serialization so the whole document is not rebuilt on every
      // nudge (the src divergence self-heals on the next real content change).
      if (consumeSuppressedSrcUpdate()) return;
      onChange(htmlToMarkdown(ed.getHTML()));
    },
  });

  // Apply a transient highlight class to the whole affected section (heading +
  // body) in the editor while an operation targets it, and a brief
  // success/error flash after. The highlight is removed after a short delay so
  // it does not linger permanently.
  useEffect(() => {
    if (!editor || operationHeadingPos == null) return;
    const heading = headingDom(editor, operationHeadingPos);
    if (!heading) return;
    const level = /^H([1-6])$/.test(heading.tagName)
      ? Number(heading.tagName.slice(1))
      : 1;
    const els = sectionDom(editor, operationHeadingPos, level);
    if (els.length === 0) return;
    const status = operation?.status;
    els.forEach((el) => {
      el.classList.add("op-section");
      if (status === "success") el.classList.add("op-flash-success");
      if (status === "error") el.classList.add("op-flash-error");
    });
    const timer = window.setTimeout(() => {
      els.forEach((el) => {
        el.classList.remove("op-section", "op-flash-success", "op-flash-error");
      });
    }, 2500);
    return () => {
      window.clearTimeout(timer);
      els.forEach((el) => {
        el.classList.remove("op-section", "op-flash-success", "op-flash-error");
      });
    };
  }, [editor, operationHeadingPos, operation?.status]);

  // Recompute the "KI fragen?" popup's screen position so it stays anchored to
  // the text even when the editor scrolls. Reads the target from a ref (not
  // state) so this callback is stable and does not trigger a render loop.
  //
  // Two anchoring modes:
  //  - Highlight (council passage): anchor to the live `mark[data-passage-highlight]`
  //    element so the popup tracks the highlighted text exactly.
  //  - Plain text selection: anchor to the current DOM selection's bounding
  //    rect so the popup appears above the selected text.
  const repositionPopup = useCallback(() => {
    if (!editor) return;
    const target = popupTargetRef.current;
    if (!target) {
      setPopupPos(null);
      return;
    }
    const wrap = wrapRef.current;
    if (!wrap) return;
    const wrapRect = wrap.getBoundingClientRect();
    let rect: DOMRect | null = null;
    // Prefer the highlighted mark's live position (viewport coords) so the
    // popup tracks the text exactly, including during scroll.
    const mark = wrap.querySelector("mark[data-passage-highlight]");
    if (mark) {
      rect = mark.getBoundingClientRect();
    } else {
      // No highlight mark — anchor to the current DOM text selection.
      const sel = window.getSelection();
      if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        rect = range.getBoundingClientRect();
      }
    }
    if (!rect || (rect.width === 0 && rect.height === 0)) return;
    // Center the popup horizontally over the selection/mark, just above it.
    const x = (rect.left + rect.right) / 2;
    const y = rect.top - 8;
    setPopupPos({
      x: Math.min(Math.max(x, wrapRect.left + 60), wrapRect.right - 60),
      y: Math.max(y, wrapRect.top + 4),
    });
  }, [editor]);

  useEffect(() => {
    setFrameHandlers({
      onShift,
      onDelete: onDeleteImage,
      onSeek,
      onReplace,
      timestamps,
      videoDuration,
      hasVideo,
    });
  }, [onShift, onDeleteImage, onSeek, onReplace, timestamps, videoDuration, hasVideo]);

  useEffect(() => {
    if (!editor) return;
    const current = htmlToMarkdown(editor.getHTML()).trim();
    if (current === (markdown || "").trim()) return;
    // A frame timestamp nudge refreshes the image src in the document via a
    // targeted node patch (FrameImage) and updates the manual's src in the
    // record (App). If the only difference between the editor and the incoming
    // markdown is image srcs, don't reset the editor — the src is already
    // updated in the document, and a full setContent would rebuild the whole
    // document and cause a visible stutter.
    if (markdownIgnoringImageSrc(current) === markdownIgnoringImageSrc(markdown || "")) {
      return;
    }
    skip.current = true;
    editor.commands.setContent(markdownToHtml(markdown || ""), false);
    skip.current = false;
    if (followStreaming) {
      requestAnimationFrame(() => {
        const wrap = wrapRef.current;
        if (wrap) wrap.scrollTop = wrap.scrollHeight;
      });
    }
  }, [markdown, editor, followStreaming]);

  useEffect(() => {
    if (!editor) return;
    editor.storage.headingNumbers.enabled = headingNumbering;
    skip.current = true;
    editor.view.dispatch(editor.state.tr);
    skip.current = false;
  }, [editor, headingNumbering]);

  useEffect(() => {
    if (!editor) return;

    const syncOutline = () => {
      const items = collectHeadings(editor);
      setHeadings((prev) => (sameHeadings(prev, items) ? prev : items));
      const wrap = wrapRef.current;
      const nextActive = wrap ? headingNearestTop(editor, wrap, items) : (items[0]?.pos ?? null);
      setActivePos((prev) => (prev === nextActive ? prev : nextActive));
      const nextStyle = currentBlockStyle(editor);
      setBlockStyle((prev) => (prev === nextStyle ? prev : nextStyle));
    };

    const rememberSelection = () => {
      const { from, to, empty } = editor.state.selection;
      if (empty) return;
      const text = editor.state.doc.textBetween(from, to, " ");
      if (text.trim()) lastSelectionRef.current = { from, to, text };
    };

    // Show the translucent "KI fragen?" popup above a non-empty selection.
    const updateRefPopup = () => {
      const { from, to, empty } = editor.state.selection;
      if (empty) {
        setRefPopup(null);
        // Only clear the shared target if the forced (highlight) popup is not
        // active — otherwise we'd wipe the highlight popup's anchor.
        if (!forcedPopupActiveRef.current) popupTargetRef.current = null;
        return;
      }
      const text = editor.state.doc.textBetween(from, to, " ");
      if (!text.trim()) {
        setRefPopup(null);
        if (!forcedPopupActiveRef.current) popupTargetRef.current = null;
        return;
      }
      setRefPopup({ from, to, text });
      popupTargetRef.current = { from, to, text };
      // Defer positioning to the next frame so the DOM selection is updated
      // before we read its bounding rect (ProseMirror updates the DOM
      // selection asynchronously after the selectionUpdate event).
      requestAnimationFrame(repositionPopup);
    };

    syncOutline();
    editor.on("update", syncOutline);
    editor.on("selectionUpdate", () => {
      syncOutline();
      rememberSelection();
      updateRefPopup();
    });
    const wrap = wrapRef.current;
    wrap?.addEventListener("scroll", syncOutline, { passive: true });
    wrap?.addEventListener("scroll", repositionPopup, { passive: true });

    return () => {
      editor.off("update", syncOutline);
      editor.off("selectionUpdate", () => {
        syncOutline();
        rememberSelection();
        updateRefPopup();
      });
      wrap?.removeEventListener("scroll", syncOutline);
      wrap?.removeEventListener("scroll", repositionPopup);
    };
  }, [editor, repositionPopup]);

  useLayoutEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    const sync = () => setBodyWidth(el.getBoundingClientRect().width);
    sync();
    const observer = new ResizeObserver(sync);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Jump to a council passage and highlight it. Council passages are often
  // paraphrases rather than verbatim quotes, and sometimes describe content
  // that is absent from the manual. We resolve the passage + section hint
  // against the document with a tiered matcher (see lib/passageMatch.ts) and
  // apply a transient highlight mark to the best location (a soft marker, not
  // a selection). When nothing matches, we show a short non-blocking note.
  useEffect(() => {
    if (!editor || !highlightPassage) return;
    const { passage, section, kind } = highlightPassage;
    const needle = (passage || "").replace(/\s+/g, " ").trim();
    if (!needle && !section) return;

    // Collect every word in the document with its TRUE ProseMirror position by
    // walking the document tree (textBetween would shift positions at block
    // boundaries, causing partial-word selections). Tokenization mirrors the
    // matcher so technical terms (192.168.29.2, R&S, EM200) stay whole.
    const docWords: DocWord[] = [];
    editor.state.doc.descendants((node, pos) => {
      if (node.isText && node.text) {
        const tokenRe = /[\p{L}\p{N}]+(?:[.\-&][\p{L}\p{N}]+)*/gu;
        let m: RegExpExecArray | null;
        while ((m = tokenRe.exec(node.text)) !== null) {
          docWords.push({
            word: m[0].toLowerCase(),
            from: pos + m.index,
            to: pos + m.index + m[0].length,
          });
        }
      }
      return true;
    });

    const headings: DocHeading[] = collectHeadings(editor).map((h) => ({
      level: h.level,
      text: h.text,
      pos: h.pos,
    }));

    const result = resolvePassage({ passage: needle, section, kind, docWords, headings });

    // Scroll the highlighted mark into view within the editor wrap.
    const scrollToMark = () => {
      requestAnimationFrame(() => {
        const wrap = wrapRef.current;
        if (!wrap) return;
        const mark = wrap.querySelector("mark[data-passage-highlight]");
        if (mark) mark.scrollIntoView({ block: "center", behavior: "smooth" });
      });
    };

    // Expand a matched word range to the full block (paragraph) containing it,
    // so the user sees the whole criticized region, not just a fragment. We use
    // ProseMirror block boundaries so the positions stay accurate.
    const expandToBlock = (from: number): { from: number; to: number } => {
      const doc = editor.state.doc;
      const startRes = doc.resolve(from);
      // Always highlight a single block (the one containing the match start),
      // never spanning across blocks. This prevents a highlight from swallowing
      // an intervening heading or unrelated content when a match straddles a
      // section boundary.
      return { from: startRes.start(), to: startRes.end() };
    };

    if (result.status === "match") {
      const { from, to } = expandToBlock(result.from);
      // Apply the highlight mark, then collapse the selection to a cursor so
      // only the yellow marker is visible (no blue selection overlay). Show the
      // "KI fragen?" popup for the highlighted text via a dedicated state that
      // is independent of the text selection.
      editor
        .chain()
        .focus()
        .setTextSelection({ from, to })
        .setMark("passageHighlight", {})
        .setTextSelection(from)
        .run();
      const text = editor.state.doc.textBetween(from, to, " ");
      setForcedRefPopup({ from, to, text });
      popupTargetRef.current = { from, to, text };
      forcedPopupActiveRef.current = true;
      scrollToMark();
      // Position the popup after the mark is rendered.
      requestAnimationFrame(repositionPopup);
      const timer = window.setTimeout(() => {
        editor.chain().focus().unsetMark("passageHighlight").run();
        setForcedRefPopup(null);
        popupTargetRef.current = null;
        forcedPopupActiveRef.current = false;
      }, 3500);
      return () => {
        window.clearTimeout(timer);
        setForcedRefPopup(null);
        popupTargetRef.current = null;
        forcedPopupActiveRef.current = false;
      };
    }

    if (result.status === "section") {
      // Jump to the section heading and highlight it.
      const pos = result.headingPos;
      editor.chain().focus().setTextSelection(pos + 1).run();
      headingDom(editor, pos)?.scrollIntoView({ block: "start", behavior: "smooth" });
      setActivePos(pos);
      const timer = window.setTimeout(() => {
        editor.chain().focus().unsetMark("passageHighlight").run();
      }, 3500);
      return () => window.clearTimeout(timer);
    }

    // No match — show a short, non-blocking note instead of silently doing
    // nothing.
    setJumpStatus("Kein passender Abschnitt im Manual gefunden.");
    const timer = window.setTimeout(() => setJumpStatus(""), 3500);
    return () => window.clearTimeout(timer);
  }, [editor, highlightPassage, highlightNonce, repositionPopup]);

  const onSplitterPointerDown = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    setResizing(true);
  }, []);

  const onSplitterPointerMove = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
    const el = bodyRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const next = clampOutlineColWidth(e.clientX - rect.left, rect.width);
    preferredOutlineWidthRef.current = next;
    setPreferredOutlineWidth(next);
  }, []);

  const onSplitterPointerUp = useCallback((e: PointerEvent<HTMLDivElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setResizing(false);
    saveOutlineColWidth(preferredOutlineWidthRef.current);
  }, []);

  const onSplitterDoubleClick = useCallback(() => {
    setPreferredOutlineWidth(DEFAULT_OUTLINE_COL_WIDTH);
    saveOutlineColWidth(DEFAULT_OUTLINE_COL_WIDTH);
  }, []);

  function toggleOutline() {
    const next = !outlineCollapsed;
    setOutlineCollapsed(next);
    saveOutlineCollapsed(next);
  }

  function applyBlockStyle(value: string) {
    if (!editor) return;
    if (value === "p") {
      editor.chain().focus().setParagraph().run();
      return;
    }
    const level = Number(value) as HeadingLevel;
    if (HEADING_LEVELS.includes(level)) {
      editor.chain().focus().setHeading({ level }).run();
    }
  }

  function jumpToHeading(pos: number) {
    if (!editor) return;
    editor.chain().focus().setTextSelection(pos + 1).run();
    headingDom(editor, pos)?.scrollIntoView({ block: "start", behavior: "smooth" });
    setActivePos(pos);
  }

  async function insertFrame() {
    if (!editor || inserting) return;
    setInserting(true);
    try {
      const res = await onInsertFrame();
      if (!res) return;
      editor.chain().focus().setImage({ src: res.url, alt: res.filename }).run();
    } catch (err) {
      alert(err instanceof Error ? err.message : String(err));
    } finally {
      setInserting(false);
    }
  }

  function closeMenu() {
    setMenu(null);
    setInstruction("");
  }

  function runNumbering(command: "restart" | "continue" | "value", value?: number) {
    if (!editor || !menu?.numbering) return;
    const chain = editor.chain().focus().setTextSelection(menu.numberingPos);
    if (command === "restart") chain.restartOrderedList().run();
    else if (command === "continue") chain.continueOrderedList().run();
    else chain.setOrderedListValue(value ?? menu.numbering.value).run();
    closeMenu();
  }

  function openSetValueDialog() {
    if (!menu?.numbering) return;
    setValueDialog({ pos: menu.numberingPos, value: menu.numbering.value });
    closeMenu();
  }

  function applySetValue() {
    if (!editor || !valueDialog) return;
    const next = Math.max(1, Math.floor(Number(valueDialog.value) || 1));
    editor.chain().focus().setTextSelection(valueDialog.pos).setOrderedListValue(next).run();
    setValueDialog(null);
  }

  async function applyAi() {
    if (!editor || !menu) return;
    setBusy(true);
    try {
      const around = editor.state.doc.textBetween(
        Math.max(0, menu.from - 400),
        Math.min(editor.state.doc.content.size, menu.to + 400),
        " ",
      );
      const res = await rewriteSelection(settings, menu.text, instruction, around);
      if (menu.text.trim()) {
        editor.chain().focus().insertContentAt({ from: menu.from, to: menu.to }, res.text).run();
      } else {
        editor.chain().focus().insertContentAt(menu.from, res.text).run();
      }
      closeMenu();
    } catch (err) {
      alert(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (!menu) return;
    const open = menu;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        closeMenu();
        return;
      }
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "TEXTAREA" || target.tagName === "INPUT")) return;
      if (!open.numbering) return;
      const key = e.key.toLowerCase();
      if (key === "r" && open.numbering.canRestart) {
        e.preventDefault();
        runNumbering("restart");
      } else if (key === "c" && open.numbering.canContinue) {
        e.preventDefault();
        runNumbering("continue");
      } else if (key === "v") {
        e.preventDefault();
        openSetValueDialog();
      }
    }
    function onPointer(e: globalThis.PointerEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) closeMenu();
    }
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onPointer);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointerdown", onPointer);
    };
  }, [menu]);

  return (
    <>
      <div className="toolbar">
        <button
          type="button"
          className={!outlineCollapsed ? "on" : ""}
          aria-pressed={!outlineCollapsed}
          title={outlineCollapsed ? "Show outline" : "Collapse outline"}
          aria-label={outlineCollapsed ? "Show outline" : "Collapse outline"}
          onClick={toggleOutline}
        >
          <PanelLeft size={16} />
        </button>
        {editor && (
          <>
            <select
              aria-label="Paragraph style"
              title="Style"
              value={blockStyle}
              onChange={(e) => applyBlockStyle(e.target.value)}
            >
              <option value="p">Normal</option>
              {HEADING_LEVELS.map((level) => (
                <option key={level} value={String(level)}>
                  Heading {level}
                </option>
              ))}
            </select>
            <button
              type="button"
              className={headingNumbering ? "on" : ""}
              aria-pressed={headingNumbering}
              title={headingNumbering ? "Hide heading numbers" : "Show heading numbers"}
              aria-label={headingNumbering ? "Hide heading numbers" : "Show heading numbers"}
              onClick={() => onHeadingNumbering(!headingNumbering)}
            >
              <ListTree size={16} />
            </button>
            <button type="button" className={editor.isActive("bold") ? "on" : ""} title="Bold" aria-label="Bold" aria-pressed={editor.isActive("bold")} onClick={() => editor.chain().focus().toggleBold().run()}>
              <Bold size={16} />
            </button>
            <button type="button" className={editor.isActive("italic") ? "on" : ""} title="Italic" aria-label="Italic" aria-pressed={editor.isActive("italic")} onClick={() => editor.chain().focus().toggleItalic().run()}>
              <Italic size={16} />
            </button>
            <button type="button" className={editor.isActive("bulletList") ? "on" : ""} title="Bullet list" aria-label="Bullet list" aria-pressed={editor.isActive("bulletList")} onClick={() => editor.chain().focus().toggleBulletList().run()}>
              <List size={16} />
            </button>
            <button type="button" className={editor.isActive("orderedList") ? "on" : ""} title="Numbered list" aria-label="Numbered list" aria-pressed={editor.isActive("orderedList")} onClick={() => editor.chain().focus().toggleOrderedList().run()}>
              <ListOrdered size={16} />
            </button>
            <button
              type="button"
              title="Insert frame"
              aria-label="Insert frame at cursor"
              disabled={!hasVideo || inserting}
              onClick={() => void insertFrame()}
            >
              <ImagePlus size={16} />
            </button>
          </>
        )}
      </div>
      <div className={`editor-body${resizing ? " is-resizing" : ""}`} ref={bodyRef}>
        {!outlineCollapsed && (
          <>
            <nav
              className="editor-outline"
              aria-label="Document outline"
              style={{ width: outlineWidth, flexBasis: outlineWidth, flexShrink: 0 }}
            >
              {headings.length === 0 ? (
                <div className="editor-outline-empty">No headings</div>
              ) : (
                <ul>
                  {headings.map((h, i) => {
                    const label = outlineNumbers?.[i];
                    const title = label
                      ? `${label} ${h.text || "Untitled heading"}`
                      : h.text || "Untitled heading";
                    const isOpTarget = operationHeadingPos === h.pos;
                    const opStatus = isOpTarget ? operation?.status : undefined;
                    return (
                      <li key={h.pos}>
                        <button
                          type="button"
                          data-level={h.level}
                          className={`${activePos === h.pos ? "active" : ""}${isOpTarget ? " op-target" : ""}`}
                          aria-current={activePos === h.pos ? "location" : undefined}
                          title={title}
                          onClick={() => jumpToHeading(h.pos)}
                        >
                          {label ? `${label} ` : null}
                          {h.text || <span className="muted">Untitled heading</span>}
                          {isOpTarget && (
                            <span className={`outline-op-badge ${opStatus || ""}`} aria-hidden>
                              {opStatus === "running" && <Loader2 size={11} className="spin" />}
                              {opStatus === "success" && <Check size={11} />}
                              {opStatus === "error" && <X size={11} />}
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </nav>
            <div
              className="editor-outline-splitter"
              role="separator"
              aria-orientation="vertical"
              aria-valuenow={Math.round(outlineWidth)}
              aria-label="Resize outline"
              onPointerDown={onSplitterPointerDown}
              onPointerMove={onSplitterPointerMove}
              onPointerUp={onSplitterPointerUp}
              onPointerCancel={onSplitterPointerUp}
              onDoubleClick={onSplitterDoubleClick}
            />
          </>
        )}
        <div
          className="editor-wrap"
          ref={wrapRef}
          onContextMenu={(e) => {
            if (!editor) return;
            e.preventDefault();
            const numberingPos = numberingPosFromEvent(editor.view, e.nativeEvent);
            const { from, to, empty } = editor.state.selection;
            // If the right-click collapsed the selection, fall back to the last
            // remembered non-empty selection so "reference" still works.
            let selFrom = from;
            let selTo = to;
            let text = editor.state.doc.textBetween(from, to, " ");
            if (empty || !text.trim()) {
              const last = lastSelectionRef.current;
              if (last) {
                selFrom = last.from;
                selTo = last.to;
                text = last.text;
              }
            }
            const numbering =
              numberingPos != null ? getNumberingMenuState(editor.state.doc, numberingPos) : null;
            setInstruction("");
            setMenu({
              x: Math.min(e.clientX, window.innerWidth - 300),
              y: Math.min(e.clientY, window.innerHeight - 360),
              text,
              from: selFrom,
              to: selTo,
              numbering,
              numberingPos: numberingPos ?? selFrom,
            });
          }}
        >
          {editor && <EditorContent editor={editor} />}
          {jumpStatus && <div className="editor-jump-status">{jumpStatus}</div>}
        </div>
      </div>
      {((refPopup && onReferenceSelection) || (forcedRefPopup && onReferenceSelection)) && popupPos && (
        <div
          className="editor-ref-popup"
          ref={refPopupRef}
          role="button"
          tabIndex={0}
          style={{ left: popupPos.x, top: popupPos.y }}
          onClick={() => {
            onReferenceSelection((forcedRefPopup || refPopup)!.text);
            setRefPopup(null);
            setForcedRefPopup(null);
            setPopupPos(null);
            popupTargetRef.current = null;
            forcedPopupActiveRef.current = false;
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onReferenceSelection((forcedRefPopup || refPopup)!.text);
              setRefPopup(null);
              setForcedRefPopup(null);
              setPopupPos(null);
              popupTargetRef.current = null;
              forcedPopupActiveRef.current = false;
            }
          }}
          title="Ausgewählten Text an die KI senden"
        >
          <span className="editor-ref-popup-icon">⤴</span>
          <span>KI fragen?</span>
        </div>
      )}
      {menu && (
        <div
          className="editor-ctx"
          ref={menuRef}
          role="menu"
          style={{ left: menu.x, top: menu.y }}
          onContextMenu={(e) => e.preventDefault()}
        >
          {menu.numbering && (
            <>
              <button
                type="button"
                className="editor-ctx-item"
                role="menuitem"
                disabled={!menu.numbering.canRestart}
                onClick={() => runNumbering("restart")}
              >
                <IconRestart />
                <span>{mnemonicLabel("Restart at 1", "r")}</span>
              </button>
              <button
                type="button"
                className="editor-ctx-item"
                role="menuitem"
                disabled={!menu.numbering.canContinue}
                onClick={() => runNumbering("continue")}
              >
                <IconContinue />
                <span>{mnemonicLabel("Continue Numbering", "c")}</span>
              </button>
              <button
                type="button"
                className="editor-ctx-item"
                role="menuitem"
                onClick={openSetValueDialog}
              >
                <IconSetValue />
                <span>{mnemonicLabel("Set Numbering Value...", "v")}</span>
              </button>
              <hr className="editor-ctx-sep" />
            </>
          )}
          {menu.text.trim() && onReferenceSelection && (
            <>
              <button
                type="button"
                className="editor-ctx-item"
                role="menuitem"
                onClick={() => {
                  onReferenceSelection(menu.text);
                  closeMenu();
                }}
              >
                <span className="editor-ctx-ref-icon">⤴</span>
                <span>An LLM referenzieren</span>
              </button>
              <hr className="editor-ctx-sep" />
            </>
          )}
          <div className="editor-ctx-ai">
            <div className="muted">{menu.text.trim() ? "Rewrite selection with AI" : "Insert text with AI"}</div>
            <textarea
              placeholder="Instruction for the LLM"
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
            />
            <div className="row">
              <button className="btn ghost" type="button" onClick={closeMenu}>
                Cancel
              </button>
              <button
                className="btn primary"
                type="button"
                disabled={busy || !instruction.trim()}
                onClick={() => void applyAi()}
              >
                {busy ? (menu.text.trim() ? "Rewriting…" : "Inserting…") : "Apply"}
              </button>
            </div>
          </div>
        </div>
      )}
      {valueDialog && (
        <Modal
          title="Set numbering value"
          onClose={() => setValueDialog(null)}
          onConfirm={applySetValue}
          confirmDisabled={!Number.isFinite(valueDialog.value) || valueDialog.value < 1}
        >
          <div className="field">
            <label htmlFor="list-number-value">Set value to</label>
            <input
              id="list-number-value"
              type="number"
              min={1}
              step={1}
              value={valueDialog.value}
              onChange={(e) => setValueDialog({ ...valueDialog, value: Number(e.target.value) })}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  applySetValue();
                }
              }}
            />
          </div>
        </Modal>
      )}
    </>
  );
}
