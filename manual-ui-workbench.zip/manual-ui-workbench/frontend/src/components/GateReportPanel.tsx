import type { GateResult, SmmSummary } from "../types";

type Props = {
  gateReport?: GateResult[];
  smmSummary?: SmmSummary;
};

const STATUS_ICON: Record<string, string> = {
  passed: "✅",
  warning: "⚠️",
  blocked: "⛔",
};

/**
 * Panel showing the SMM quality gate report after a manual is generated.
 * Displays the gate status summary and the individual gate results.
 */
export default function GateReportPanel({ gateReport, smmSummary }: Props) {
  if (!gateReport || gateReport.length === 0) {
    return null;
  }

  const blocked = gateReport.filter((g) => g.status === "blocked").length;
  const warnings = gateReport.filter((g) => g.status === "warning").length;
  const passed = gateReport.filter((g) => g.status === "passed").length;

  return (
    <div className="gate-report-panel">
      <div className="gate-report-head">
        <span className="gate-report-title">Quality Gates</span>
        {smmSummary && (
          <span className="gate-report-summary">
            {smmSummary.title}
          </span>
        )}
      </div>
      <div className="gate-report-counts">
        <span className={`gate-count ${blocked > 0 ? "blocked" : ""}`}>
          {blocked} blockiert
        </span>
        <span className={`gate-count ${warnings > 0 ? "warning" : ""}`}>
          {warnings} Warnungen
        </span>
        <span className="gate-count passed">{passed} bestanden</span>
      </div>
      <ul className="gate-report-list">
        {gateReport.map((g) => (
          <li key={g.gateId} className={`gate-item ${g.status}`}>
            <span className="gate-icon">{STATUS_ICON[g.status] ?? "•"}</span>
            <div className="gate-body">
              <div className="gate-name">{g.name}</div>
              {g.message && <div className="gate-message">{g.message}</div>}
              {g.recommendedFixes && g.recommendedFixes.length > 0 && (
                <ul className="gate-fixes">
                  {g.recommendedFixes.map((fix, i) => (
                    <li key={i}>{fix}</li>
                  ))}
                </ul>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
