import { Node } from "@tiptap/core";
import { NodeViewWrapper, ReactNodeViewRenderer } from "@tiptap/react";
import type { NodeViewProps } from "@tiptap/react";
import { useEffect, useRef } from "react";

/**
 * TipTap table support without the @tiptap/extension-table packages.
 *
 * The manual generator emits Markdown tables (metadata block, change log,
 * glossary, troubleshooting). `marked` converts them to `<table>` HTML, but the
 * editor has no table extension, so TipTap dropped the table structure and
 * rendered the cells as a single flow-text line.
 *
 * The table is rendered as an atom node: the full `<table>` HTML is stored in a
 * `data-html` attribute and injected verbatim via a custom node view, so TipTap
 * never parses the rows/cells into its own schema (which would drop them).
 *
 * The cells are editable: the node view marks each `td`/`th` as
 * `contenteditable` and, on `input`/`blur`, writes the updated `<table>` HTML
 * back into the `html` attribute. The Markdown round-trip in `markdown.ts`
 * reads the same `data-html` attribute, so edits are preserved on export.
 *
 * The DOM is rebuilt whenever `node.attrs.html` changes from an external source
 * (e.g. streaming manual generation, where the table grows row by row). It is
 * NOT rebuilt when the change is the user's own edit — the `sync` handler
 * records the html it wrote back, and a matching `node.attrs.html` is treated
 * as the user's own edit so the caret/focus is preserved while typing.
 */

function TableView({ node, updateAttributes }: NodeViewProps) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  // The last table HTML we wrote back from a user edit. Used to tell external
  // changes (streaming / setContent) apart from the user's own edits: when
  // `node.attrs.html` changes to exactly this value, the change came from the
  // user, so we keep the current DOM (preserving caret/focus).
  const lastSyncedRef = useRef<string | null>(null);

  // Build (or rebuild) the table DOM whenever the node's html changes from an
  // external source. Skipped when the change is the user's own edit (the html
  // matches what we last synced), so the caret/focus is preserved while typing.
  useEffect(() => {
    const dom = wrapRef.current;
    if (!dom) return;

    const html = node.attrs.html || "";
    // The change came from the user's own edit — keep the current DOM so the
    // caret/focus is not dropped mid-edit.
    if (lastSyncedRef.current === html) return;

    dom.innerHTML = html;

    // Make every cell editable so the user can adjust generated values
    // (e.g. "open — to be set before release" in the metadata block).
    dom.querySelectorAll("td, th").forEach((cell) => {
      cell.setAttribute("contenteditable", "true");
    });

    lastSyncedRef.current = html;
  }, [node.attrs.html]);

  // Write the current table HTML back into the node attribute so the Markdown
  // export picks up the edits.
  useEffect(() => {
    const dom = wrapRef.current;
    if (!dom) return;

    const sync = () => {
      const table = dom.querySelector("table");
      if (table) {
        const html = table.outerHTML;
        lastSyncedRef.current = html;
        updateAttributes({ html });
      }
    };
    dom.addEventListener("input", sync);
    // Capture-phase blur so edits are saved even when focus moves to another
    // cell inside the same table.
    dom.addEventListener("blur", sync, true);

    return () => {
      dom.removeEventListener("input", sync);
      dom.removeEventListener("blur", sync, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <NodeViewWrapper className="manual-table-wrap">
      <div ref={wrapRef} />
    </NodeViewWrapper>
  );
}

export const Table = Node.create({
  name: "table",
  group: "block",
  atom: true,
  isolating: true,

  addAttributes() {
    return {
      html: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-html"),
        renderHTML: (attributes) => {
          if (!attributes.html) return {};
          return { "data-html": attributes.html };
        },
      },
    };
  },

  parseHTML() {
    return [{ tag: "table[data-html]" }];
  },

  renderHTML({ HTMLAttributes }) {
    // `HTMLAttributes` already carries the `data-html` produced by the `html`
    // attribute's `renderHTML` (see `addAttributes`). Reading `HTMLAttributes.html`
    // here would always be undefined and silently drop the table content on
    // serialization (getHTML → markdown round-trip), so pass the attributes
    // through as-is.
    return ["table", HTMLAttributes, ""];
  },

  addNodeView() {
    return ReactNodeViewRenderer(TableView);
  },
});

