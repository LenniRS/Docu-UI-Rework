import { Moon, Sun } from "lucide-react";
import type { Theme } from "../types";

type Props = {
  theme: Theme;
  onToggle: () => void;
};

export default function ThemeToggle({ theme, onToggle }: Props) {
  const toBright = theme !== "light";
  return (
    <button
      className="icon-btn theme-toggle"
      type="button"
      onClick={onToggle}
      aria-label={toBright ? "Switch to bright mode" : "Switch to dark mode"}
      title={toBright ? "Switch to bright mode" : "Switch to dark mode"}
    >
      {toBright ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
