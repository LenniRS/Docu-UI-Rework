import { memo, useEffect, useRef, useState } from "react";
import { Check, CloudOff, Loader2, TriangleAlert } from "lucide-react";

type SaveState = "saved" | "dirty" | "saving" | "error";

type Props = {
  state: SaveState;
};

const LABELS: Record<SaveState, string> = {
  saved: "Gespeichert",
  dirty: "Ungespeichert",
  saving: "Speichert…",
  error: "Speichern fehlgeschlagen",
};

// How long the "Gespeichert" confirmation stays visible before fading out.
const SAVED_VISIBLE_MS = 2500;

/**
 * Small save/dirty indicator shown in the editor head. Makes it clear whether
 * the manual is saved, has unsaved changes, is currently saving, or failed.
 *
 * The indicator is ALWAYS rendered (never returns null) and occupies a fixed
 * width, so showing/hiding it never changes the toolbar height or causes a
 * layout shift. The "saved" confirmation only fades out via opacity — the
 * element keeps its reserved space.
 */
export default memo(function SaveIndicator({ state }: Props) {
  const [visible, setVisible] = useState(state !== "saved");
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    if (state === "saved") {
      // Show the confirmation briefly, then fade out (opacity only — the
      // element keeps its space so the layout never shifts).
      setVisible(true);
      timer.current = window.setTimeout(() => setVisible(false), SAVED_VISIBLE_MS);
    } else {
      // dirty / saving / error stay visible.
      setVisible(true);
    }
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [state]);

  return (
    <div
      className={`save-indicator ${state}${visible ? "" : " is-hidden"}`}
      role="status"
      aria-live="polite"
    >
      {state === "saved" && <Check size={13} aria-hidden />}
      {state === "saving" && <Loader2 size={13} className="spin" aria-hidden />}
      {state === "dirty" && <CloudOff size={13} aria-hidden />}
      {state === "error" && <TriangleAlert size={13} aria-hidden />}
      <span>{LABELS[state]}</span>
    </div>
  );
});
