import { FileText, Folder, MoreHorizontal, PanelLeft, Plus, Settings } from "lucide-react";
import { useMemo, useState } from "react";

type Props = {
  collapsed: boolean;
  onToggle: () => void;
  projects: string[];
  activeProject: string | null;
  settingsOpen: boolean;
  parentReady: boolean;
  onNew: () => void;
  onSelect: (name: string) => void;
  onSettings: () => void;
  onRename: (name: string) => void;
  onDelete: (name: string) => void;
  busy?: boolean;
};

export default function Sidebar({
  collapsed,
  onToggle,
  projects,
  activeProject,
  settingsOpen,
  parentReady,
  onNew,
  onSelect,
  onSettings,
  onRename,
  onDelete,
  busy = false,
}: Props) {
  const [query, setQuery] = useState("");
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? projects.filter((p) => p.toLowerCase().includes(q)) : projects;
  }, [projects, query]);

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar-top">
        <div className="brand" aria-label="RS Docu">
          <FileText className="brand-logo" size={28} />
          <span className="brand-text">RS Docu</span>
        </div>
        <button className="icon-btn" type="button" onClick={onToggle} title="Collapse sidebar">
          <PanelLeft size={18} />
        </button>
      </div>
      <button className="new-session" type="button" onClick={onNew} disabled={!parentReady || busy} title="New Project" aria-label="New Project">
        <Plus size={16} />
        <span>New Project</span>
      </button>
      <input
        className="search"
        placeholder="Search projects"
        aria-label="Search projects"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="section-label">Projects</div>
      <div className="project-list">
        {filtered.length === 0 && !collapsed && (
          <div className="muted" style={{ padding: "8px 10px" }}>
            {parentReady ? "No projects yet" : "Set a parent folder in Settings"}
          </div>
        )}
        {filtered.map((name) => (
          <div key={name} style={{ position: "relative" }}>
            <button
              type="button"
              className={`project-row ${!settingsOpen && activeProject === name ? "active" : ""}`}
              onClick={() => {
                if (!busy) onSelect(name);
              }}
              disabled={busy}
              onContextMenu={(e) => {
                e.preventDefault();
                if (!busy) setMenuFor(name);
              }}
            >
              <Folder size={16} />
              <span className="proj-name">{name}</span>
              <span
                className="row-menu"
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.stopPropagation();
                  setMenuFor(menuFor === name ? null : name);
                }}
              >
                <MoreHorizontal size={16} />
              </span>
            </button>
            {menuFor === name && (
              <div className="menu" onMouseLeave={() => setMenuFor(null)}>
                <button
                  type="button"
                  onClick={() => {
                    setMenuFor(null);
                    onRename(name);
                  }}
                >
                  Rename
                </button>
                <button
                  type="button"
                  className="danger"
                  onClick={() => {
                    setMenuFor(null);
                    onDelete(name);
                  }}
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="sidebar-footer">
        <button
          type="button"
          className={`settings-btn ${settingsOpen ? "active" : ""}`}
          onClick={onSettings}
          disabled={busy}
        >
          <Settings size={18} />
          <span className="settings-label">Settings</span>
        </button>
      </div>
    </aside>
  );
}
