import { useEffect, useRef, useState } from "react";
import type { AppSettings, GatewayModel, Theme } from "../types";
import { ffmpegHealth, listLlmModels, llmHealth, whisperHealth } from "../lib/api";
import { resolveWriterId } from "../lib/writers";
import ThemeToggle from "./ThemeToggle";
import WritersPanel from "./WritersPanel";

type SettingsTab = "general" | "writers";

type LlmProvider = "cloud2" | "cloud1" | "ollama";

const CLOUD2_URL = "https://mock-gateway.example.invalid/v1/chat/completions";
const CLOUD1_URL = "https://mock-gateway-qual.example.invalid/v1/chat/completions";
const OLLAMA_URL = "http://localhost:11434";
const CLOUD2_DEFAULT_MODEL = "deepseek-v4-flash-0731";

function isGatewayModel(m: string | GatewayModel): m is GatewayModel {
  return typeof m === "object" && m !== null && "id" in m;
}

/** True when a model points at the Cloud1 gateway. */
function isCloud1Model(m: string | GatewayModel): boolean {
  return isGatewayModel(m) && m.url.includes("llm-gateway-qual.cloud.rsint.net");
}

/** Derive the active LLM provider from the current settings. */
function deriveProvider(settings: AppSettings): LlmProvider {
  if (settings.endpointType === "ollama") return "ollama";
  if (settings.baseUrl.includes("llm-gateway-qual.cloud.rsint.net")) return "cloud1";
  return "cloud2";
}

/** Filter a model list down to the models belonging to the given provider. */
function providerModels(models: string[] | GatewayModel[], provider: LlmProvider): string[] | GatewayModel[] {
  if (provider === "ollama") return models;
  return models.filter((m) => (provider === "cloud1" ? isCloud1Model(m) : !isCloud1Model(m))) as string[] | GatewayModel[];
}

type Props = {
  settings: AppSettings;
  theme: Theme;
  onToggleTheme: () => void;
  onChange: (next: AppSettings) => void;
  onClose: () => void;
};

export default function SettingsPage({ settings, theme, onToggleTheme, onChange, onClose }: Props) {
  const [whisper, setWhisper] = useState<{ available: boolean; detail?: string } | null>(null);
  const [llm, setLlm] = useState<{ available: boolean; detail?: string } | null>(null);
  const [ffmpeg, setFfmpeg] = useState<{ available: boolean; version?: string } | null>(null);
  const [modelsLoading, setModelsLoading] = useState(false);
  const [modelsError, setModelsError] = useState<string | null>(null);
  const [tab, setTab] = useState<SettingsTab>("general");
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const modelsReqId = useRef(0);

  function patch(partial: Partial<AppSettings>) {
    onChange({ ...settingsRef.current, ...partial });
  }

  async function refreshHealth() {
    try {
      setWhisper(await whisperHealth(settings.whisperUrl));
    } catch (err) {
      setWhisper({ available: false, detail: String(err) });
    }
    try {
      const healthKey = deriveProvider(settings) === "cloud1" ? settings.cloud1ApiKey : settings.apiKey;
      setLlm(await llmHealth(settings.baseUrl, settings.endpointType, healthKey));
    } catch (err) {
      setLlm({ available: false, detail: String(err) });
    }
    try {
      setFfmpeg(await ffmpegHealth());
    } catch (err) {
      setFfmpeg({ available: false, version: String(err) });
    }
  }

  useEffect(() => {
    void refreshHealth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.whisperUrl, settings.baseUrl, settings.endpointType]);

  async function refreshModels() {
    const reqId = ++modelsReqId.current;
    setModelsError(null);
    setModelsLoading(true);
    const { baseUrl, endpointType, apiKey } = settingsRef.current;
    try {
      const { models } = await listLlmModels(baseUrl, endpointType, apiKey);
      if (reqId !== modelsReqId.current) return; // stale response, ignore
      const current = settingsRef.current;
      const provider = deriveProvider(current);
      const filtered = providerModels(models, provider);
      const modelIds = filtered.map((m) => (isGatewayModel(m) ? m.id : m));
      // Prefer the provider's default model when the stored selection is not
      // usable for this provider (e.g. a Cloud1 model while Cloud2 is active).
      const defaultForProvider =
        provider === "cloud2" ? CLOUD2_DEFAULT_MODEL : provider === "cloud1" ? "qwen3-coder-30b" : "";
      const selectedModel =
        defaultForProvider && modelIds.includes(defaultForProvider)
          ? defaultForProvider
          : modelIds.includes(current.selectedModel)
            ? current.selectedModel
            : (filtered[0] && (isGatewayModel(filtered[0]) ? filtered[0].id : filtered[0])) || "";
      onChange({ ...current, models: filtered, selectedModel });
    } catch (err) {
      if (reqId !== modelsReqId.current) return;
      setModelsError(err instanceof Error ? err.message : String(err));
      // Clear the model list so we don't show stale models from another
      // provider when the current one can't be reached (e.g. Ollama down).
      const current = settingsRef.current;
      if (current.models.length) onChange({ ...current, models: [], selectedModel: "" });
    } finally {
      if (reqId === modelsReqId.current) setModelsLoading(false);
    }
  }

  /** Switch the active LLM provider (Cloud2 / Cloud1 / local Ollama). */
  function switchProvider(provider: LlmProvider) {
    if (provider === "ollama") {
      // Clear the model list so we don't show models from another provider
      // while the local Ollama models are being loaded.
      patch({ endpointType: "ollama", baseUrl: OLLAMA_URL, models: [], selectedModel: "" });
    } else if (provider === "cloud1") {
      patch({ endpointType: "customendpoint", baseUrl: CLOUD1_URL });
    } else {
      patch({ endpointType: "customendpoint", baseUrl: CLOUD2_URL });
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => void refreshModels(), 400);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.baseUrl, settings.endpointType, settings.apiKey]);

  return (
    <div className="settings-page">
      <div className="settings-head">
        <h1 style={{ margin: 0, fontSize: 22 }}>Settings</h1>
        <div className="settings-head-actions">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <button className="btn ghost" type="button" onClick={onClose}>
            Back
          </button>
        </div>
      </div>
      <div className="settings-tabs" role="tablist">
        <button
          className={`settings-tab ${tab === "general" ? "active" : ""}`}
          type="button"
          role="tab"
          aria-selected={tab === "general"}
          onClick={() => setTab("general")}
        >
          General
        </button>
        <button
          className={`settings-tab ${tab === "writers" ? "active" : ""}`}
          type="button"
          role="tab"
          aria-selected={tab === "writers"}
          onClick={() => setTab("writers")}
        >
          Writers
        </button>
      </div>
      {tab === "writers" ? (
        <WritersPanel
          writers={settings.writers ?? []}
          lastWriterId={settings.lastWriterId ?? ""}
          onChange={(writers) => {
            const current = settingsRef.current;
            patch({ writers, lastWriterId: resolveWriterId(writers, current.lastWriterId) });
          }}
        />
      ) : (
      <div className="settings-grid">
        <section className="card">
          <h2>Projects</h2>
          <div className="field">
            <label>Parent directory</label>
            <input
              value={settings.parentDir}
              onChange={(e) => patch({ parentDir: e.target.value })}
              placeholder="saas/data/projects"
            />
          </div>
          <p className="muted">
            Path inside the backend (with Docker, usually <code>/data/projects</code> unless the compose volume
            changes). Each New Project creates a folder here. FastAPI creates the directory if it is missing.
          </p>
          <div className="field">
            <label>Transcript language</label>
            <input value={settings.language} onChange={(e) => patch({ language: e.target.value })} />
          </div>
        </section>

        <section className="card">
          <h2>Whisper server</h2>
          <div className={`chip ${whisper == null ? "" : whisper.available ? "ok" : "bad"}`}>
            <span>
              Whisper
              <small>{settings.whisperUrl}</small>
            </span>
            <strong>{whisper == null ? "Prüfe…" : whisper.available ? "Available" : "Unavailable"}</strong>
          </div>
          {whisper && !whisper.available && whisper.detail && (
            <p className="health-detail">{whisper.detail}</p>
          )}
          <div className="field">
            <label>URL</label>
            <input value={settings.whisperUrl} onChange={(e) => patch({ whisperUrl: e.target.value })} />
          </div>
          <div className="field">
            <label>Model size</label>
            <select value={settings.whisperModel} onChange={(e) => patch({ whisperModel: e.target.value })}>
              <option value="tiny">tiny — fastest, lowest quality (~75 MB)</option>
              <option value="base">base — fast, medium quality (~142 MB)</option>
              <option value="small">small — balanced (default, ~466 MB)</option>
              <option value="medium">medium — slower, high quality (~1.5 GB)</option>
              <option value="large">large (turbo) — slowest, best quality (~1.6 GB)</option>
            </select>
            <p className="muted">
              Smaller models transcribe faster and use less memory; larger models are more accurate. The model is
              loaded on demand before each transcription.
            </p>
          </div>
          <button className="btn ghost" type="button" onClick={() => void refreshHealth()}>
            Refresh status
          </button>
          <div className={`chip ${ffmpeg == null ? "" : ffmpeg.available ? "ok" : "bad"}`} style={{ marginTop: 12 }}>
            <span>FFmpeg</span>
            <strong>{ffmpeg == null ? "Prüfe…" : ffmpeg.available ? "Available" : "Missing"}</strong>
          </div>
          {ffmpeg && !ffmpeg.available && ffmpeg.version && (
            <p className="health-detail">{ffmpeg.version}</p>
          )}
        </section>

        <section className="card llm">
          <h2>LLM</h2>
          <div className={`chip ${llm == null ? "" : llm.available ? "ok" : "bad"}`}>
            <span>
              LLM connection
              <small>{settings.baseUrl}</small>
            </span>
            <strong>{llm == null ? "Prüfe…" : llm.available ? "Available" : "Unavailable"}</strong>
          </div>
          {llm && !llm.available && llm.detail && (
            <p className="health-detail">{llm.detail}</p>
          )}
          <div className="field">
            <label>Provider</label>
            <div className="provider-switch" role="group" aria-label="LLM provider">
              <button
                type="button"
                className={`provider-btn ${deriveProvider(settings) === "cloud2" ? "active" : ""}`}
                onClick={() => switchProvider("cloud2")}
              >
                Cloud 2
              </button>
              <button
                type="button"
                className={`provider-btn ${deriveProvider(settings) === "cloud1" ? "active" : ""}`}
                onClick={() => switchProvider("cloud1")}
              >
                Cloud 1
              </button>
              <button
                type="button"
                className={`provider-btn ${deriveProvider(settings) === "ollama" ? "active" : ""}`}
                onClick={() => switchProvider("ollama")}
              >
                Local Ollama
              </button>
            </div>
            <p className="muted">
              {deriveProvider(settings) === "cloud2"
                ? "Cloud 2 is the on-site gateway and the default."
                : deriveProvider(settings) === "cloud1"
                  ? "Cloud 1 needs an API key below."
                  : "Connect to a local Ollama instance."}
            </p>
          </div>
          <div className="grid-2">
            <div className="field">
              <label>Model</label>
              <div className="row">
                <select
                  value={settings.selectedModel}
                  onChange={(e) => patch({ selectedModel: e.target.value })}
                  disabled={!settings.models.length}
                >
                  {settings.models.length === 0 && <option value="">No models</option>}
                  {settings.models.map((m) => {
                    const modelId = isGatewayModel(m) ? m.id : m;
                    const modelName = isGatewayModel(m) ? m.name : m;
                    return (
                      <option key={modelId} value={modelId}>
                        {modelName}
                      </option>
                    );
                  })}
                </select>
                <button className="btn ghost" type="button" onClick={() => void refreshModels()} disabled={modelsLoading}>
                  {modelsLoading ? "Refreshing…" : "Refresh"}
                </button>
              </div>
              {modelsError && <p className="field-error">{modelsError}</p>}
            </div>
            <div className="field">
              <label>Manual language</label>
              <select value={settings.manualLanguage} onChange={(e) => patch({ manualLanguage: e.target.value })}>
                <option>English</option>
                <option>German</option>
                <option>Chinese</option>
                <option>Arabic</option>
              </select>
            </div>
          </div>
          {deriveProvider(settings) === "ollama" && (
            <div className="field">
              <label>Ollama URL</label>
              <input value={settings.baseUrl} onChange={(e) => patch({ baseUrl: e.target.value })} />
            </div>
          )}
          {deriveProvider(settings) === "cloud1" && (
            <div className="field">
              <label>API key (Cloud 1)</label>
              <input
                type="password"
                value={settings.cloud1ApiKey}
                onChange={(e) => patch({ cloud1ApiKey: e.target.value })}
                placeholder="enter the Cloud 1 API key"
              />
            </div>
          )}
        </section>

        <details className="card advanced">
          <summary>Advanced settings</summary>
          <p className="muted">Leave these at their defaults unless you know what they do.</p>

          <div className="grid-2">
            <div className="field">
              <label>Screenshot keyword</label>
              <input value={settings.keyword} onChange={(e) => patch({ keyword: e.target.value })} />
              <p className="muted">Word that triggers a screenshot frame during transcription.</p>
            </div>
            <label className="checkbox">
              <input
                type="checkbox"
                checked={settings.suppressNst}
                onChange={(e) => patch({ suppressNst: e.target.checked })}
              />
              Suppress NST
              <span className="muted"> — suppress non-speech tokens in the transcript.</span>
            </label>
          </div>

          <h3>Decoding</h3>
          <div className="grid-2">
            <div className="field">
              <label>Temperature</label>
              <input
                type="number"
                step="0.1"
                value={settings.temperature}
                onChange={(e) => patch({ temperature: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <label>Temp inc</label>
              <input
                type="number"
                step="0.1"
                value={settings.temperatureInc}
                onChange={(e) => patch({ temperatureInc: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <label>No speech</label>
              <input
                type="number"
                step="0.1"
                value={settings.noSpeech}
                onChange={(e) => patch({ noSpeech: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <label>Entropy</label>
              <input
                type="number"
                step="0.1"
                value={settings.entropy}
                onChange={(e) => patch({ entropy: Number(e.target.value) })}
              />
            </div>
          </div>
          <div className="grid-2">
            <div className="field">
              <label>Logprob</label>
              <input
                type="number"
                step="0.1"
                value={settings.logprob}
                onChange={(e) => patch({ logprob: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <label>Prompt</label>
              <textarea value={settings.prompt} onChange={(e) => patch({ prompt: e.target.value })} />
            </div>
          </div>

          <h3>LLM connection</h3>
          <div className="field">
            <label>Base URL</label>
            <input value={settings.baseUrl} onChange={(e) => patch({ baseUrl: e.target.value })} />
          </div>
          <div className="grid-2">
            <div className="field">
              <label>Writer temperature</label>
              <input
                type="number"
                step="0.1"
                value={settings.writerTemperature}
                onChange={(e) => patch({ writerTemperature: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <label>Max tokens</label>
              <input
                type="number"
                step="256"
                value={settings.writerMaxTokens}
                onChange={(e) => patch({ writerMaxTokens: Number(e.target.value) })}
              />
            </div>
          </div>
        </details>
      </div>
      )}
    </div>
  );
}
