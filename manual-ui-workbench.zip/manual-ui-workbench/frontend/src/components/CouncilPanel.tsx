import { memo } from "react";
import { Check, Database, Locate, Sparkles, Users } from "lucide-react";
import type { CouncilData } from "../types";
import type { CouncilEdit } from "../lib/council";

type Props = {
  data: CouncilData | null;
  loading: boolean;
  running: boolean;
  /** The latest edit proposal from the chat, shown directly under the points. */
  currentEdit: CouncilEdit | null;
  applying: boolean;
  onRun: () => void;
  onApplyEdit: (edit: CouncilEdit) => Promise<void>;
  onApplySuggestion: (suggestion: string, passage: string, pointTitle?: string) => Promise<void>;
  onApplyAllSuggestions: () => Promise<void>;
  /** Jump to a passage in the manual and highlight it. */
  onJumpToPassage?: (point: { passage: string; section?: string; kind?: string }) => void;
  /** Open the chat to add missing data (for missing_info points). */
  onAddData?: (point: { title: string; needsInfo?: string }) => void;
};

export default memo(function CouncilPanel({
  data,
  loading,
  running,
  currentEdit,
  applying,
  onRun,
  onApplyEdit,
  onApplySuggestion,
  onApplyAllSuggestions,
  onJumpToPassage,
  onAddData,
}: Props) {
  const points = data?.points || [];
  const consensus = Boolean(data?.consensus);
  const status = data?.status || "none";

  // Only points with an adoptable suggestion count for "apply all". A
  // missing_info point has no sensible suggestion to adopt — the fix is to add
  // the missing data, not to rewrite existing text.
  const suggestions = points.filter((p) => p.suggestion && p.kind !== "missing_info");

  return (
    <div className="council">
      <div className="council-head">
        <span className="council-title">
          <Users size={14} />
          Council-Review
        </span>
        {!loading && (
          <button
            type="button"
            className="council-run"
            onClick={onRun}
            disabled={running}
          >
            <Sparkles size={14} />
            {running ? "Council läuft…" : status === "none" ? "Council starten" : "Council neu starten"}
          </button>
        )}
      </div>

      {/* Points are always visible as a flat, open list (no boxes). */}
      {!loading && data && status !== "none" && (
        <div className="council-summary-list">
          {consensus ? (
            <div className="council-consensus">
              <Check size={16} />
              <span>Konsens erreicht — keine Einwände.</span>
            </div>
          ) : (
            <ol className="council-points-list">
              {points.map((p, i) => {
                const isMissingInfo = p.kind === "missing_info";
                return (
                  <li key={i} className="council-point">
                    <div className="council-point-title">{p.title}</div>
                    {isMissingInfo ? (
                      <>
                        {p.needsInfo && (
                          <div className="council-point-needs">
                            <span className="council-point-needs-label">Benötigte Info:</span>{" "}
                            {p.needsInfo}
                          </div>
                        )}
                        {(onAddData || (onJumpToPassage && p.passage?.trim())) && (
                          <div className="council-point-actions">
                            {onJumpToPassage && p.passage?.trim() && (
                              <button
                                type="button"
                                className="council-jump"
                                onClick={() =>
                                  onJumpToPassage?.({
                                    passage: p.passage || "",
                                    section: p.section,
                                    kind: p.kind,
                                  })
                                }
                              >
                                <Locate size={13} />
                                Im Manual anzeigen
                              </button>
                            )}
                            {onAddData && (
                              <button
                                type="button"
                                className="council-add-data"
                                onClick={() =>
                                  onAddData({
                                    title: p.title,
                                    needsInfo: p.needsInfo || p.description || "",
                                  })
                                }
                              >
                                <Database size={13} />
                                Daten hinzufügen
                              </button>
                            )}
                          </div>
                        )}
                      </>
                    ) : (
                      <>
                        {p.suggestion && (
                          <div className="council-point-suggestion">
                            <span className="council-point-suggestion-label">Vorschlag:</span>{" "}
                            {p.suggestion}
                          </div>
                        )}
                        {(p.suggestion || (onJumpToPassage && p.passage?.trim())) && (
                          <div className="council-point-actions">
                            {onJumpToPassage && p.passage?.trim() && (
                              <button
                                type="button"
                                className="council-jump"
                                onClick={() =>
                                  onJumpToPassage?.({
                                    passage: p.passage || "",
                                    section: p.section,
                                    kind: p.kind,
                                  })
                                }
                              >
                                <Locate size={13} />
                                Im Manual anzeigen
                              </button>
                            )}
                            {p.suggestion && (
                              <button
                                type="button"
                                className="council-apply"
                                disabled={applying}
                                onClick={() =>
                                  void onApplySuggestion(p.suggestion || "", p.passage || "", p.title)
                                }
                              >
                                {applying ? "Übernehme…" : "Übernehmen"}
                              </button>
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </li>
                );
              })}
            </ol>
          )}
        </div>
      )}

      <div className="council-body">
        {loading && <p className="muted">Lade Council…</p>}
        {!loading && !data && <p className="muted">Kein Council verfügbar.</p>}
        {!loading && data && (
          <>
            {status === "none" && (
              <div className="council-empty">
                <p className="muted">
                  Der Council bewertet das Manual aus 4 Perspektiven und nennt die wichtigsten
                  Punkte bis zum Konsens.
                </p>
              </div>
            )}

            {status !== "none" && (
              <>
                {status === "partial" && (
                  <p className="council-partial muted">
                    Einige Rollen konnten nicht bewertet werden. Ergebnis ist unvollständig.
                  </p>
                )}

                {/* Apply all suggestions at once. */}
                {suggestions.length > 0 && (
                  <div className="council-apply-all">
                    <button
                      type="button"
                      className="council-apply-all-btn"
                      disabled={applying}
                      onClick={() => void onApplyAllSuggestions()}
                    >
                      {applying ? "Übernehme…" : `Alle Vorschläge übernehmen (${suggestions.length})`}
                    </button>
                  </div>
                )}

                {/* Proposed change — directly under the council points. */}
                {currentEdit && (
                  <div className="council-proposed">
                    <div className="council-proposed-head">
                      <span>
                        Vorgeschlagene Änderung
                        {currentEdit.type === "replace_section"
                          ? ` — Abschnitt ${currentEdit.section}`
                          : currentEdit.type === "replace_section_body"
                            ? ` — Inhalt von Abschnitt ${currentEdit.section}`
                            : currentEdit.type === "rename_heading"
                              ? ` — Überschrift von Abschnitt ${currentEdit.section}`
                              : ""}
                      </span>
                    </div>
                    <details className="council-edit-diff" open>
                      <summary>Änderung anzeigen</summary>
                      {currentEdit.type === "replace" && (
                        <div className="council-edit-old">
                          <div className="council-edit-tag">Vorher</div>
                          <pre>{currentEdit.old_text}</pre>
                        </div>
                      )}
                      <div className="council-edit-new">
                        <div className="council-edit-tag">Nachher</div>
                        <pre>
                          {currentEdit.type === "replace_section"
                            ? currentEdit.new_text
                            : currentEdit.type === "replace_section_body"
                              ? currentEdit.new_body
                              : currentEdit.type === "rename_heading"
                                ? currentEdit.new_heading
                                : currentEdit.new_text}
                        </pre>
                      </div>
                    </details>
                    <button
                      type="button"
                      className="council-apply"
                      disabled={applying}
                      onClick={() => void onApplyEdit(currentEdit)}
                    >
                      {applying ? "Übernehme…" : "Übernehmen"}
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
});

