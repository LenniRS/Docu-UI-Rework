import { memo, useCallback, useEffect, useRef, useState, type CSSProperties, type MutableRefObject } from "react";
import { Check, Loader2, PictureInPicture2 } from "lucide-react";
import { videoUrl } from "../lib/api";
import type { CouncilData } from "../types";
import type { CouncilEdit } from "../lib/council";
import type { OperationState } from "../lib/operations";
import CouncilPanel from "./CouncilPanel";

type Props = {
  parentDir: string;
  projectName: string;
  hasVideo: boolean;
  videoKey: number;
  videoRef: MutableRefObject<HTMLVideoElement | null>;
  onDuration: (duration: number) => void;
  council: CouncilData | null;
  councilLoading: boolean;
  councilRunning: boolean;
  currentEdit: CouncilEdit | null;
  applying: boolean;
  onCouncilRun: () => void;
  onCouncilApplyEdit: (edit: CouncilEdit) => Promise<void>;
  onCouncilApplySuggestion: (suggestion: string, passage: string, pointTitle?: string) => Promise<void>;
  onCouncilApplyAllSuggestions: () => Promise<void>;
  onCouncilJumpToPassage?: (point: { passage: string; section?: string; kind?: string }) => void;
  onCouncilAddData?: (point: { title: string; needsInfo?: string }) => void;
  /** Centralized operation state (drives video processing progress). */
  operation?: OperationState | null;
  /** Abort the running generation pipeline. */
  onAbort?: () => void;
  /** Re-run generation after a failure (opens the generate dialog). */
  onRetry?: () => void;
  style?: CSSProperties;
};

function pipSupported() {
  return typeof document !== "undefined" && Boolean(document.pictureInPictureEnabled);
}

type StepState = "done" | "active" | "upcoming";
type ProgressStep = { label: string; state: StepState };

/**
 * Derive a clean, hierarchical progress presentation from the operation state:
 * a main title (overall process), a current-step line (with percent), and an
 * ordered step list where each step is exactly one of done / active / upcoming.
 * This avoids the previous contradictions (e.g. "✓ Transkription läuft") and
 * the redundancy between the title and the step list.
 */
function buildProgress(op: OperationState): {
  title: string;
  current: string;
  percent: number | null;
  steps: ProgressStep[];
} {
  const percent = op.progress?.percent != null ? Math.round(op.progress.percent) : null;
  const pct = percent != null ? ` ${percent}%` : "";

  if (op.type === "video_upload") {
    return {
      title: "Video wird hochgeladen",
      current: `Lade Video hoch…${pct}`,
      percent,
      steps: [],
    };
  }

  if (op.type === "video_processing") {
    if (op.step === "transcribing") {
      return {
        title: "Video wird verarbeitet",
        current: `Transkription läuft…${pct}`,
        percent,
        steps: [
          { label: "Transkription läuft", state: "active" },
          { label: "Screenshots werden extrahiert", state: "upcoming" },
          { label: "Manual wird geschrieben", state: "upcoming" },
          { label: "Editor wird aktualisiert", state: "upcoming" },
        ],
      };
    }
    // video_processing, writing phase (transcription already done)
    return {
      title: "Manual wird generiert",
      current: `Schreibe Manual…${pct}`,
      percent,
      steps: [
        { label: "Transkription abgeschlossen", state: "done" },
        { label: "Screenshots extrahiert", state: "done" },
        { label: "Manual wird geschrieben", state: "active" },
        { label: "Editor wird aktualisiert", state: "upcoming" },
      ],
    };
  }

  // manual_generation (reusable transcript, no transcription step)
  return {
    title: "Manual wird generiert",
    current: `Schreibe Manual…${pct}`,
    percent,
    steps: [
      { label: "Manual wird geschrieben", state: "active" },
      { label: "Editor wird aktualisiert", state: "upcoming" },
    ],
  };
}

export default memo(function MediaPanel({
  parentDir,
  projectName,
  hasVideo,
  videoKey,
  videoRef,
  onDuration,
  council,
  councilLoading,
  councilRunning,
  currentEdit,
  applying,
  onCouncilRun,
  onCouncilApplyEdit,
  onCouncilApplySuggestion,
  onCouncilApplyAllSuggestions,
  onCouncilJumpToPassage,
  onCouncilAddData,
  operation,
  onAbort,
  onRetry,
  style,
}: Props) {
  const [inPip, setInPip] = useState(false);
  const [canPip, setCanPip] = useState(() => pipSupported());
  const pipListeners = useRef<{ video: HTMLVideoElement; onEnter: () => void; onLeave: () => void } | null>(null);

  const unbindPip = useCallback(() => {
    const bound = pipListeners.current;
    if (!bound) return;
    bound.video.removeEventListener("enterpictureinpicture", bound.onEnter);
    bound.video.removeEventListener("leavepictureinpicture", bound.onLeave);
    pipListeners.current = null;
  }, []);

  const bindVideo = useCallback(
    (el: HTMLVideoElement | null) => {
      unbindPip();
      videoRef.current = el;
      if (!el) {
        setInPip(false);
        return;
      }
      const onEnter = () => setInPip(true);
      const onLeave = () => setInPip(false);
      el.addEventListener("enterpictureinpicture", onEnter);
      el.addEventListener("leavepictureinpicture", onLeave);
      pipListeners.current = { video: el, onEnter, onLeave };
      setInPip(document.pictureInPictureElement === el);
    },
    [unbindPip, videoRef],
  );

  useEffect(() => {
    setCanPip(pipSupported());
    return () => unbindPip();
  }, [unbindPip]);

  async function togglePip() {
    const video = videoRef.current;
    if (!video || !pipSupported()) return;
    try {
      if (document.pictureInPictureElement === video) {
        await document.exitPictureInPicture();
      } else {
        await video.requestPictureInPicture();
      }
    } catch {
      /* gesture rejected or PiP unavailable */
    }
  }

  return (
    <aside className="media-col" style={style}>
      <h3>Video</h3>
      <div className="player">
        {hasVideo ? (
          <div className="player-frame">
            <video
              key={videoKey}
              ref={bindVideo}
              controls
              disablePictureInPicture={false}
              src={videoUrl(parentDir, projectName, videoKey)}
              onLoadedMetadata={(e) => {
                const duration = e.currentTarget.duration;
                if (Number.isFinite(duration)) onDuration(duration);
              }}
              onDurationChange={(e) => {
                const duration = e.currentTarget.duration;
                if (Number.isFinite(duration)) onDuration(duration);
              }}
            />
            {canPip && (
              <button
                type="button"
                className={`pip-btn${inPip ? " on" : ""}`}
                title={inPip ? "Exit Picture-in-Picture" : "Picture-in-Picture"}
                aria-label={inPip ? "Exit Picture-in-Picture" : "Picture-in-Picture"}
                aria-pressed={inPip}
                onClick={() => void togglePip()}
              >
                <PictureInPicture2 size={16} />
              </button>
            )}
          </div>
        ) : (
          <p className="muted">Upload a source video to preview it here.</p>
        )}
      </div>
      {operation &&
        (operation.type === "video_processing" ||
          operation.type === "video_upload" ||
          operation.type === "manual_generation") &&
        (operation.status === "running" ||
          operation.status === "success" ||
          operation.status === "error") &&
        (() => {
          if (operation.status === "success") {
            const doneTitle =
              operation.type === "video_upload" ? "Video hochgeladen" : "Manual generiert";
            return (
              <div className="video-progress success" role="status" aria-live="polite">
                <div className="video-progress-title">{doneTitle}</div>
                <div className="video-progress-current">Alle Schritte abgeschlossen</div>
              </div>
            );
          }
          if (operation.status === "error") {
            const failTitle =
              operation.type === "video_upload"
                ? "Upload fehlgeschlagen"
                : "Generierung fehlgeschlagen";
            return (
              <div className="video-progress error" role="alert" aria-live="assertive">
                <div className="video-progress-title">{failTitle}</div>
                <div className="video-progress-error">
                  {operation.error || "Unbekannter Fehler"}
                </div>
                {onRetry && operation.type !== "video_upload" && (
                  <div className="video-progress-actions">
                    <button className="btn ghost" type="button" onClick={onRetry}>
                      Erneut versuchen
                    </button>
                  </div>
                )}
              </div>
            );
          }
          const { title, current, percent, steps } = buildProgress(operation);
          return (
            <div className="video-progress" role="status" aria-live="polite">
              <div className="video-progress-title">{title}</div>
              <div className="video-progress-current">
                <span>{current}</span>
              </div>
              {percent != null && (
                <div
                  className="progress-bar"
                  role="progressbar"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={percent}
                >
                  <div className="progress-bar-fill" style={{ width: `${percent}%` }} />
                </div>
              )}
              {steps.length > 0 && (
                <ul className="video-progress-steps">
                  {steps.map((s) => (
                    <li key={s.label} className={s.state}>
                      {s.state === "done" ? (
                        <Check size={11} aria-hidden />
                      ) : s.state === "active" ? (
                        <Loader2 size={11} className="spin" aria-hidden />
                      ) : (
                        <span className="video-progress-step-dot" aria-hidden />
                      )}
                      {s.label}
                    </li>
                  ))}
                </ul>
              )}
              {onAbort && (
                <div className="video-progress-actions">
                  <button className="btn ghost" type="button" onClick={onAbort}>
                    Abbrechen
                  </button>
                </div>
              )}
            </div>
          );
        })()}
      <CouncilPanel
        data={council}
        loading={councilLoading}
        running={councilRunning}
        currentEdit={currentEdit}
        applying={applying}
        onRun={onCouncilRun}
        onApplyEdit={onCouncilApplyEdit}
        onApplySuggestion={onCouncilApplySuggestion}
        onApplyAllSuggestions={onCouncilApplyAllSuggestions}
        onJumpToPassage={onCouncilJumpToPassage}
        onAddData={onCouncilAddData}
      />
    </aside>
  );
});
