import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, Minus, RotateCcw, Send, Trash2, X } from "lucide-react";
import type { CouncilChatMessage, ReferencedContext } from "../types";
import { parseAssistantReply } from "../lib/council";
import type { OperationState } from "../lib/operations";
import { chatStatusText } from "../lib/operations";
import OperationCard from "./OperationCard";

// Max height the input grows to before it starts scrolling internally.
const MAX_INPUT_HEIGHT = 160;

type Props = {
  messages: CouncilChatMessage[];
  chatBusy: boolean;
  onSend: (messages: CouncilChatMessage[]) => Promise<string>;
  /** Referenced passages shown as visible context attachments above the input. */
  contexts: ReferencedContext[];
  onRemoveContext: (index: number) => void;
  /** Whether referenced context is kept after sending (for follow-up questions). */
  keepContext: boolean;
  onToggleKeepContext: () => void;
  /** Incremented to open the chat from outside (e.g. when referencing text). */
  openSignal?: number;
  /** Whether the last chat-applied manual change can be undone. */
  canUndo?: boolean;
  /** Undo the last chat-applied manual change (back button). */
  onUndo?: () => void;
  /** Clear the chat thread (empties the persisted conversation). */
  onClear?: () => void;
  /** Called when the chat expands or collapses (so the editor can reserve space). */
  onExpandedChange?: (expanded: boolean) => void;
  /** Centralized operation state (drives the precise status + OperationCard). */
  operation?: OperationState | null;
};

/**
 * Expandable Chat Composer — a compact chat bar at the bottom of the screen
 * that expands into a full chat window on focus/click/typing.
 *
 * Collapsed: a slim input bar (textarea + send button).
 * Expanded: a larger window with a header, the message thread, an optional
 * referenced-context area and the input pinned at the bottom.
 *
 * The transition between the two states is animated (height, border-radius).
 * Typed text is preserved when collapsing.
 */
export default function ChatWindow({
  messages,
  chatBusy,
  onSend,
  contexts,
  onRemoveContext,
  keepContext,
  onToggleKeepContext,
  openSignal = 0,
  canUndo = false,
  onUndo,
  onClear,
  onExpandedChange,
  operation = null,
}: Props) {
  const [expanded, setExpanded] = useState(false);
  const [input, setInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const threadRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  // Report the expanded state so the parent can reserve space for the chat
  // window (otherwise the expanded chat covers the bottom of the manual).
  useEffect(() => {
    onExpandedChange?.(expanded);
  }, [expanded, onExpandedChange]);

  // Expand the chat when the openSignal changes (e.g. a text reference was added).
  useEffect(() => {
    if (openSignal > 0) setExpanded(true);
  }, [openSignal]);

  // Keep the thread scrolled to the bottom when messages change.
  useEffect(() => {
    const el = threadRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, chatBusy]);

  // Focus the input when the chat expands.
  useEffect(() => {
    if (expanded) inputRef.current?.focus();
  }, [expanded]);

  // Collapse on Escape.
  useEffect(() => {
    if (!expanded) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setExpanded(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [expanded]);

  const collapse = useCallback(() => {
    setExpanded(false);
    setError(null);
  }, []);

  // Grow the textarea with its content (ChatGPT-style) so the input expands
  // as the user types, up to a max height after which it scrolls.
  const resizeInput = useCallback(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, MAX_INPUT_HEIGHT)}px`;
  }, []);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || chatBusy) return;
    setError(null);
    const userMsg: CouncilChatMessage = { role: "user", content: text };
    const next = [...messages, userMsg];
    setInput("");
    // Reset the input height after sending.
    requestAnimationFrame(() => {
      const el = inputRef.current;
      if (el) el.style.height = "auto";
    });
    try {
      // The parent (Workspace) streams the reply, appends the assistant message
      // and updates the edit proposal — nothing to do here beyond awaiting.
      await onSend(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, [input, chatBusy, messages, onSend]);

  return (
    <div className="chat-composer-wrap">
      {/* Referenced context — shown ABOVE the chat window, not inside it. */}
      {expanded && contexts.length > 0 && (
        <div className="chat-context">
          <div className="chat-context-head">
            <span className="chat-context-title">Verwendeter Kontext</span>
            <label className="chat-context-keep">
              <input
                type="checkbox"
                checked={keepContext}
                onChange={onToggleKeepContext}
              />
              <span>nach Senden behalten</span>
            </label>
          </div>
          <div className="chat-context-list">
            {contexts.map((ctx, i) => (
              <div key={i} className="chat-context-card">
                <div className="chat-context-meta">
                  <span className="chat-context-source">{ctx.source}</span>
                  {ctx.startLine != null && (
                    <span className="chat-context-pos">
                      Zeile {ctx.startLine}
                      {ctx.endLine != null && ctx.endLine !== ctx.startLine
                        ? `–${ctx.endLine}`
                        : ""}
                    </span>
                  )}
                </div>
                <div className="chat-context-text">{ctx.text}</div>
                <button
                  type="button"
                  className="chat-context-remove"
                  onClick={() => onRemoveContext(i)}
                  title="Kontext entfernen"
                  aria-label="Kontext entfernen"
                >
                  <X size={13} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className={`chat-composer${expanded ? " expanded" : ""}`}>
        {/* Expanded header — only visible when expanded. */}
        {expanded && (
          <div className="chat-header">
            <span className="chat-header-title">
              {contexts.length > 0 ? contexts[0].text : "Mit KI bearbeiten"}
            </span>
            <div className="chat-header-actions">
              {canUndo && onUndo && (
                <button
                  type="button"
                  className="chat-header-btn chat-undo"
                  onClick={onUndo}
                  title="Letzte Änderung rückgängig machen"
                  aria-label="Letzte Änderung rückgängig machen"
                >
                  <RotateCcw size={16} />
                </button>
              )}
              {onClear && messages.length > 0 && (
                <button
                  type="button"
                  className="chat-header-btn chat-clear"
                  onClick={onClear}
                  title="Chat-Verlauf löschen"
                  aria-label="Chat-Verlauf löschen"
                >
                  <Trash2 size={16} />
                </button>
              )}
              <button
                type="button"
                className="chat-header-btn"
                onClick={collapse}
                title="Minimieren"
                aria-label="Chat minimieren"
              >
                <Minus size={16} />
              </button>
              <button
                type="button"
                className="chat-header-btn"
                onClick={collapse}
                title="Schließen"
                aria-label="Chat schließen"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        {/* Message thread — only visible when expanded and there is content. */}
        {expanded && (messages.length > 0 || chatBusy) && (
          <div className="chat-thread" ref={threadRef}>
            <div className="chat-thread-body">
              {messages.map((m, i) => {
                if (m.role === "user") {
                  return (
                    <div key={i} className="council-msg user">
                      <div className="council-msg-bubble">{m.content}</div>
                    </div>
                  );
                }
                const parsed = parseAssistantReply(m.content);
                return (
                  <div key={i} className="council-msg assistant">
                    <div className="council-msg-bubble">
                      <div className="council-msg-text">{parsed.text}</div>
                    </div>
                  </div>
                );
              })}
              {chatBusy && (
                <div className="council-msg assistant">
                  {operation && operation.type === "ai_edit" ? (
                    <OperationCard operation={operation} canUndo={canUndo} onUndo={onUndo} />
                  ) : (
                    <div className="council-msg-bubble council-typing">
                      <Loader2 size={14} className="spin" />
                      <span>{chatStatusText(operation)}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {error && <div className="chat-error">{error}</div>}

        {/* Input bar — always visible, collapsed or expanded. */}
        <div className="chat-input-bar">
          <textarea
            ref={inputRef}
            value={input}
            placeholder="Frage stellen oder Änderung vorschlagen…"
            onChange={(e) => {
              setInput(e.target.value);
              resizeInput();
            }}
            onFocus={() => setExpanded(true)}
            onClick={() => setExpanded(true)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            rows={1}
          />
          <button
            type="button"
            className="chat-send"
            disabled={chatBusy || !input.trim()}
            onClick={() => void send()}
            title="Senden"
            aria-label="Senden"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
