import { NodeViewWrapper, ReactNodeViewRenderer } from "@tiptap/react";
import Image from "@tiptap/extension-image";
import type { NodeViewProps } from "@tiptap/react";
import { Camera, LocateFixed, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { filenameFromSrc } from "../lib/markdown";
import { formatOverlayTime } from "../lib/time";

const DELTAS = [-1, -0.5, -0.1, 0.1, 0.5, 1];

// How long to wait after the last nudge before committing the timestamp to the
// backend/global state. Rapid clicks coalesce into a single commit.
const COMMIT_DEBOUNCE_MS = 500;

export type FrameHandlers = {
  onShift: (filename: string, delta: number, currentTime?: number) => Promise<string | void>;
  onDelete: (filename: string) => Promise<void>;
  onSeek: (filename: string) => void;
  onReplace: (filename: string) => Promise<string | void>;
  timestamps: Record<string, number>;
  videoDuration: number;
  hasVideo: boolean;
};

let handlers: FrameHandlers = {
  onShift: async () => undefined,
  onDelete: async () => undefined,
  onSeek: () => undefined,
  onReplace: async () => undefined,
  timestamps: {},
  videoDuration: 0,
  hasVideo: false,
};

const listeners = new Set<() => void>();

export function setFrameHandlers(next: FrameHandlers) {
  handlers = next;
  listeners.forEach((fn) => fn());
}

// Set right before a frame's image `src` is refreshed programmatically (after
// a timestamp nudge / replace). EditorPane's `onUpdate` consumes this to skip
// the full markdown re-serialization: a src refresh is a targeted node patch,
// not a document content edit, and re-serializing the whole document on every
// nudge is what causes the visible stutter.
let suppressNextSrcUpdateFlag = false;
export function suppressNextSrcUpdate() {
  suppressNextSrcUpdateFlag = true;
}
export function consumeSuppressedSrcUpdate(): boolean {
  const s = suppressNextSrcUpdateFlag;
  suppressNextSrcUpdateFlag = false;
  return s;
}

/**
 * Subscribe to frame-handler updates, but only re-render this FrameView when
 * the data it actually shows changed: its own timestamp, video duration, or
 * video availability. Other frames' timestamp changes must not re-render this
 * one (avoids a full re-render of every screenshot on every nudge).
 */
function useFrameHandlers(filename: string): FrameHandlers {
  const [, bump] = useState(0);
  const last = useRef({ time: handlers.timestamps[filename], duration: handlers.videoDuration, hasVideo: handlers.hasVideo });
  useEffect(() => {
    const fn = () => {
      const t = handlers.timestamps[filename];
      const d = handlers.videoDuration;
      const h = handlers.hasVideo;
      if (t === last.current.time && d === last.current.duration && h === last.current.hasVideo) return;
      last.current = { time: t, duration: d, hasVideo: h };
      bump((n) => n + 1);
    };
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }, [filename]);
  return handlers;
}

function FrameView({ node, updateAttributes, deleteNode }: NodeViewProps) {
  const src = String(node.attrs.src || "");
  const alt = String(node.attrs.alt || "");
  const filename = filenameFromSrc(src, alt);
  const { onShift, onDelete, onSeek, onReplace, timestamps, videoDuration, hasVideo } = useFrameHandlers(filename);
  const serverTime = timestamps[filename];
  const [replacing, setReplacing] = useState(false);

  // Optimistic local timestamp: updated immediately on nudge so the UI reacts
  // without waiting for the debounced backend commit. Falls back to the server
  // value when no local nudge is pending.
  const [localTime, setLocalTime] = useState<number | null>(null);
  const commitTimer = useRef<number | null>(null);
  const pendingDelta = useRef<number>(0);

  // When the server timestamp changes (e.g. a different screenshot is loaded or
  // the external value is replaced), reset the local optimistic state so we do
  // not keep showing a stale value.
  useEffect(() => {
    setLocalTime(null);
    pendingDelta.current = 0;
    if (commitTimer.current) window.clearTimeout(commitTimer.current);
  }, [filename, serverTime]);

  const time = localTime ?? serverTime;
  const hasTime = time != null && Number.isFinite(time);

  function handleNudge(delta: number) {
    if (!hasTime) return;
    // Update the local optimistic timestamp immediately for instant feedback.
    setLocalTime((prev) => {
      const base = prev ?? serverTime ?? 0;
      const next = Math.min(Math.max(base + delta, 0), videoDuration || Number.MAX_SAFE_INTEGER);
      pendingDelta.current += delta;
      return next;
    });
    // Debounce the backend commit: rapid clicks coalesce into one request with
    // the final accumulated delta.
    if (commitTimer.current) window.clearTimeout(commitTimer.current);
    commitTimer.current = window.setTimeout(() => {
      const deltaToCommit = pendingDelta.current;
      pendingDelta.current = 0;
      void onShift(filename, deltaToCommit, serverTime)
        .then((url) => {
          if (url) {
            // Refresh the displayed frame image. This is a targeted node patch;
            // suppress the editor's markdown re-serialization so the whole
            // document is not rebuilt on every nudge.
            suppressNextSrcUpdate();
            updateAttributes({ src: url });
            // Safety: if the update produced no doc change (identical src),
            // clear the flag so a subsequent real edit is not suppressed.
            queueMicrotask(() => consumeSuppressedSrcUpdate());
          }
        })
        .catch((err) => {
          alert(err instanceof Error ? err.message : String(err));
        });
    }, COMMIT_DEBOUNCE_MS);
  }

  useEffect(() => {
    return () => {
      if (commitTimer.current) window.clearTimeout(commitTimer.current);
    };
  }, []);

  return (
    <NodeViewWrapper className="frame-wrap" data-filename={filename}>
      <img src={src} alt={alt || filename} />
      <div className="frame-overlay" contentEditable={false}>
        <div className="frame-times">
          {DELTAS.map((d) => (
            <button
              key={d}
              type="button"
              disabled={!hasVideo || !hasTime}
              onClick={() => handleNudge(d)}
            >
              {d > 0 ? `+${d}s` : `${d}s`}
            </button>
          ))}
          <button
            type="button"
            className="frame-icon"
            title="Jump video to this timestamp"
            aria-label="Jump video to this timestamp"
            disabled={!hasVideo || !hasTime}
            onClick={() => onSeek(filename)}
          >
            <LocateFixed size={14} />
          </button>
          <button
            type="button"
            className="frame-icon"
            title="Replace with current video frame"
            aria-label="Replace with current video frame"
            disabled={!hasVideo || replacing}
            onClick={async () => {
              setReplacing(true);
              try {
                const url = await onReplace(filename);
                if (url) {
                  suppressNextSrcUpdate();
                  updateAttributes({ src: url });
                  queueMicrotask(() => consumeSuppressedSrcUpdate());
                }
              } catch (err) {
                alert(err instanceof Error ? err.message : String(err));
              } finally {
                setReplacing(false);
              }
            }}
          >
            <Camera size={14} />
          </button>
        </div>
        <button
          type="button"
          className="frame-delete"
          title="Delete"
          aria-label="Delete frame"
          onClick={async () => {
            await onDelete(filename);
            deleteNode();
          }}
        >
          <Trash2 size={16} />
        </button>
        {hasTime && (
          <div className="frame-timestamp">{formatOverlayTime(time, videoDuration)}</div>
        )}
      </div>
    </NodeViewWrapper>
  );
}

export const FrameImage = Image.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      src: { default: null },
      alt: { default: null },
      title: { default: null },
    };
  },
  addNodeView() {
    return ReactNodeViewRenderer(FrameView);
  },
});
