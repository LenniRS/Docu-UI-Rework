import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Sidebar from "./components/Sidebar";
import SettingsPage from "./components/SettingsPage";
import Workspace from "./components/Workspace";
import Modal from "./components/Modal";
import GenerateManualDialog from "./components/GenerateManualDialog";
import ThemeToggle from "./components/ThemeToggle";
import type { AppSettings, DownloadFormat, PaneMode, ProjectRecord, Stage, Theme } from "./types";
import {
  createProject,
  deletePicture,
  deleteProject,
  downloadExport,
  extractPicture,
  getConfig,
  getProject,
  listProjects,
  renameProject,
  saveDocument,
  shiftPicture,
  transcribeStream,
  uploadVideo,
  writeManualSmm,
} from "./lib/api";
import {
  applyConfigDefaults,
  applyTheme,
  deleteProjectRecord,
  loadActiveProject,
  loadCollapsed,
  loadPaneMode,
  loadProjectRecord,
  loadSettings,
  loadStage,
  loadTheme,
  renameProjectRecord,
  saveActiveProject,
  saveCollapsed,
  savePaneMode,
  saveProjectRecord,
  saveSettings,
  saveStage,
  saveTheme,
} from "./lib/storage";
import { hasReusableTranscript } from "./lib/transcriptReuse";
import { mergeIncomingFiles, timestampsFromFiles } from "./lib/time";
import { useOperationState } from "./lib/operations";

function emptyRecord(name: string): ProjectRecord {
  return {
    markdown: "",
    transcript: "",
    title: name,
    outputName: name,
    files: [],
    timestamps: {},
    hasVideo: false,
    screenshotCount: 0,
    headingNumbering: false,
  };
}

/**
 * Replace the `src` of the markdown image whose URL contains `filename` with
 * `newSrc`. Used to keep the manual's image URL in sync after a frame timestamp
 * nudge / replace, without re-serializing the whole document.
 */
function replaceImageSrc(markdown: string, filename: string, newSrc: string): string {
  return markdown.replace(/!\[([^\]]*)\]\(([^)]*)\)/g, (match, alt: string, src: string) => {
    if (src.includes(filename)) return `![${alt}](${newSrc})`;
    return match;
  });
}

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [pane, setPane] = useState<PaneMode>(() => loadPaneMode());
  const [stage, setStage] = useState<Stage>(() => {
    // A persisted "writing"/"transcribing" stage means a generation was
    // interrupted (e.g. the page was closed mid-run). No generation is running
    // after a reload, so reset to "editing" to avoid a stuck "Generating…".
    const saved = loadStage();
    return saved === "writing" || saved === "transcribing" ? "editing" : saved;
  });
  const [collapsed, setCollapsed] = useState(() => loadCollapsed());
  const [theme, setTheme] = useState<Theme>(() => loadTheme());
  // Incremented after each successful manual generation so Workspace can
  // trigger the automatic council review of the freshly generated manual.
  const [generationCount, setGenerationCount] = useState(0);
  const [projects, setProjects] = useState<string[]>([]);
  const [active, setActive] = useState<string | null>(() => loadActiveProject());
  const [record, setRecord] = useState<ProjectRecord | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [videoKey, setVideoKey] = useState(0);
  const [downloading, setDownloading] = useState<DownloadFormat | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const recordRef = useRef<ProjectRecord | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const [modal, setModal] = useState<
    | { type: "create" }
    | { type: "rename"; name: string }
    | { type: "delete"; name: string }
    | null
  >(null);
  const [draftName, setDraftName] = useState("");
  const [generateOpen, setGenerateOpen] = useState(false);
  // Centralized operation state driving the global ActivityIndicator, chat
  // OperationCard, editor section highlight, save indicator and video progress.
  const op = useOperationState();
  // Save/dirty state: "saved" | "dirty" | "saving" | "error". Driven by the
  // debounced save in scheduleSave so the UI reflects actual persistence.
  const [saveState, setSaveState] = useState<"saved" | "dirty" | "saving" | "error">("saved");
  const saveTimer = useRef<number | null>(null);
  const pictureMutationChain = useRef(Promise.resolve());
  const timestampsRef = useRef<Record<string, number>>({});
  const parentReady = Boolean(settings.parentDir.trim());
  // The app is "busy" (blocks new operations / project switching) only while a
  // manual-generation pipeline is running. Progress is shown in the box under
  // the video (MediaPanel), so there is no separate central overlay anymore.
  const busy =
    op.operation !== null &&
    op.operation.status === "running" &&
    (op.operation.type === "video_processing" || op.operation.type === "manual_generation");

  function isAbortError(err: unknown) {
    return (
      (err instanceof DOMException && err.name === "AbortError") ||
      (err instanceof Error && err.name === "AbortError")
    );
  }

  const persistSettings = useCallback((next: AppSettings) => {
    setSettings(next);
    saveSettings(next);
  }, []);

  const persistPane = useCallback((next: PaneMode) => {
    setPane(next);
    savePaneMode(next);
  }, []);

  const persistTheme = useCallback((next: Theme) => {
    setTheme(next);
    saveTheme(next);
    applyTheme(next);
  }, []);

  const toggleTheme = useCallback(() => {
    persistTheme(theme === "light" ? "dark" : "light");
  }, [persistTheme, theme]);

  const persistStage = useCallback((next: Stage) => {
    setStage(next);
    saveStage(next);
  }, []);

  const refreshProjects = useCallback(async (parent = settings.parentDir) => {
    if (!parent.trim()) {
      setProjects([]);
      return;
    }
    try {
      const res = await listProjects(parent);
      setProjects(res.projects);
      if (res.parentDir && res.parentDir !== settings.parentDir) {
        persistSettings({ ...settings, parentDir: res.parentDir });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, [persistSettings, settings]);

  const openProject = useCallback(
    async (name: string) => {
      setError(null);
      saveActiveProject(name);
      setActive(name);
      persistPane("workspace");
      const cached = await loadProjectRecord(name);
      try {
        const remote = await getProject(settings.parentDir, name);
        const merged = mergeIncomingFiles(cached?.files, remote.files || cached?.files, {
          ...(cached?.timestamps || {}),
          ...(remote.timestamps || {}),
        });
        const next: ProjectRecord = {
          markdown: cached?.markdown || remote.manual || "",
          transcript: cached?.transcript || remote.transcript || "",
          title: remote.title || cached?.title || name,
          outputName: remote.outputName || cached?.outputName || name,
          files: merged.files,
          timestamps: merged.timestamps,
          hasVideo: remote.hasVideo,
          videoName: remote.videoName,
          screenshotCount: cached?.screenshotCount,
          transcriptReusable: cached?.transcriptReusable,
          headingNumbering: cached?.headingNumbering ?? false,
        };
        if (!next.markdown && remote.manual) next.markdown = remote.manual;
        setRecord(next);
        await saveProjectRecord(name, next);
      } catch (err) {
        if (cached) setRecord(cached);
        else setRecord(emptyRecord(name));
        setError(err instanceof Error ? err.message : String(err));
      }
    },
    [persistPane, settings.parentDir],
  );

  useEffect(() => {
    (async () => {
      let next = loadSettings();
      try {
        const applied = applyConfigDefaults(next, await getConfig());
        if (applied !== next) {
          next = applied;
          persistSettings(next);
        }
      } catch {
        /* backend may be down */
      }
      await refreshProjects(next.parentDir);
      const mode = loadPaneMode();
      const current = loadActiveProject();
      if (mode === "settings") persistPane("settings");
      else if (current) await openProject(current);
      else persistPane("empty");
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void refreshProjects();
  }, [settings.parentDir, refreshProjects]);

  recordRef.current = record;
  timestampsRef.current = record
    ? timestampsFromFiles(record.files, record.timestamps)
    : {};

  function scheduleSave(name: string, next: ProjectRecord) {
    if (saveTimer.current) window.clearTimeout(saveTimer.current);
    setSaveState("dirty");
    saveTimer.current = window.setTimeout(() => {
      setSaveState("saving");
      void saveProjectRecord(name, next);
      void saveDocument(settings.parentDir, name, next.markdown, {
        transcript: next.transcript,
        title: next.title,
        outputName: next.outputName,
      })
        .then(() => setSaveState("saved"))
        .catch(() => setSaveState("error"));
    }, 800);
  }

  function updateRecord(patch: Partial<ProjectRecord>) {
    if (!active) return;
    setRecord((cur) => {
      if (!cur) return cur;
      let next: ProjectRecord = { ...cur, ...patch };
      if (patch.files) {
        const merged = mergeIncomingFiles(cur.files, patch.files, {
          ...cur.timestamps,
          ...patch.timestamps,
        });
        next = { ...next, files: merged.files, timestamps: merged.timestamps };
      } else if (patch.timestamps) {
        const merged = mergeIncomingFiles(next.files, next.files, {
          ...cur.timestamps,
          ...patch.timestamps,
        });
        next = { ...next, files: merged.files, timestamps: merged.timestamps };
      }
      recordRef.current = next;
      scheduleSave(active, next);
      return next;
    });
  }

  async function handleCreate() {
    const name = draftName.trim();
    if (!name) return;
    try {
      await createProject(settings.parentDir, name);
      setModal(null);
      setDraftName("");
      await refreshProjects();
      const rec = emptyRecord(name);
      setRecord(rec);
      await saveProjectRecord(name, rec);
      saveActiveProject(name);
      setActive(name);
      persistPane("workspace");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleRename() {
    if (!modal || modal.type !== "rename") return;
    const nextName = draftName.trim();
    if (!nextName) return;
    try {
      await renameProject(settings.parentDir, modal.name, nextName);
      await renameProjectRecord(modal.name, nextName);
      setModal(null);
      await refreshProjects();
      if (active === modal.name) {
        saveActiveProject(nextName);
        setActive(nextName);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleDelete() {
    if (!modal || modal.type !== "delete") return;
    try {
      await deleteProject(settings.parentDir, modal.name);
      await deleteProjectRecord(modal.name);
      setModal(null);
      await refreshProjects();
      if (active === modal.name) {
        saveActiveProject(null);
        setActive(null);
        setRecord(null);
        persistPane("empty");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleUpload(file: File) {
    if (!active || busy) return;
    op.start({ type: "video_upload", label: "Video wird hochgeladen…", target: { type: "video" } });
    try {
      const res = await uploadVideo(settings.parentDir, active, file);
      setVideoKey((k) => k + 1);
      updateRecord({ hasVideo: true, videoName: res.name, files: res.files, transcriptReusable: false });
      op.succeed("Video hochgeladen");
    } catch (err) {
      op.fail(err instanceof Error ? err.message : String(err));
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  const handleAbort = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  async function handleGenerate(writerPrompt: string, { retranscribe }: { retranscribe: boolean }) {
    if (!active || !record || busy) return;
    const prompt = writerPrompt.trim();
    if (!prompt) return;
    const previousMarkdown = record.markdown;
    const shouldTranscribe = retranscribe || !hasReusableTranscript(record);
    const controller = new AbortController();
    abortRef.current = controller;
    setError(null);
    op.start({
      type: shouldTranscribe ? "video_processing" : "manual_generation",
      label: shouldTranscribe ? "Video wird verarbeitet…" : "Manual wird generiert…",
      target: { type: "manual" },
      step: shouldTranscribe ? "transcribing" : "writing",
      progress: { percent: shouldTranscribe ? 5 : 50 },
    });

    let transcript = record.transcript;
    let files = record.files;
    let timestampMap = record.timestamps || {};
    let screenshotCount = record.screenshotCount;
    let interpId: number | null = null;
    const displayedRef = { current: shouldTranscribe ? 5 : 50 };
    const serverRef = { current: shouldTranscribe ? 5 : 50 };
    const messageRef = { current: shouldTranscribe ? "Extracting audio…" : "Writing manual…" };

    try {
      if (shouldTranscribe) {
        persistStage("transcribing");
        interpId = window.setInterval(() => {
          let next = displayedRef.current;
          if (next < 50) next = next + (50 - next) * 0.15;
          next = Math.max(next, serverRef.current);
          displayedRef.current = next;
          op.update({
            label: messageRef.current,
            step: "transcribing",
            progress: { percent: next },
          });
        }, 300);
        const res = await transcribeStream(
          settings.parentDir,
          active,
          settings,
          (event) => {
            if (typeof event.percent === "number") serverRef.current = event.percent;
            const shown = Math.max(displayedRef.current, serverRef.current);
            displayedRef.current = shown;
            if (event.message) messageRef.current = event.message;
            op.update({
              label: messageRef.current,
              step: "transcribing",
              progress: { percent: shown },
            });
          },
          controller.signal,
        );
        if (interpId != null) {
          window.clearInterval(interpId);
          interpId = null;
        }
        if (controller.signal.aborted) throw new DOMException("Aborted", "AbortError");
        transcript = res.text;
        const transcribed = mergeIncomingFiles(files, res.files, res.timestamps);
        files = transcribed.files;
        timestampMap = transcribed.timestamps;
        screenshotCount = res.screenshotCount;
        displayedRef.current = 50;
        messageRef.current = "Writing manual…";
        setRecord((cur) => {
          if (!cur) return cur;
          const next = {
            ...cur,
            transcript: res.text,
            files,
            timestamps: timestampMap,
            screenshotCount: res.screenshotCount,
            hasVideo: true,
            transcriptReusable: true,
          };
          recordRef.current = next;
          return next;
        });
        await saveProjectRecord(active, {
          ...(recordRef.current || record),
          transcript: res.text,
          files,
          timestamps: timestampMap,
          screenshotCount: res.screenshotCount,
          hasVideo: true,
          transcriptReusable: true,
        });
      }

      persistStage("writing");
      op.update({ label: "Manual wird generiert…", step: "writing", progress: { percent: 50 } });
      // The SMM pipeline returns the full markdown + gate report as JSON once
      // the SMM has been generated and validated. We show indeterminate
      // progress while waiting, then set the markdown in one step.
      const smmResp = await writeManualSmm(
        settings.parentDir,
        active,
        transcript,
        settings,
        prompt,
        controller.signal,
      );
      const acc = smmResp.markdown;
      op.update({ label: "Manual wird generiert…", step: "writing", progress: { percent: 95 } });
      const filesOut = undefined;
      const written = mergeIncomingFiles(files, filesOut, timestampMap);
      const base = recordRef.current || record;
      const next: ProjectRecord = {
        ...base,
        markdown: acc,
        transcript,
        files: written.files,
        timestamps: written.timestamps,
        screenshotCount,
        hasVideo: true,
        transcriptReusable: shouldTranscribe ? true : base.transcriptReusable,
        gateReport: smmResp.gateReport,
        smmSummary: smmResp.smmSummary,
      };
      setRecord(next);
      await saveProjectRecord(active, next);
      persistStage("editing");
      op.succeed("Manual generiert");
      // Signal Workspace to run the automatic council review of the new manual.
      setGenerationCount((c) => c + 1);
    } catch (err) {
      persistStage("editing");
      if (isAbortError(err) || controller.signal.aborted) {
        op.clear();
        setRecord((cur) => {
          if (!cur) return cur;
          const restored = { ...cur, markdown: previousMarkdown };
          recordRef.current = restored;
          return restored;
        });
        if (active) {
          const restored = { ...(recordRef.current || record), markdown: previousMarkdown };
          void saveProjectRecord(active, restored);
        }
        return;
      }
      op.fail(err instanceof Error ? err.message : String(err));
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      if (interpId != null) window.clearInterval(interpId);
      abortRef.current = null;
    }
  }

  async function handleDownload(format: DownloadFormat) {
    if (!active || !record || downloading || busy) return;
    setDownloading(format);
    setError(null);
    op.start({ type: "export", label: "Export läuft…", target: { type: "export" } });
    try {
      await downloadExport(format, settings.parentDir, active, record.markdown, record.headingNumbering);
      const remote = await getProject(settings.parentDir, active);
      updateRecord({ files: remote.files });
      op.succeed("Export fertig");
    } catch (err) {
      op.fail(err instanceof Error ? err.message : String(err));
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setDownloading(null);
    }
  }

  function enqueuePictureMutation<T>(fn: () => Promise<T>): Promise<T> {
    const run = pictureMutationChain.current.then(fn, fn);
    pictureMutationChain.current = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  const handleShift = useCallback(
    async (filename: string, delta: number, currentTime?: number) => {
      if (!active) return;
      return enqueuePictureMutation(async () => {
        const known = timestampsRef.current[filename] ?? currentTime;
        const res = await shiftPicture(
          settings.parentDir,
          active,
          filename,
          delta,
          Number.isFinite(known) ? known : undefined,
        );
        timestampsRef.current = { ...timestampsRef.current, [filename]: res.time };
        const url = `${res.url}${res.url.includes("?") ? "&" : "?"}v=${Date.now()}`;
        // Keep the manual's image src in sync with the refreshed frame. This is
        // a targeted replacement (not a full re-serialization), so the editor
        // is not rebuilt on every nudge. The editor's own image node is updated
        // separately via the targeted node patch in FrameImage.
        const currentMarkdown = recordRef.current?.markdown ?? "";
        const nextMarkdown = replaceImageSrc(currentMarkdown, filename, url);
        updateRecord({
          files: res.files,
          timestamps: { [filename]: res.time },
          ...(nextMarkdown !== currentMarkdown ? { markdown: nextMarkdown } : {}),
        });
        return url;
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [active, settings.parentDir],
  );

  const handleSeek = useCallback((filename: string) => {
    const video = videoRef.current;
    if (!video) return;
    const rec = recordRef.current;
    const time = rec?.files.find((f) => f.name === filename)?.time ?? rec?.timestamps?.[filename];
    if (time == null || !Number.isFinite(time)) return;
    const jump = () => {
      video.currentTime = time;
      void video.pause();
    };
    if (video.readyState >= 1) {
      jump();
      return;
    }
    const onMeta = () => {
      video.removeEventListener("loadedmetadata", onMeta);
      jump();
    };
    video.addEventListener("loadedmetadata", onMeta);
  }, []);

  const handleReplace = useCallback(
    async (filename: string) => {
      if (!active) return;
      return enqueuePictureMutation(async () => {
        const time = videoRef.current?.currentTime ?? 0;
        const res = await shiftPicture(settings.parentDir, active, filename, 0, time);
        timestampsRef.current = { ...timestampsRef.current, [filename]: res.time };
        updateRecord({ files: res.files, timestamps: { [filename]: res.time } });
        return `${res.url}${res.url.includes("?") ? "&" : "?"}v=${Date.now()}`;
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [active, settings.parentDir],
  );

  const handleDeleteImage = useCallback(
    async (filename: string) => {
      if (!active) return;
      await enqueuePictureMutation(async () => {
        const res = await deletePicture(settings.parentDir, active, filename);
        updateRecord({ files: res.files });
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [active, settings.parentDir],
  );

  const handleInsertFrame = useCallback(async () => {
    if (!active) return null;
    return enqueuePictureMutation(async () => {
      const time = videoRef.current?.currentTime ?? 0;
      const res = await extractPicture(settings.parentDir, active, time);
      timestampsRef.current = { ...timestampsRef.current, [res.filename]: res.time };
      updateRecord({ files: res.files, timestamps: { [res.filename]: res.time } });
      return { filename: res.filename, url: res.url };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, settings.parentDir]);

  const main = useMemo(() => {
    if (pane === "settings") {
      return (
        <SettingsPage
          settings={settings}
          theme={theme}
          onToggleTheme={toggleTheme}
          onChange={(next) => {
            persistSettings(next);
            void refreshProjects(next.parentDir);
          }}
          onClose={() => persistPane(active ? "workspace" : "empty")}
        />
      );
    }
    if (pane === "workspace" && active && record) {
      return (
        <Workspace
          name={active}
          record={record}
          settings={settings}
          stage={stage}
          error={error}
          videoKey={videoKey}
          downloading={downloading}
          busy={busy}
          theme={theme}
          onToggleTheme={toggleTheme}
          videoRef={videoRef}
          followStreaming={stage === "writing"}
          onMarkdown={(md) => updateRecord({ markdown: md })}
          onUpload={(f) => void handleUpload(f)}
          onGenerate={() => {
            if (!busy) setGenerateOpen(true);
          }}
          onAbort={handleAbort}
          onRetry={() => {
            if (!busy) setGenerateOpen(true);
          }}
          onExport={(format) => void handleDownload(format)}
          onShift={handleShift}
          onDeleteImage={handleDeleteImage}
          onSeek={handleSeek}
          onReplace={handleReplace}
          onInsertFrame={handleInsertFrame}
          onHeadingNumbering={(headingNumbering) => updateRecord({ headingNumbering })}
          generationCount={generationCount}
          operation={op.operation}
          onOperationStart={op.start}
          onOperationUpdate={op.update}
          onOperationSucceed={op.succeed}
          onOperationFail={op.fail}
          onOperationClear={op.clear}
          saveState={saveState}
        />
      );
    }
    return (
      <div className="empty-page">
        <div className="empty-head">
          <ThemeToggle theme={theme} onToggle={toggleTheme} />
        </div>
        <div className="empty">
          <h1>RS Docu</h1>
          <p>Create a session or open a project from the sidebar. Configure Whisper, FFmpeg, and the LLM under Settings first.</p>
        </div>
      </div>
    );
  }, [
    pane,
    settings,
    active,
    record,
    stage,
    error,
    videoKey,
    downloading,
    busy,
    theme,
    toggleTheme,
    persistSettings,
    persistPane,
    refreshProjects,
    handleShift,
    handleDeleteImage,
    handleSeek,
    handleReplace,
    handleInsertFrame,
    op.operation,
    op.start,
    op.update,
    op.succeed,
    op.fail,
    op.clear,
    saveState,
  ]);

  return (
    <div className="app">
      <Sidebar
        collapsed={collapsed}
        onToggle={() => {
          const next = !collapsed;
          setCollapsed(next);
          saveCollapsed(next);
        }}
        projects={projects}
        activeProject={active}
        settingsOpen={pane === "settings"}
        parentReady={parentReady}
        busy={busy}
        onNew={() => {
          if (busy) return;
          setDraftName("");
          setModal({ type: "create" });
        }}
        onSelect={(name) => {
          if (!busy) void openProject(name);
        }}
        onSettings={() => {
          if (!busy) persistPane("settings");
        }}
        onRename={(name) => {
          if (busy) return;
          setDraftName(name);
          setModal({ type: "rename", name });
        }}
        onDelete={(name) => {
          if (!busy) setModal({ type: "delete", name });
        }}
      />
      <main className="main">
        {pane !== "workspace" && error && <div className="banner error">{error}</div>}
        {main}
      </main>
      {modal?.type === "create" && (
        <Modal
          title="New project"
          onClose={() => setModal(null)}
          onConfirm={() => void handleCreate()}
          confirmLabel="Create"
          confirmDisabled={!draftName.trim() || !parentReady}
        >
          <p className="muted">Creates a folder under the parent directory.</p>
          <input autoFocus placeholder="Project name" value={draftName} onChange={(e) => setDraftName(e.target.value)} />
        </Modal>
      )}
      {modal?.type === "rename" && (
        <Modal
          title="Rename project"
          onClose={() => setModal(null)}
          onConfirm={() => void handleRename()}
          confirmLabel="Rename"
          confirmDisabled={!draftName.trim()}
        >
          <input autoFocus value={draftName} onChange={(e) => setDraftName(e.target.value)} />
        </Modal>
      )}
      {modal?.type === "delete" && (
        <Modal
          title="Delete project"
          onClose={() => setModal(null)}
          onConfirm={() => void handleDelete()}
          confirmLabel="Delete folder"
          danger
        >
          <p>
            This removes <strong>{modal.name}</strong> and all files on disk.
          </p>
        </Modal>
      )}
      {generateOpen && !busy && (
        <GenerateManualDialog
          writers={settings.writers ?? []}
          lastWriterId={settings.lastWriterId ?? ""}
          hasTranscript={hasReusableTranscript(record)}
          settings={settings}
          onClose={() => setGenerateOpen(false)}
          onSelectModel={(model) => persistSettings({ ...settings, selectedModel: model })}
          onSelectLanguage={(language) => persistSettings({ ...settings, manualLanguage: language })}
          onGenerate={({ writerPrompt, lastWriterId, writers, retranscribe }) => {
            persistSettings({
              ...settings,
              lastWriterId,
              ...(writers ? { writers } : {}),
            });
            setGenerateOpen(false);
            void handleGenerate(writerPrompt, { retranscribe });
          }}
        />
      )}
    </div>
  );
}
