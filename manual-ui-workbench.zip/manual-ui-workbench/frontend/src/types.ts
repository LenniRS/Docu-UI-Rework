import { DEFAULT_WRITER_ID, seedWriters } from "./lib/writers";

export type PaneMode = "empty" | "workspace" | "settings";
export type Stage = "idle" | "transcribing" | "writing" | "editing";
export type EndpointType = "ollama" | "openrouter" | "openai-compatible" | "customendpoint";
export type Theme = "dark" | "light";
export type DownloadFormat = "markdown" | "cosima" | "transcript" | "docx" | "pdf";

export type Writer = {
  id: string;
  name: string;
  prompt: string;
};

export type GatewayModel = {
  id: string;
  name: string;
  url: string;
  toolCalling: boolean;
  vision: boolean;
  maxInputTokens: number;
  maxOutputTokens: number;
  streaming: boolean;
};

export type AppSettings = {
  parentDir: string;
  whisperUrl: string;
  /** Whisper model size (tiny/base/small/medium/large). */
  whisperModel: string;
  language: string;
  keyword: string;
  suppressNst: boolean;
  temperature: number;
  temperatureInc: number;
  noSpeech: number;
  entropy: number;
  logprob: number;
  prompt: string;
  endpointType: EndpointType;
  baseUrl: string;
  apiKey: string;
  /** API key for Cloud1 gateway models (separate from the Cloud2 apiKey). */
  cloud1ApiKey: string;
  models: string[] | GatewayModel[];
  selectedModel: string;
  writerTemperature: number;
  writerMaxTokens: number;
  manualLanguage: string;
  writers: Writer[];
  lastWriterId: string;
  /** Version of the default writer prompts. Bumped when the default style/structure prompts change. */
  manualPromptVersion: number;
};

export type ProjectFile = {
  name: string;
  relpath: string;
  kind: string;
  label: string;
  size: number;
  url: string;
  downloadUrl: string;
  time?: number;
  pictureUrl?: string;
};

export type ProjectRecord = {
  markdown: string;
  transcript: string;
  title: string;
  outputName: string;
  files: ProjectFile[];
  timestamps?: Record<string, number>;
  hasVideo: boolean;
  videoName?: string | null;
  screenshotCount?: number;
  /** False after a new video upload until a fresh transcription completes. */
  transcriptReusable?: boolean;
  /** Display/export-only heading numbers (1 / 1.1 / 1.1.1). Default false. */
  headingNumbering?: boolean;
  /** Quality gate report from the SMM pipeline (Phase G). */
  gateReport?: GateResult[];
  /** SMM summary from the SMM pipeline (Phase G). */
  smmSummary?: SmmSummary;
};

export type CouncilPoint = {
  title: string;
  description: string;
  roles: string[];
  passage: string;
  /** Heading of the manual section this point refers to (navigation hint). */
  section?: string;
  /** Whether the point is a restructuring or requires missing information. */
  kind?: "restructure" | "missing_info";
  /** For missing_info points: what additional information is needed. */
  needsInfo?: string;
  /** Short, concrete suggestion how to fix this point. */
  suggestion?: string;
};

export type CouncilRoleFeedback = {
  role_id: string;
  role_name: string;
  verdict: "consensus" | "objections";
  strengths: string[];
  weaknesses: string[];
  points: string[];
};

export type CouncilChatMessage = {
  role: "user" | "assistant";
  content: string;
  edit?: import("./lib/council").CouncilEdit | null;
};

// ---------------------------------------------------------------------------
// SMM (Structured Manual Model) types — Phase G frontend integration.
// ---------------------------------------------------------------------------

export type GateResult = {
  gateId: string;
  name: string;
  status: "passed" | "warning" | "blocked";
  affectedElements: string[];
  message: string;
  recommendedFixes: string[];
};

export type GateSummary = {
  total: number;
  blocked: number;
  warnings: number;
  passed: number;
  status: "blocked" | "warning" | "passed";
  blockedGates: string[];
  warningGates: string[];
};

export type SmmSummary = {
  manualId: string;
  title: string;
  status: string;
  openIssuesCount: number;
  blockingIssuesCount: number;
  gateStatus: string;
  blockedGates: string[];
};

export type ExportStatus = {
  reviewReady: boolean;
  customerReady: boolean;
  blockedGates: string[];
};

export type WriteManualSmmResponse = {
  markdown: string;
  gateReport: GateResult[];
  smmSummary: SmmSummary;
  exportStatus: ExportStatus;
};

export type GateReportResponse = {
  gateReport: GateResult[];
  summary: GateSummary;
};

/**
 * A passage the user explicitly referenced as context for the next chat
 * message. Shown as a visible attachment above the chat input and sent to the
 * LLM separately from the user's own text.
 */
export type ReferencedContext = {
  /** Where the passage comes from, e.g. "manual.md" or "council.json". */
  source: string;
  /** The referenced text excerpt. */
  text: string;
  /** Optional position within the source (1-based, inclusive). */
  startLine?: number;
  endLine?: number;
};

export type CouncilData = {
  status: "none" | "running" | "partial" | "complete" | "failed";
  consensus: boolean;
  points: CouncilPoint[];
  roles: CouncilRoleFeedback[];
  failedRoles: string[];
  chat: CouncilChatMessage[];
  /** Whether a chat-applied manual change can be undone (back button). */
  canUndo?: boolean;
};

export const DEFAULT_SETTINGS: AppSettings = {
  parentDir: "",
  whisperUrl: "http://host.docker.internal:8081",
  whisperModel: "small",
  language: "en",
  keyword: "picture",
  suppressNst: true,
  temperature: 0,
  temperatureInc: 0.2,
  noSpeech: 0.6,
  entropy: 2.4,
  logprob: -1,
  prompt: "",
  endpointType: "customendpoint",
  baseUrl: "https://mock-gateway.example.invalid/v1/chat/completions",
  apiKey: "",
  cloud1ApiKey: "",
  models: ["deepseek-v4-flash-0731"],
  selectedModel: "deepseek-v4-flash-0731",
  writerTemperature: 0.1,
  writerMaxTokens: 8192,
  manualLanguage: "English",
  writers: seedWriters(),
  lastWriterId: DEFAULT_WRITER_ID,
  manualPromptVersion: 2,
};
