import { del, get, set, update } from "idb-keyval";
import type { AppSettings, EndpointType, PaneMode, ProjectRecord, Stage, Theme } from "../types";
import { DEFAULT_SETTINGS } from "../types";
import type { ConfigResponse } from "./api";
import { isFactoryS1000d, isLegacyV1Writers, resolveWriterId, seedWriters } from "./writers";

const SETTINGS_KEY = "rsdocu:settings";
const PANE_KEY = "rsdocu:paneMode";
const ACTIVE_KEY = "rsdocu:activeProject";
const STAGE_KEY = "rsdocu:stage";
const COLLAPSE_KEY = "rsdocu:sidebarCollapsed";
const THEME_KEY = "rsdocu:theme";
const MEDIA_COL_WIDTH_KEY = "rsdocu:mediaColWidth";
const OUTLINE_COL_WIDTH_KEY = "rsdocu:outlineColWidth";
const OUTLINE_COLLAPSE_KEY = "rsdocu:outlineCollapsed";

export const DEFAULT_MEDIA_COL_WIDTH = 420;
export const DEFAULT_OUTLINE_COL_WIDTH = 220;

const LEGACY_WHISPER_URLS = new Set(["http://127.0.0.1:8081", "http://localhost:8081"]);
const LEGACY_LLM_URLS = new Set(["http://127.0.0.1:11434", "http://localhost:11434"]);

function migrateLocalhostUrls(settings: AppSettings, cfg?: ConfigResponse): AppSettings {
  const whisperUrl = LEGACY_WHISPER_URLS.has(settings.whisperUrl)
    ? (cfg?.whisperUrl || DEFAULT_SETTINGS.whisperUrl)
    : settings.whisperUrl;
  const baseUrl = LEGACY_LLM_URLS.has(settings.baseUrl)
    ? (cfg?.llmBaseUrl || DEFAULT_SETTINGS.baseUrl)
    : settings.baseUrl;
  if (whisperUrl === settings.whisperUrl && baseUrl === settings.baseUrl) return settings;
  return { ...settings, whisperUrl, baseUrl };
}

function withWriters(settings: AppSettings): AppSettings {
  let writers =
    Array.isArray(settings.writers) && settings.writers.length > 0
      ? settings.writers.map((w) => ({ ...w }))
      : seedWriters();
  // Migrate untouched factory seeds to the current defaults. User-edited
  // prompts are never overwritten.
  if (isFactoryS1000d(writers) || isLegacyV1Writers(writers)) writers = seedWriters();
  const manualPromptVersion = settings.manualPromptVersion ?? DEFAULT_SETTINGS.manualPromptVersion;
  return {
    ...settings,
    writers,
    manualPromptVersion,
    lastWriterId: resolveWriterId(writers, settings.lastWriterId),
  };
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return withWriters({ ...DEFAULT_SETTINGS });
    const parsed = { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    const urlMigrated = migrateLocalhostUrls(parsed);
    const next = withWriters(urlMigrated);
    const writersChanged = JSON.stringify(urlMigrated.writers) !== JSON.stringify(next.writers);
    if (urlMigrated !== parsed || writersChanged) saveSettings(next);
    return next;
  } catch {
    return withWriters({ ...DEFAULT_SETTINGS });
  }
}

export function saveSettings(settings: AppSettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function isEndpointType(value: string): value is EndpointType {
  return (
    value === "ollama" ||
    value === "openrouter" ||
    value === "openai-compatible" ||
    value === "customendpoint"
  );
}

/** Fill empty parent dir and rewrite localhost Whisper/LLM URLs using /api/config. */
export function applyConfigDefaults(settings: AppSettings, cfg: ConfigResponse): AppSettings {
  const migrated = migrateLocalhostUrls(settings, cfg);
  const patch: Partial<AppSettings> = {};
  if (!migrated.parentDir.trim()) {
    const parent = (cfg.parentDir || cfg.defaultParentDir || "").trim();
    if (parent) patch.parentDir = parent;
  }
  if (migrated.whisperUrl === DEFAULT_SETTINGS.whisperUrl && cfg.whisperUrl && cfg.whisperUrl !== migrated.whisperUrl) {
    patch.whisperUrl = cfg.whisperUrl;
  }
  if (migrated.baseUrl === DEFAULT_SETTINGS.baseUrl && cfg.llmBaseUrl && cfg.llmBaseUrl !== migrated.baseUrl) {
    patch.baseUrl = cfg.llmBaseUrl;
    if (cfg.endpointType && isEndpointType(cfg.endpointType)) patch.endpointType = cfg.endpointType;
  }
  return Object.keys(patch).length ? { ...migrated, ...patch } : migrated;
}

export function loadPaneMode(): PaneMode {
  const v = localStorage.getItem(PANE_KEY);
  if (v === "workspace" || v === "settings" || v === "empty") return v;
  return "empty";
}

export function savePaneMode(mode: PaneMode) {
  localStorage.setItem(PANE_KEY, mode);
}

export function loadActiveProject(): string | null {
  return localStorage.getItem(ACTIVE_KEY);
}

export function saveActiveProject(name: string | null) {
  if (name) localStorage.setItem(ACTIVE_KEY, name);
  else localStorage.removeItem(ACTIVE_KEY);
}

export function loadStage(): Stage {
  const v = localStorage.getItem(STAGE_KEY);
  if (v === "idle" || v === "transcribing" || v === "writing" || v === "editing") return v;
  return "idle";
}

export function saveStage(stage: Stage) {
  localStorage.setItem(STAGE_KEY, stage);
}

export function loadCollapsed(): boolean {
  return localStorage.getItem(COLLAPSE_KEY) === "1";
}

export function saveCollapsed(value: boolean) {
  localStorage.setItem(COLLAPSE_KEY, value ? "1" : "0");
}

export function loadTheme(): Theme {
  try {
    return localStorage.getItem(THEME_KEY) === "dark" ? "dark" : "light";
  } catch {
    return "light";
  }
}

export function saveTheme(theme: Theme) {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch {
    /* ignore quota / private-mode failures */
  }
}

export function applyTheme(theme: Theme) {
  document.documentElement.setAttribute("data-theme", theme);
}

export function loadMediaColWidth(): number {
  try {
    const raw = localStorage.getItem(MEDIA_COL_WIDTH_KEY);
    if (raw == null || raw === "") return DEFAULT_MEDIA_COL_WIDTH;
    const n = Number(raw);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_MEDIA_COL_WIDTH;
    return n;
  } catch {
    return DEFAULT_MEDIA_COL_WIDTH;
  }
}

export function saveMediaColWidth(width: number) {
  if (!Number.isFinite(width) || width <= 0) return;
  localStorage.setItem(MEDIA_COL_WIDTH_KEY, String(Math.round(width)));
}

export function loadOutlineColWidth(): number {
  try {
    const raw = localStorage.getItem(OUTLINE_COL_WIDTH_KEY);
    if (raw == null || raw === "") return DEFAULT_OUTLINE_COL_WIDTH;
    const n = Number(raw);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_OUTLINE_COL_WIDTH;
    return n;
  } catch {
    return DEFAULT_OUTLINE_COL_WIDTH;
  }
}

export function saveOutlineColWidth(width: number) {
  if (!Number.isFinite(width) || width <= 0) return;
  localStorage.setItem(OUTLINE_COL_WIDTH_KEY, String(Math.round(width)));
}

export function loadOutlineCollapsed(): boolean {
  return localStorage.getItem(OUTLINE_COLLAPSE_KEY) === "1";
}

export function saveOutlineCollapsed(value: boolean) {
  localStorage.setItem(OUTLINE_COLLAPSE_KEY, value ? "1" : "0");
}

export async function loadProjectRecord(name: string): Promise<ProjectRecord | undefined> {
  return get(`project:${name}`);
}

export async function saveProjectRecord(name: string, record: ProjectRecord) {
  await set(`project:${name}`, record);
}

export async function deleteProjectRecord(name: string) {
  await del(`project:${name}`);
}

export async function renameProjectRecord(oldName: string, newName: string) {
  const rec = await get(`project:${oldName}`);
  if (rec) {
    await set(`project:${newName}`, rec);
    await del(`project:${oldName}`);
  }
}

export async function patchProjectRecord(name: string, patch: Partial<ProjectRecord>) {
  await update(`project:${name}`, (current?: ProjectRecord) => ({
    markdown: "",
    transcript: "",
    title: name,
    outputName: name,
    files: [],
    hasVideo: false,
    headingNumbering: false,
    ...current,
    ...patch,
  }));
}
