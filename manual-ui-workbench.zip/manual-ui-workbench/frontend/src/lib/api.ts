import type { AppSettings, CouncilChatMessage, CouncilData, DownloadFormat, ProjectFile, GatewayModel, ReferencedContext, WriteManualSmmResponse, GateReportResponse } from "../types";

async function parseError(res: Response): Promise<string> {
  try {
    const data = await res.json();
    const detail = data.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) return detail.map((d) => d.msg || JSON.stringify(d)).join("; ");
    return JSON.stringify(data);
  } catch {
    return res.statusText || `HTTP ${res.status}`;
  }
}

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) throw new Error(await parseError(res));
  return res.json() as Promise<T>;
}

export type ConfigResponse = {
  parentDir: string;
  defaultParentDir: string;
  whisperUrl: string;
  llmBaseUrl: string;
  endpointType: string;
};
export type ProjectsResponse = { parentDir: string; reachable: boolean; projects: string[] };
export type ProjectResponse = {
  name: string;
  path: string;
  title: string;
  outputName: string;
  hasVideo: boolean;
  videoName: string | null;
  manual: string;
  transcript: string;
  files: ProjectFile[];
  timestamps: Record<string, number>;
};

export type TranscribeProgressEvent = {
  stage?: string;
  percent?: number;
  message?: string;
  screenshotCurrent?: number;
  screenshotTotal?: number;
};

export type TranscribeDone = {
  text: string;
  screenshotCount: number;
  timestamps: Record<string, number>;
  files: ProjectFile[];
};

type SsePayload = {
  delta?: string;
  done?: boolean;
  error?: unknown;
  files?: ProjectFile[];
  text?: string;
  screenshotCount?: number;
  timestamps?: Record<string, number>;
  stage?: string;
  percent?: number;
  message?: string;
  screenshotCurrent?: number;
  screenshotTotal?: number;
  /** Whether a council point was resolved by this chat reply. */
  resolved?: boolean;
  /** Updated council data after a point was resolved. */
  council?: CouncilData;
};

async function consumeSse(res: Response, onEvent: (payload: SsePayload) => void): Promise<void> {
  if (!res.ok) throw new Error(await parseError(res));
  if (!res.body) throw new Error("No stream");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const chunks = buffer.split("\n\n");
      buffer = chunks.pop() ?? "";
      for (const chunk of chunks) {
        const line = chunk.trim().replace(/^data:\s*/, "");
        if (!line) continue;
        onEvent(JSON.parse(line) as SsePayload);
      }
    }
    const tail = buffer.trim().replace(/^data:\s*/, "");
    if (tail) onEvent(JSON.parse(tail) as SsePayload);
  } finally {
    try {
      reader.releaseLock();
    } catch {
      /* already released */
    }
  }
}

export async function getConfig() {
  return json<ConfigResponse>(await fetch("/api/config"));
}

export async function listProjects(parent: string) {
  const q = new URLSearchParams({ parent });
  return json<ProjectsResponse>(await fetch(`/api/projects?${q}`));
}

export async function createProject(parentDir: string, name: string) {
  return json<{ name: string; path: string }>(
    await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, name }),
    }),
  );
}

export async function renameProject(parentDir: string, oldName: string, newName: string) {
  return json<{ name: string; path: string }>(
    await fetch("/api/projects/rename", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, oldName, newName }),
    }),
  );
}

export async function deleteProject(parentDir: string, name: string) {
  const q = new URLSearchParams({ parent: parentDir });
  return json<{ ok: boolean }>(await fetch(`/api/projects/${encodeURIComponent(name)}?${q}`, { method: "DELETE" }));
}

export async function getProject(parentDir: string, name: string) {
  const q = new URLSearchParams({ parent: parentDir });
  return json<ProjectResponse>(await fetch(`/api/projects/${encodeURIComponent(name)}?${q}`));
}

export async function saveMeta(parentDir: string, name: string, title?: string, outputName?: string) {
  return json(
    await fetch(`/api/projects/${encodeURIComponent(name)}/meta`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, title, outputName }),
    }),
  );
}

export async function uploadVideo(parentDir: string, name: string, file: File) {
  const form = new FormData();
  form.append("parent", parentDir);
  form.append("file", file);
  return json<{ name: string; size: number; url: string; files: ProjectFile[] }>(
    await fetch(`/api/projects/${encodeURIComponent(name)}/video`, { method: "POST", body: form }),
  );
}

export function videoUrl(parentDir: string, name: string, bust?: string | number) {
  const q = new URLSearchParams({ parent: parentDir });
  if (bust != null) q.set("v", String(bust));
  return `/api/projects/${encodeURIComponent(name)}/video?${q}`;
}

export async function saveDocument(
  parentDir: string,
  name: string,
  markdown: string,
  extra?: { transcript?: string; title?: string; outputName?: string },
) {
  return json<{ ok: boolean; files: ProjectFile[] }>(
    await fetch(`/api/projects/${encodeURIComponent(name)}/document`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, projectName: name, markdown, ...extra }),
    }),
  );
}

export async function getCouncil(parentDir: string, name: string) {
  const q = new URLSearchParams({ parent: parentDir });
  return json<CouncilData>(await fetch(`/api/projects/${encodeURIComponent(name)}/council?${q}`));
}

/** Clear the council chat thread for a project. */
export async function clearCouncilChat(parentDir: string, name: string): Promise<void> {
  const q = new URLSearchParams({ parent: parentDir });
  await fetch(`/api/projects/${encodeURIComponent(name)}/council/chat/clear?${q}`, {
    method: "POST",
  });
}

/** Run the council review of the generated manual (same LLM as generation). */
export async function runCouncil(
  parentDir: string,
  name: string,
  settings: AppSettings,
): Promise<CouncilData> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/run`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 4096),
      candidates: buildCandidates(settings),
    }),
  });
  return json<CouncilData>(res);
}

/** Stream a chat reply from the council assistant (same LLM as generation). */
export async function councilChatStream(
  parentDir: string,
  name: string,
  messages: CouncilChatMessage[],
  contexts: ReferencedContext[],
  settings: AppSettings,
  onDelta: (delta: string) => void,
  signal?: AbortSignal,
  resolvePoint?: { title: string; needsInfo?: string } | null,
): Promise<{ resolved: boolean; council?: CouncilData }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      messages,
      contexts,
      resolvePoint: resolvePoint || null,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      // Higher budget for the chat so whole-section translations/rewrites are
      // not truncated. Validation before apply still guards against truncation.
      maxTokens: Math.min(settings.writerMaxTokens, 8192),
      candidates: buildCandidates(settings),
    }),
    signal,
  });
  let resolved = false;
  let council: CouncilData | undefined;
  await consumeSse(res, (payload) => {
    if (payload.error) {
      throw new Error(typeof payload.error === "string" ? payload.error : JSON.stringify(payload.error));
    }
    if (payload.delta) onDelta(payload.delta);
    if (payload.done) {
      resolved = Boolean(payload.resolved);
      council = payload.council;
    }
  });
  return { resolved, council };
}

/** Apply a council chat edit proposal to the manual. Returns the full new manual. */
export async function applyCouncilEdit(
  parentDir: string,
  name: string,
  oldText: string,
  newText: string,
  settings: AppSettings,
): Promise<{ markdown: string }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/apply-edit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      editType: "replace",
      oldText,
      newText,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string }>(res);
}

/** Apply a whole-section edit (replace_section) to the manual. */
export async function applyCouncilSectionEdit(
  parentDir: string,
  name: string,
  section: string,
  newText: string,
  settings: AppSettings,
): Promise<{ markdown: string }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/apply-edit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      editType: "replace_section",
      section,
      newText,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string }>(res);
}

/** Apply a body-only edit (replace_section_body) to the manual. */
export async function applyCouncilSectionBodyEdit(
  parentDir: string,
  name: string,
  section: string,
  newBody: string,
  settings: AppSettings,
): Promise<{ markdown: string }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/apply-edit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      editType: "replace_section_body",
      section,
      newBody,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string }>(res);
}

/** Apply a heading-only edit (rename_heading) to the manual. */
export async function applyCouncilRenameHeading(
  parentDir: string,
  name: string,
  section: string,
  newHeading: string,
  settings: AppSettings,
): Promise<{ markdown: string }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/apply-edit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      editType: "rename_heading",
      section,
      newHeading,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string }>(res);
}

/** Undo the last chat-applied change to the manual. Returns the restored manual. */
export async function undoCouncilEdit(
  parentDir: string,
  name: string,
  settings: AppSettings,
): Promise<{ markdown: string; canUndo: boolean }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/undo`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string; canUndo: boolean }>(res);
}

/** Apply a council suggestion to the manual (LLM turns it into an edit). */
export async function applyCouncilSuggestion(
  parentDir: string,
  name: string,
  suggestion: string,
  passage: string,
  settings: AppSettings,
  pointTitle?: string,
): Promise<{ markdown: string; council?: CouncilData }> {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch(`/api/projects/${encodeURIComponent(name)}/council/apply-suggestion`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      suggestion,
      passage,
      pointTitle: pointTitle || "",
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: Math.min(settings.writerMaxTokens, 2048),
      candidates: buildCandidates(settings),
    }),
  });
  return json<{ markdown: string; council?: CouncilData }>(res);
}

export async function transcribeStream(
  parentDir: string,
  name: string,
  settings: AppSettings,
  onProgress: (event: TranscribeProgressEvent) => void,
  signal?: AbortSignal,
): Promise<TranscribeDone> {
  const res = await fetch("/api/transcribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName: name,
      whisperUrl: settings.whisperUrl,
      whisperModel: settings.whisperModel,
      language: settings.language,
      keyword: settings.keyword,
      suppressNst: settings.suppressNst,
      temperature: settings.temperature,
      temperatureInc: settings.temperatureInc,
      noSpeech: settings.noSpeech,
      entropy: settings.entropy,
      logprob: settings.logprob,
      prompt: settings.prompt,
    }),
    signal,
  });
  let done: TranscribeDone | null = null;
  await consumeSse(res, (payload) => {
    if (payload.error) {
      throw new Error(typeof payload.error === "string" ? payload.error : JSON.stringify(payload.error));
    }
    if (payload.done) {
      done = {
        text: String(payload.text || ""),
        screenshotCount: Number(payload.screenshotCount || 0),
        timestamps: (payload.timestamps as Record<string, number>) || {},
        files: (payload.files as ProjectFile[]) || [],
      };
      return;
    }
    onProgress({
      stage: typeof payload.stage === "string" ? payload.stage : undefined,
      percent: typeof payload.percent === "number" ? payload.percent : undefined,
      message: typeof payload.message === "string" ? payload.message : undefined,
      screenshotCurrent: typeof payload.screenshotCurrent === "number" ? payload.screenshotCurrent : undefined,
      screenshotTotal: typeof payload.screenshotTotal === "number" ? payload.screenshotTotal : undefined,
    });
  });
  if (!done) throw new Error("Transcription did not finish");
  return done;
}

export async function shiftPicture(
  parentDir: string,
  projectName: string,
  filename: string,
  delta: number,
  currentTime?: number,
) {
  return json<{ filename: string; time: number; url: string; files: ProjectFile[] }>(
    await fetch("/api/pictures/shift", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, projectName, filename, delta, currentTime }),
    }),
  );
}

export async function extractPicture(parentDir: string, projectName: string, time: number) {
  return json<{ filename: string; time: number; url: string; files: ProjectFile[] }>(
    await fetch("/api/pictures/extract", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, projectName, time }),
    }),
  );
}

export async function deletePicture(parentDir: string, projectName: string, filename: string) {
  return json<{ ok: boolean; files: ProjectFile[] }>(
    await fetch("/api/pictures/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentDir, projectName, filename }),
    }),
  );
}

export async function downloadExport(
  format: DownloadFormat,
  parentDir: string,
  projectName: string,
  markdown: string,
  headingNumbering = false,
) {
  const body =
    format === "transcript"
      ? { parentDir, projectName }
      : { parentDir, projectName, markdown, headingNumbering };
  const res = await fetch(`/api/export/${format}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await parseError(res));
  const blob = await res.blob();
  // Statischer Exportname, damit der Download unabhängig vom Projektnamen ist
  // (muss mit dem Backend-EXPORT_BASENAME übereinstimmen).
  const base = "RS_Docu";
  const fallback =
    format === "markdown"
      ? `${base}.zip`
      : format === "cosima"
        ? `${base}_cosima.zip`
        : format === "transcript"
          ? `${base}_transcript.zip`
          : format === "docx"
            ? `${base}.docx`
            : `${base}.pdf`;
  triggerDownload(blob, filenameFromDisposition(res.headers.get("Content-Disposition")) || fallback);
}

function filenameFromDisposition(header: string | null): string | null {
  if (!header) return null;
  const star = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[1].trim());
    } catch {
      return star[1].trim();
    }
  }
  const quoted = /filename="([^"]+)"/i.exec(header);
  if (quoted) return quoted[1];
  const plain = /filename=([^;]+)/i.exec(header);
  return plain ? plain[1].trim() : null;
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// Helper: find the URL for the selected model from the models list
function selectedModelUrl(settings: AppSettings): string {
  // If models are GatewayModel objects, find the selected model's URL
  if (Array.isArray(settings.models) && settings.models.length > 0) {
    const first = settings.models[0];
    if (typeof first === "object" && first !== null && "url" in first) {
      const found = (settings.models as GatewayModel[]).find((m) => m.id === settings.selectedModel);
      if (found?.url) return found.url;
    }
  }
  return settings.baseUrl;
}

/** True when the model URL points at the Cloud1 gateway (needs cloud1ApiKey). */
function isCloud1Url(url: string): boolean {
  return url.includes("llm-gateway-qual.cloud.rsint.net");
}

/** Pick the API key for a model URL.
 *
 * Cloud2 (on-prem) works without a key; only Cloud1 models need cloud1ApiKey.
 */
function keyForUrl(settings: AppSettings, url: string): string {
  return isCloud1Url(url) ? settings.cloud1ApiKey : "";
}

/** Build the ordered fallback chain from the available gateway models.
 *
 * The selected model is first; then the other usable models in a sensible
 * order (Cloud2 before Cloud1, best-known models first). Each entry carries
 * its own URL and the matching API key, so Cloud1 models use cloud1ApiKey.
 */
function buildCandidates(settings: AppSettings): Array<Record<string, string>> {
  const models = Array.isArray(settings.models) ? settings.models : [];
  const gatewayModels = models.filter(
    (m): m is GatewayModel => typeof m === "object" && m !== null && "url" in m,
  );
  if (gatewayModels.length === 0) {
    // Fall back to a single candidate using the configured base URL.
    return [
      {
        model: settings.selectedModel,
        baseUrl: settings.baseUrl,
        apiKey: keyForUrl(settings, settings.baseUrl),
      },
    ];
  }
  // Order: selected first, then Cloud2 models, then Cloud1 models.
  const selected = gatewayModels.find((m) => m.id === settings.selectedModel);
  const rest = gatewayModels.filter((m) => m.id !== settings.selectedModel);
  const cloud2 = rest.filter((m) => !isCloud1Url(m.url));
  const cloud1 = rest.filter((m) => isCloud1Url(m.url));
  const ordered = selected ? [selected, ...cloud2, ...cloud1] : [...cloud2, ...cloud1];
  return ordered.map((m) => ({
    model: m.id,
    baseUrl: m.url,
    apiKey: keyForUrl(settings, m.url),
  }));
}

export async function rewriteSelection(
  settings: AppSettings,
  selection: string,
  instruction: string,
  context: string,
) {
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  return json<{ text: string }>(
    await fetch("/api/llm/rewrite", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        selection,
        instruction,
        context,
        endpointType: settings.endpointType,
        baseUrl,
        apiKey,
        model: settings.selectedModel,
        temperature: settings.writerTemperature,
        maxTokens: Math.min(settings.writerMaxTokens, 2048),
        candidates: buildCandidates(settings),
      }),
    }),
  );
}

export async function writeManualStream(
  parentDir: string,
  projectName: string,
  transcript: string,
  settings: AppSettings,
  writerPrompt: string,
  onDelta: (delta: string) => void,
  signal?: AbortSignal,
): Promise<ProjectFile[] | undefined> {
  const prompt = writerPrompt.trim();
  if (!prompt) throw new Error("Writer prompt is required");
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch("/api/llm/write-manual", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName,
      transcript,
      language: settings.manualLanguage,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: settings.writerMaxTokens,
      writerPrompt: prompt,
      candidates: buildCandidates(settings),
    }),
    signal,
  });
  let files: ProjectFile[] | undefined;
  await consumeSse(res, (payload) => {
    if (payload.error) {
      throw new Error(typeof payload.error === "string" ? payload.error : JSON.stringify(payload.error));
    }
    if (payload.delta) onDelta(payload.delta);
    if (payload.files) files = payload.files;
  });
  return files;
}

/**
 * Generate a manual through the SMM pipeline (Phase E/G).
 *
 * The SMM endpoint returns a JSON payload (markdown + gate report + SMM
 * summary) instead of an SSE stream. The markdown is delivered whole once the
 * SMM has been generated and validated.
 */
export async function writeManualSmm(
  parentDir: string,
  projectName: string,
  transcript: string,
  settings: AppSettings,
  writerPrompt: string,
  signal?: AbortSignal,
): Promise<WriteManualSmmResponse> {
  const prompt = writerPrompt.trim();
  if (!prompt) throw new Error("Writer prompt is required");
  const baseUrl = selectedModelUrl(settings);
  const apiKey = keyForUrl(settings, baseUrl);
  const res = await fetch("/api/llm/write-manual-smm", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      parentDir,
      projectName,
      transcript,
      language: settings.manualLanguage,
      endpointType: settings.endpointType,
      baseUrl,
      apiKey,
      model: settings.selectedModel,
      temperature: settings.writerTemperature,
      maxTokens: settings.writerMaxTokens,
      writerPrompt: prompt,
      candidates: buildCandidates(settings),
    }),
    signal,
  });
  return json<WriteManualSmmResponse>(res);
}

/** Fetch the persisted gate report for a project. */
export async function getGateReport(parentDir: string, projectName: string): Promise<GateReportResponse> {
  const q = new URLSearchParams({ parentDir });
  return json<GateReportResponse>(await fetch(`/api/projects/${encodeURIComponent(projectName)}/gate-report?${q}`));
}

/** Fetch the persisted SMM for a project (404 if none). */
export async function getSmm(parentDir: string, projectName: string): Promise<Record<string, unknown>> {
  const q = new URLSearchParams({ parentDir });
  return json<Record<string, unknown>>(await fetch(`/api/projects/${encodeURIComponent(projectName)}/smm?${q}`));
}

/** Fetch the fully assembled system prompt (style + engine + glossary) from the backend. */
export async function getSystemPrompt(writerPrompt: string) {
  return json<{ systemPrompt: string }>(
    await fetch("/api/llm/system-prompt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ writerPrompt }),
    }),
  );
}

export async function whisperHealth(url: string) {
  const q = new URLSearchParams({ url });
  return json<{ available: boolean; detail?: string }>(await fetch(`/api/health/whisper?${q}`));
}

export async function llmHealth(baseUrl: string, endpointType: string, apiKey: string) {
  const q = new URLSearchParams({ baseUrl, endpointType, apiKey });
  return json<{ available: boolean; detail?: string }>(await fetch(`/api/health/llm?${q}`));
}

export async function listLlmModels(baseUrl: string, endpointType: string, apiKey: string) {
  // For the Cloud Gateway (customendpoint), load models from gateway-config.json.
  if (endpointType === "customendpoint") {
    try {
      const response = await fetch("/gateway-config.json");
      if (response.ok) {
        const config = await response.json();
        const models: GatewayModel[] = [];
        for (const vendorConfig of config as Array<{ models: GatewayModel[] }>) {
          if (vendorConfig?.models) {
            for (const model of vendorConfig.models) {
              models.push(model);
            }
          }
        }
        return { models, url: baseUrl };
      }
    } catch {
      // Fall back to standard model listing
    }
  }

  const q = new URLSearchParams({ baseUrl, endpointType, apiKey });
  return json<{ models: string[] | GatewayModel[]; url?: string }>(await fetch(`/api/llm/models?${q}`));
}

export async function ffmpegHealth() {
  return json<{ available: boolean; version?: string }>(await fetch("/api/health/ffmpeg"));
}
