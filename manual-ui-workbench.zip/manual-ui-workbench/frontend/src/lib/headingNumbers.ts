import { Extension } from "@tiptap/core";
import type { Node } from "@tiptap/pm/model";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";

export type HeadingLevel = 1 | 2 | 3 | 4 | 5 | 6;

/** Increment level N and reset deeper levels. Skip-level headings may include a 0 (H1 then H3 → 1.0.1). */
export function headingNumberLabel(level: HeadingLevel, counters: number[]): string {
  const idx = level - 1;
  counters[idx] += 1;
  for (let i = idx + 1; i < counters.length; i++) counters[i] = 0;
  return counters.slice(0, level).join(".");
}

function headingNumberDecorations(doc: Node, enabled: boolean): DecorationSet {
  if (!enabled) return DecorationSet.empty;
  const decorations: Decoration[] = [];
  const counters = [0, 0, 0, 0, 0, 0];
  doc.descendants((node, pos) => {
    if (node.type.name !== "heading") return;
    const level = node.attrs.level as HeadingLevel;
    const label = headingNumberLabel(level, counters);
    decorations.push(
      Decoration.widget(
        pos + 1,
        () => {
          const span = document.createElement("span");
          span.className = "heading-num";
          span.contentEditable = "false";
          span.textContent = `${label}\u00a0`;
          return span;
        },
        { side: -1, ignoreSelection: true },
      ),
    );
  });
  return DecorationSet.create(doc, decorations);
}

const headingNumbersKey = new PluginKey("headingNumbers");

export const HeadingNumbers = Extension.create({
  name: "headingNumbers",

  addStorage() {
    return { enabled: false };
  },

  addProseMirrorPlugins() {
    const extension = this;
    return [
      new Plugin({
        key: headingNumbersKey,
        props: {
          decorations: (state) => headingNumberDecorations(state.doc, Boolean(extension.storage.enabled)),
        },
      }),
    ];
  },
});
