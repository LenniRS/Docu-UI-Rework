import { Extension } from "@tiptap/core";
import { Fragment, type Node as PMNode } from "@tiptap/pm/model";
import { Plugin, PluginKey, type Transaction } from "@tiptap/pm/state";
import type { EditorView } from "@tiptap/pm/view";

export type ListOrigin = "auto" | "restart" | "manual";

export type NumberedItem = {
  listPos: number;
  itemPos: number;
  itemIndex: number;
  itemCount: number;
  depth: number;
  number: number;
  origin: ListOrigin;
  start: number;
};

export type NumberingMenuState = {
  canRestart: boolean;
  canContinue: boolean;
  value: number;
  listPos: number;
  itemIndex: number;
};

type ListPatch = {
  pos: number;
  start: number;
  origin: ListOrigin;
};

const RESTART_COMMENT = "ol-origin:restart";
const MANUAL_COMMENT_RE = /^ol-origin:manual(?::(\d+))?$/;
const MAX_LIST_DEPTH = 12;

export function normalizeOrigin(value: unknown): ListOrigin {
  if (value === "restart" || value === "manual") return value;
  return "auto";
}

export function findOrderedListItem(doc: PMNode, pos: number): {
  listPos: number;
  listNode: PMNode;
  itemIndex: number;
  itemPos: number;
} | null {
  const size = doc.content.size;
  if (size <= 0) return null;
  const safe = Math.max(0, Math.min(pos, size));

  function fromResolved($pos: ReturnType<PMNode["resolve"]>) {
    for (let d = $pos.depth; d > 0; d--) {
      if ($pos.node(d).type.name !== "listItem") continue;
      for (let p = d - 1; p >= 0; p--) {
        if ($pos.node(p).type.name !== "orderedList") continue;
        const itemDepth = p + 1 <= d && $pos.node(p + 1).type.name === "listItem" ? p + 1 : d;
        return {
          listPos: $pos.before(p),
          listNode: $pos.node(p),
          itemIndex: $pos.index(p),
          itemPos: $pos.before(itemDepth),
        };
      }
    }
    return null;
  }

  const $pos = doc.resolve(safe);
  const resolved = fromResolved($pos);
  if (resolved) return resolved;

  const node = doc.nodeAt(safe);
  if (node?.type.name === "listItem" && $pos.parent.type.name === "orderedList") {
    return {
      listPos: $pos.before($pos.depth),
      listNode: $pos.parent,
      itemIndex: $pos.index(),
      itemPos: safe,
    };
  }
  if (node?.type.name === "orderedList") {
    let itemPos = safe + 1;
    for (let i = 0, index = 0; i < node.childCount; i++) {
      const child = node.child(i);
      if (child.type.name === "listItem") {
        return { listPos: safe, listNode: node, itemIndex: index, itemPos };
      }
      itemPos += child.nodeSize;
    }
  }
  return null;
}

function eventTargetElement(event: MouseEvent): Element | null {
  const raw = event.target;
  if (raw instanceof Element) return raw;
  if (raw instanceof Node) return raw.parentElement;
  return null;
}

function isOrderedListItemEl(el: Element | null, view: EditorView): el is HTMLLIElement {
  return (
    el instanceof HTMLLIElement &&
    el.parentElement?.tagName === "OL" &&
    view.dom.contains(el)
  );
}

function posInsideListItem(view: EditorView, li: HTMLElement): number | null {
  try {
    const pos = view.posAtDOM(li, 0);
    return Math.max(0, Math.min(pos + 1, view.state.doc.content.size));
  } catch {
    return null;
  }
}

function directLiAtY(ol: HTMLElement, clientY: number): HTMLElement | null {
  for (const item of ol.querySelectorAll(":scope > li")) {
    if (!(item instanceof HTMLElement)) continue;
    const r = item.getBoundingClientRect();
    if (clientY >= r.top && clientY <= r.bottom) return item;
  }
  return null;
}

function isNonNumberedBlockTarget(target: Element, view: EditorView): boolean {
  const block = target.closest("h1, h2, h3, h4, h5, h6, p, img, ul, .frame-wrap");
  if (!block || !view.dom.contains(block)) return false;
  const li = block.closest("li");
  if (isOrderedListItemEl(li, view) && li.contains(block)) return false;
  return true;
}

function numberingPosFromOrderedListNode(
  view: EditorView,
  listPos: number,
  clientY: number,
): number | null {
  const dom = view.nodeDOM(listPos);
  if (dom instanceof HTMLElement && dom.tagName === "OL") {
    const hitLi = directLiAtY(dom, clientY);
    if (isOrderedListItemEl(hitLi, view)) return posInsideListItem(view, hitLi);
  }
  const hit = findOrderedListItem(view.state.doc, listPos);
  return hit ? Math.min(hit.itemPos + 1, view.state.doc.content.size) : null;
}

/** Document position for a right-click on a numbered item or its marker; otherwise null. */
export function numberingPosFromEvent(view: EditorView, event: MouseEvent): number | null {
  const target = eventTargetElement(event);
  const doc = view.state.doc;

  if (target && view.dom.contains(target)) {
    const li = target.closest("li");
    if (isOrderedListItemEl(li, view)) {
      const pos = posInsideListItem(view, li);
      if (pos != null) return pos;
    }
    if (target.tagName === "OL" && view.dom.contains(target)) {
      const hitLi = directLiAtY(target as HTMLElement, event.clientY);
      if (isOrderedListItemEl(hitLi, view)) {
        const pos = posInsideListItem(view, hitLi);
        if (pos != null) return pos;
      }
    }
    if (isNonNumberedBlockTarget(target, view)) return null;
  }

  const { from, to } = view.state.selection;
  if (from !== to && findOrderedListItem(doc, from) && findOrderedListItem(doc, to)) {
    return from;
  }

  const coords = view.posAtCoords({ left: event.clientX, top: event.clientY });
  if (!coords) return null;
  if (coords.inside >= 0) {
    const insideNode = doc.nodeAt(coords.inside);
    if (insideNode?.type.name === "orderedList") {
      return numberingPosFromOrderedListNode(view, coords.inside, event.clientY);
    }
    const insideHit = findOrderedListItem(doc, coords.inside);
    if (insideHit) return Math.min(insideHit.itemPos + 1, doc.content.size);
  }
  const posHit = findOrderedListItem(doc, coords.pos);
  return posHit ? coords.pos : null;
}

function listItemCount(node: PMNode): number {
  let count = 0;
  node.forEach((child) => {
    if (child.type.name === "listItem") count += 1;
  });
  return count;
}

function analyzeNode(
  node: PMNode,
  pos: number,
  counters: number[],
  depth: number,
  items: NumberedItem[],
  patches: ListPatch[],
): void {
  if (node.type.name === "heading") {
    counters.fill(0);
    return;
  }
  if (node.type.name === "orderedList") {
    const origin = normalizeOrigin(node.attrs.origin);
    const startAttr = Math.max(1, Number(node.attrs.start) || 1);
    const autoStart = (counters[depth] || 0) + 1;
    const nextOrigin = origin;
    const nextStart = origin === "auto" ? autoStart : startAttr;
    const currentStart = Math.max(1, Number(node.attrs.start) || 1);
    if (currentStart !== nextStart || normalizeOrigin(node.attrs.origin) !== nextOrigin) {
      patches.push({ pos, start: nextStart, origin: nextOrigin });
    }
    const itemCount = listItemCount(node);
    let n = nextStart - 1;
    let index = 0;
    node.forEach((child, innerOffset) => {
      if (child.type.name !== "listItem") return;
      n += 1;
      counters[depth] = n;
      for (let i = depth + 1; i < counters.length; i++) counters[i] = 0;
      const itemPos = pos + 1 + innerOffset;
      items.push({
        listPos: pos,
        itemPos,
        itemIndex: index,
        itemCount,
        depth,
        number: n,
        origin: nextOrigin,
        start: nextStart,
      });
      analyzeContent(child, itemPos, counters, depth + 1, items, patches);
      index += 1;
    });
    counters[depth] = n;
    return;
  }
  if (node.isText || !node.content.size) return;
  analyzeContent(node, pos, counters, depth, items, patches);
}

function analyzeContent(
  node: PMNode,
  pos: number,
  counters: number[],
  depth: number,
  items: NumberedItem[],
  patches: ListPatch[],
): void {
  node.forEach((child, innerOffset) => {
    analyzeNode(child, pos + 1 + innerOffset, counters, depth, items, patches);
  });
}

export function analyzeOrderedLists(doc: PMNode): { items: NumberedItem[]; patches: ListPatch[] } {
  const items: NumberedItem[] = [];
  const patches: ListPatch[] = [];
  const counters = Array.from({ length: MAX_LIST_DEPTH }, () => 0);
  analyzeContent(doc, -1, counters, 0, items, patches);
  return { items, patches };
}

export function collectNumberedItems(doc: PMNode): NumberedItem[] {
  return analyzeOrderedLists(doc).items;
}

function previousItemAtDepth(items: NumberedItem[], current: NumberedItem): NumberedItem | null {
  for (let i = items.length - 1; i >= 0; i--) {
    const item = items[i];
    if (item.itemPos < current.itemPos && item.depth === current.depth && item.listPos !== current.listPos) {
      return item;
    }
  }
  return null;
}

export function getNumberingMenuState(doc: PMNode, pos: number): NumberingMenuState | null {
  const ref = findOrderedListItem(doc, pos);
  if (!ref) return null;
  const items = collectNumberedItems(doc);
  const current =
    items.find((item) => item.listPos === ref.listPos && item.itemIndex === ref.itemIndex) ??
    items.find((item) => item.itemPos === ref.itemPos);
  if (!current) {
    const start = Math.max(1, Number(ref.listNode.attrs.start) || 1);
    return {
      canRestart: !(ref.itemIndex === 0 && start === 1),
      canContinue: true,
      value: start + ref.itemIndex,
      listPos: ref.listPos,
      itemIndex: ref.itemIndex,
    };
  }
  const prev = previousItemAtDepth(items, current);
  const canRestart = !(current.itemIndex === 0 && current.number === 1);
  const alreadyContinuing =
    current.itemIndex > 0 ||
    (!!prev && current.number === prev.number + 1 && current.origin !== "restart");
  const canContinue = Boolean(prev) && !alreadyContinuing;
  return {
    canRestart,
    canContinue,
    value: current.number,
    listPos: current.listPos,
    itemIndex: current.itemIndex,
  };
}

export function hasHeadingBetween(doc: PMNode, from: number, to: number): boolean {
  const lo = Math.max(0, Math.min(from, to));
  const hi = Math.min(doc.content.size, Math.max(from, to));
  if (hi <= lo) return false;
  let found = false;
  doc.nodesBetween(lo, hi, (node) => {
    if (node.type.name === "heading") {
      found = true;
      return false;
    }
    return true;
  });
  return found;
}

function splitListAtItem(tr: Transaction, listPos: number, itemIndex: number): number {
  const listNode = tr.doc.nodeAt(listPos);
  if (!listNode || itemIndex <= 0) return listPos;
  let cut = 0;
  let seen = 0;
  listNode.forEach((child) => {
    if (seen >= itemIndex) return;
    cut += child.nodeSize;
    if (child.type.name === "listItem") seen += 1;
  });
  const firstContent = listNode.content.cut(0, cut);
  const restContent = listNode.content.cut(cut);
  if (!firstContent.size || !restContent.size) return listPos;
  const first = listNode.type.create(listNode.attrs, firstContent);
  const second = listNode.type.create(listNode.attrs, restContent);
  tr.replaceWith(listPos, listPos + listNode.nodeSize, Fragment.from([first, second]));
  return listPos + first.nodeSize;
}

function applyListAttrs(tr: Transaction, listPos: number, origin: ListOrigin, start: number): void {
  const node = tr.doc.nodeAt(listPos);
  if (!node || node.type.name !== "orderedList") return;
  tr.setNodeMarkup(listPos, undefined, { ...node.attrs, origin, start: Math.max(1, Math.floor(start)) });
}

const orderedListKey = new PluginKey("orderedListContinuity");

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    orderedListContinuity: {
      restartOrderedList: () => ReturnType;
      continueOrderedList: () => ReturnType;
      setOrderedListValue: (value: number) => ReturnType;
    };
  }
}

export const OrderedListContinuity = Extension.create({
  name: "orderedListContinuity",

  addGlobalAttributes() {
    return [
      {
        types: ["orderedList"],
        attributes: {
          origin: {
            default: "auto",
            parseHTML: (element) => {
              const raw = element.getAttribute("data-origin");
              return raw === "restart" || raw === "manual" ? raw : "auto";
            },
            renderHTML: (attributes) => {
              if (attributes.origin === "restart" || attributes.origin === "manual") {
                return { "data-origin": attributes.origin };
              }
              return {};
            },
          },
        },
      },
    ];
  },

  addCommands() {
    return {
      restartOrderedList:
        () =>
        ({ tr, dispatch }) => {
          const ref = findOrderedListItem(tr.doc, tr.selection.from);
          const menu = getNumberingMenuState(tr.doc, tr.selection.from);
          if (!ref || !menu?.canRestart) return false;
          if (!dispatch) return true;
          const listPos = ref.itemIndex > 0 ? splitListAtItem(tr, ref.listPos, ref.itemIndex) : ref.listPos;
          applyListAttrs(tr, listPos, "restart", 1);
          return true;
        },
      continueOrderedList:
        () =>
        ({ tr, dispatch }) => {
          const ref = findOrderedListItem(tr.doc, tr.selection.from);
          const menu = getNumberingMenuState(tr.doc, tr.selection.from);
          if (!ref || !menu?.canContinue) return false;
          const items = collectNumberedItems(tr.doc);
          const current = items.find((item) => item.listPos === ref.listPos && item.itemIndex === ref.itemIndex);
          if (!current) return false;
          const prev = previousItemAtDepth(items, current);
          if (!prev) return false;
          if (!dispatch) return true;
          const nextStart = prev.number + 1;
          const crossed = hasHeadingBetween(tr.doc, prev.itemPos, ref.listPos);
          applyListAttrs(tr, ref.listPos, crossed ? "manual" : "auto", nextStart);
          return true;
        },
      setOrderedListValue:
        (value: number) =>
        ({ tr, dispatch }) => {
          const ref = findOrderedListItem(tr.doc, tr.selection.from);
          const next = Math.max(1, Math.floor(Number(value) || 1));
          if (!ref) return false;
          if (!dispatch) return true;
          const listPos = ref.itemIndex > 0 ? splitListAtItem(tr, ref.listPos, ref.itemIndex) : ref.listPos;
          applyListAttrs(tr, listPos, next <= 1 ? "restart" : "manual", next);
          return true;
        },
    };
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: orderedListKey,
        appendTransaction(transactions, _oldState, newState) {
          if (transactions.some((tr) => tr.getMeta(orderedListKey))) return null;
          if (!transactions.some((tr) => tr.docChanged)) return null;
          const { patches } = analyzeOrderedLists(newState.doc);
          if (!patches.length) return null;
          const tr = newState.tr;
          for (const patch of [...patches].reverse()) {
            const node = tr.doc.nodeAt(patch.pos);
            if (!node || node.type.name !== "orderedList") continue;
            const start = Math.max(1, Number(node.attrs.start) || 1);
            const origin = normalizeOrigin(node.attrs.origin);
            if (start === patch.start && origin === patch.origin) continue;
            tr.setNodeMarkup(patch.pos, undefined, { ...node.attrs, start: patch.start, origin: patch.origin });
          }
          if (!tr.docChanged) return null;
          tr.setMeta(orderedListKey, true);
          tr.setMeta("addToHistory", false);
          return tr;
        },
      }),
    ];
  },
});

function walkHtml(
  parent: ParentNode,
  counters: number[],
  depth: number,
): void {
  let pendingRestart = false;
  let pendingManual: false | number | true = false;
  for (const child of Array.from(parent.childNodes)) {
    if (child.nodeType === Node.COMMENT_NODE) {
      const text = (child.textContent || "").trim();
      if (text === RESTART_COMMENT) pendingRestart = true;
      else {
        const manual = text.match(MANUAL_COMMENT_RE);
        if (manual) pendingManual = manual[1] ? parseInt(manual[1], 10) : true;
      }
      continue;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;
    const el = child as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (/^h[1-6]$/.test(tag)) {
      counters.fill(0);
      pendingRestart = false;
      pendingManual = false;
      continue;
    }
    if (tag === "ol") {
      const startAttr = Math.max(1, parseInt(el.getAttribute("start") || "1", 10) || 1);
      const autoStart = (counters[depth] || 0) + 1;
      const manualStart = typeof pendingManual === "number" ? pendingManual : null;
      let origin = normalizeOrigin(el.getAttribute("data-origin"));
      if (pendingRestart) origin = "restart";
      else if (pendingManual !== false) {
        origin = "manual";
        if (manualStart != null) el.setAttribute("start", String(Math.max(1, manualStart)));
      } else if (!el.hasAttribute("data-origin")) {
        origin = "auto";
      }
      pendingRestart = false;
      pendingManual = false;
      if (origin === "restart" || origin === "manual") el.setAttribute("data-origin", origin);
      else el.removeAttribute("data-origin");
      const nextStart =
        origin === "auto"
          ? autoStart
          : origin === "manual" && manualStart != null
            ? Math.max(1, manualStart)
            : Math.max(1, parseInt(el.getAttribute("start") || String(startAttr), 10) || startAttr);
      if (nextStart === 1) el.removeAttribute("start");
      else el.setAttribute("start", String(nextStart));
      let n = nextStart - 1;
      for (const li of Array.from(el.children)) {
        if (li.tagName.toLowerCase() !== "li") continue;
        n += 1;
        counters[depth] = n;
        for (let i = depth + 1; i < counters.length; i++) counters[i] = 0;
        walkHtml(li, counters, depth + 1);
      }
      counters[depth] = n;
      continue;
    }
    pendingRestart = false;
    pendingManual = false;
    walkHtml(el, counters, depth);
  }
}

function isOriginComment(text: string): boolean {
  const trimmed = text.trim();
  return trimmed === RESTART_COMMENT || MANUAL_COMMENT_RE.test(trimmed);
}

function stripOriginComments(root: ParentNode): void {
  for (const node of Array.from(root.childNodes)) {
    if (node.nodeType === Node.COMMENT_NODE && isOriginComment(node.textContent || "")) {
      node.parentNode?.removeChild(node);
    }
  }
  if (root instanceof Element) {
    root.querySelectorAll("*").forEach((el) => {
      for (const node of Array.from(el.childNodes)) {
        if (node.nodeType === Node.COMMENT_NODE && isOriginComment(node.textContent || "")) {
          node.parentNode?.removeChild(node);
        }
      }
    });
  }
}

/** Mark restart/manual lists in HTML from Markdown so TipTap keeps sequence breaks. */
export function stampOrderedListOrigins(html: string): string {
  if (!html || typeof DOMParser === "undefined") return html;
  const prepared = html
    .replace(/<!--\s*ol-origin:restart\s*-->\s*<ol\b([^>]*)>/gi, '<ol data-origin="restart"$1>')
    .replace(/<!--\s*ol-origin:manual(?::(\d+))?\s*-->\s*<ol\b([^>]*)>/gi, (_match, value, attrs) => {
      const start = value ? ` start="${value}"` : "";
      const cleaned = String(attrs || "").replace(/\sstart="[^"]*"/i, "");
      return `<ol data-origin="manual"${cleaned}${start}>`;
    });
  const doc = new DOMParser().parseFromString(`<div class="ol-stamp-root">${prepared}</div>`, "text/html");
  const root = doc.body.querySelector(".ol-stamp-root");
  if (!root) return html;
  const counters = Array.from({ length: MAX_LIST_DEPTH }, () => 0);
  walkHtml(root, counters, 0);
  stripOriginComments(root);
  return root.innerHTML;
}

export function orderedListOriginPrefix(
  origin: string | null | undefined,
  start: string | null | undefined,
  itemIndex: number,
): string {
  if (itemIndex !== 0) return "";
  if (origin === "restart") return `<!-- ${RESTART_COMMENT} -->\n\n`;
  if (origin === "manual") {
    const n = Math.max(1, parseInt(start || "1", 10) || 1);
    return `<!-- ol-origin:manual:${n} -->\n\n`;
  }
  return "";
}
