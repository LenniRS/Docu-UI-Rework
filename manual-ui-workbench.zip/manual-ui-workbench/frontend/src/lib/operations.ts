import { useCallback, useRef, useState } from "react";

/**
 * Centralized operation-state model.
 *
 * Every long-running or document-changing operation in the app reports its
 * state through a single `OperationState`. This one object drives several UI
 * surfaces at once:
 *   - the global ActivityIndicator in the toolbar,
 *   - the chat OperationCard for AI edits,
 *   - the editor section highlight + outline badges,
 *   - the save/dirty indicator,
 *   - the video processing progress.
 *
 * The state lives in `App.tsx` (via `useOperationState`) and is passed down by
 * props, matching the existing prop-drilling architecture (no state library).
 */

export type OperationType =
  | "video_upload"
  | "video_processing"
  | "manual_generation"
  | "chat_question"
  | "ai_edit"
  | "section_apply"
  | "manual_save"
  | "export";

export type OperationStatus = "idle" | "running" | "success" | "error";

export type OperationTarget =
  | { type: "section"; sectionNumber?: string; heading?: string }
  | { type: "video" }
  | { type: "manual" }
  | { type: "export" };

export type OperationState = {
  id: string;
  type: OperationType;
  status: OperationStatus;
  label: string;
  target?: OperationTarget;
  step?: string;
  progress?: { current?: number; total?: number; percent?: number };
  error?: string;
  startedAt: number;
};

let opCounter = 0;
function nextId(): string {
  opCounter += 1;
  return `op-${Date.now()}-${opCounter}`;
}

export type OperationControls = {
  operation: OperationState | null;
  /** Start a new operation (replaces any current one). */
  start: (op: Omit<OperationState, "id" | "status" | "startedAt">) => void;
  /** Update the running operation's label/step/progress/target. */
  update: (patch: Partial<Pick<OperationState, "label" | "step" | "progress" | "target">>) => void;
  /** Mark the current operation as successful. */
  succeed: (label?: string) => void;
  /** Mark the current operation as failed with an error message. */
  fail: (error: string) => void;
  /** Clear the current operation entirely (no lingering success/error pill). */
  clear: () => void;
};

/**
 * Holds a single active operation and exposes control functions. Success and
 * error states auto-clear after a short delay so the indicator does not linger.
 */
export function useOperationState(): OperationControls {
  const [operation, setOperation] = useState<OperationState | null>(null);
  const clearTimer = useRef<number | null>(null);

  const scheduleClear = useCallback((ms: number) => {
    if (clearTimer.current) window.clearTimeout(clearTimer.current);
    clearTimer.current = window.setTimeout(() => {
      setOperation(null);
      clearTimer.current = null;
    }, ms);
  }, []);

  const start = useCallback((op: Omit<OperationState, "id" | "status" | "startedAt">) => {
    if (clearTimer.current) {
      window.clearTimeout(clearTimer.current);
      clearTimer.current = null;
    }
    setOperation({ ...op, id: nextId(), status: "running", startedAt: Date.now() });
  }, []);

  const update = useCallback(
    (patch: Partial<Pick<OperationState, "label" | "step" | "progress" | "target">>) => {
      setOperation((cur) => (cur ? { ...cur, ...patch } : cur));
    },
    [],
  );

  const succeed = useCallback(
    (label?: string) => {
      setOperation((cur) =>
        cur ? { ...cur, status: "success", label: label ?? cur.label, error: undefined } : cur,
      );
      scheduleClear(2500);
    },
    [scheduleClear],
  );

  const fail = useCallback(
    (error: string) => {
      setOperation((cur) => (cur ? { ...cur, status: "error", error } : cur));
      scheduleClear(6000);
    },
    [scheduleClear],
  );

  const clear = useCallback(() => {
    if (clearTimer.current) {
      window.clearTimeout(clearTimer.current);
      clearTimer.current = null;
    }
    setOperation(null);
  }, []);

  return { operation, start, update, succeed, fail, clear };
}

/**
 * Map an operation to a short, human-readable German label for the global
 * ActivityIndicator. Falls back to the operation's own label when set.
 */
export function operationLabel(op: OperationState): string {
  if (op.label) return op.label;
  switch (op.type) {
    case "video_upload":
      return "Video wird hochgeladen…";
    case "video_processing":
      return "Video wird verarbeitet…";
    case "manual_generation":
      return "Manual wird generiert…";
    case "chat_question":
      return "KI analysiert Anfrage…";
    case "ai_edit":
      return "KI bearbeitet das Manual…";
    case "section_apply":
      return "Abschnitt wird aktualisiert…";
    case "manual_save":
      return "Speichere Änderungen…";
    case "export":
      return "Export läuft…";
    default:
      return "Arbeit läuft…";
  }
}

/**
 * Precise chat status text for an AI-edit operation, replacing the generic
 * "schreibt…". Mirrors the `ChatOperationState` mapping from the UX request.
 */
export function chatStatusText(op: OperationState | null): string {
  if (!op) return "schreibt…";
  if (op.status === "success") return "Änderung übernommen.";
  if (op.status === "error") return "Änderung fehlgeschlagen.";
  switch (op.step) {
    case "thinking":
      return "KI analysiert Anfrage…";
    case "generating_edit":
      return "KI erstellt Änderung…";
    case "resolving_target":
      return "Zielabschnitt wird gesucht…";
    case "validating_edit":
      return "Änderung wird geprüft…";
    case "applying_edit":
      return "Änderung wird im Manual angewendet…";
    case "saving":
      return "Speichere manual.md…";
    default:
      return op.label || "schreibt…";
  }
}
