import type { ProjectFile } from "../types";

function pad2(n: number): string {
  return n.toString().padStart(2, "0");
}

export function isFiniteTime(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

/** Editor overlay time: MM:SS, or HH:MM:SS when the video is at least one hour. */
export function formatOverlayTime(seconds: number, videoDuration: number): string {
  const total = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const duration = Number.isFinite(videoDuration) ? videoDuration : 0;
  const showHours = duration >= 3600 || total >= 3600;
  if (showHours) return `${pad2(hours)}:${pad2(minutes)}:${pad2(secs)}`;
  return `${pad2(minutes)}:${pad2(secs)}`;
}

export function timestampsFromFiles(
  files: { name: string; time?: number }[],
  extra?: Record<string, number>,
): Record<string, number> {
  const out: Record<string, number> = {};
  if (extra) {
    for (const [name, time] of Object.entries(extra)) {
      if (isFiniteTime(time)) out[name] = time;
    }
  }
  for (const file of files) {
    if (isFiniteTime(file.time)) out[file.name] = file.time;
  }
  return out;
}

/** Incoming finite times win, then extraTimes, then previously known times. Null inventory times are not kept. */
export function mergeIncomingFiles(
  previous: ProjectFile[] | undefined,
  incoming: ProjectFile[] | undefined,
  extraTimes?: Record<string, number> | null,
): { files: ProjectFile[]; timestamps: Record<string, number> } {
  const prevTimes = timestampsFromFiles(previous || []);
  const extra: Record<string, number> = {};
  if (extraTimes) {
    for (const [name, time] of Object.entries(extraTimes)) {
      if (isFiniteTime(time)) extra[name] = time;
    }
  }
  const source = incoming && incoming.length > 0 ? incoming : previous || [];
  const files = source.map((file) => {
    const incomingTime = isFiniteTime(file.time) ? file.time : undefined;
    const time = incomingTime ?? extra[file.name] ?? prevTimes[file.name];
    return time != null ? { ...file, time } : { ...file, time: undefined };
  });
  return { files, timestamps: { ...prevTimes, ...extra, ...timestampsFromFiles(files) } };
}
