/** Shared helpers for the council chat feature. */

export type CouncilEdit =
  | {
      type: "replace";
      old_text: string;
      new_text: string;
    }
  | {
      type: "replace_section";
      section: string;
      new_text: string;
    }
  | {
      type: "replace_section_body";
      section: string;
      new_body: string;
    }
  | {
      type: "rename_heading";
      section: string;
      new_heading: string;
    };

export type ParsedReply = {
  text: string;
  edit: CouncilEdit | null;
};

/**
 * Tolerantly extract a JSON object from an assistant reply.
 *
 * The LLM may wrap the JSON in markdown fences or surround it with prose. We
 * strip fences and locate the first balanced {...} block so a valid edit
 * proposal is never missed. Returns null if no object can be found.
 */
function extractJsonObject(text: string): Record<string, unknown> | null {
  let raw = (text || "").trim();
  if (raw.startsWith("```")) {
    raw = raw.replace(/^```[a-zA-Z]*\s*/, "").replace(/\s*```$/, "");
  }
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    const data = JSON.parse(raw.slice(start, end + 1));
    return data && typeof data === "object" ? (data as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** Parse an assistant reply. It may be plain text or a JSON edit proposal. */
export function parseAssistantReply(content: string): ParsedReply {
  const data = extractJsonObject(content);
  if (data) {
    const edit = data.edit;
    const message = typeof data.message === "string" ? data.message : "";

    if (edit && typeof edit === "object") {
      const e = edit as Record<string, unknown>;
      const editType = typeof e.type === "string" ? e.type : "replace";

      // Whole-section edit: the app locates the section by number.
      if (editType === "replace_section") {
        const section = typeof e.section === "string" ? e.section : "";
        const newText = typeof e.new_text === "string" ? e.new_text : "";
        if (section && newText) {
          return {
            text: message || "Ein Abschnitt wurde zur Übernahme vorbereitet.",
            edit: { type: "replace_section", section, new_text: newText },
          };
        }
      }

      // Body-only edit: replace the content under a heading, keep the heading.
      if (editType === "replace_section_body") {
        const section = typeof e.section === "string" ? e.section : "";
        const newBody = typeof e.new_body === "string" ? e.new_body : "";
        if (section && newBody) {
          return {
            text: message || "Der Abschnittsinhalt wurde zur Übernahme vorbereitet.",
            edit: { type: "replace_section_body", section, new_body: newBody },
          };
        }
      }

      // Heading-only edit: rename the heading, keep the section number.
      if (editType === "rename_heading") {
        const section = typeof e.section === "string" ? e.section : "";
        const newHeading = typeof e.new_heading === "string" ? e.new_heading : "";
        if (section && newHeading) {
          return {
            text: message || "Die Überschrift wurde zur Übernahme vorbereitet.",
            edit: { type: "rename_heading", section, new_heading: newHeading },
          };
        }
      }

      // Small inline edit: exact old_text/new_text replacement.
      const oldText = typeof e.old_text === "string" ? e.old_text : "";
      const newText = typeof e.new_text === "string" ? e.new_text : "";
      if (oldText && newText) {
        return {
          text: message || "Eine Änderung wurde zur Übernahme vorbereitet.",
          edit: { type: "replace", old_text: oldText, new_text: newText },
        };
      }
    }

    // The reply is a JSON object but not a usable edit. Do NOT surface the raw
    // JSON blob in the chat — show a clean message instead.
    if (message) {
      return { text: message, edit: null };
    }
  }

  // The reply could not be parsed as JSON. If it looks like a (possibly
  // truncated) JSON edit attempt, do NOT dump the raw blob into the chat —
  // show a clean fallback message instead.
  const trimmed = (content || "").trim();
  if (trimmed.startsWith("{") || trimmed.startsWith("```")) {
    return {
      text: "Die KI hat eine Antwort geliefert, die nicht als Änderung verarbeitet werden konnte.",
      edit: null,
    };
  }

  return { text: content, edit: null };
}
