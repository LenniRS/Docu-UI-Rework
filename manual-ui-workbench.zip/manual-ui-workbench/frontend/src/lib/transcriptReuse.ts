import type { ProjectRecord } from "../types";

/** True when the current video's transcript may be reused for generation. */
export function hasReusableTranscript(record: ProjectRecord | null | undefined): boolean {
  return Boolean(record?.transcript?.trim()) && record?.transcriptReusable !== false;
}
