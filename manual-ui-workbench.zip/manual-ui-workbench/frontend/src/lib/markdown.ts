import { marked } from "marked";
import TurndownService from "turndown";
import { orderedListOriginPrefix, stampOrderedListOrigins } from "./listNumbers";

marked.setOptions({ gfm: true, breaks: true });

const turndown = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced" });
turndown.keep(["iframe"]);
turndown.addRule("images", {
  filter: "img",
  replacement(_content, node) {
    const el = node as HTMLImageElement;
    const alt = el.getAttribute("alt") || "";
    const src = el.getAttribute("src") || "";
    return `![${alt}](${src})`;
  },
});
turndown.addRule("listItemWithOrigin", {
  filter: "li",
  replacement(content, node, options) {
    const body = content.replace(/^\n+/, "").replace(/\n+$/, "\n").replace(/\n/gm, "\n    ");
    let prefix = `${options.bulletListMarker || "*"} `;
    const parent = node.parentNode as HTMLElement | null;
    if (parent?.nodeName === "OL") {
      const start = parent.getAttribute("start");
      const index = Array.prototype.indexOf.call(parent.children, node);
      const n = (start ? Number(start) + index : index + 1);
      prefix = `${orderedListOriginPrefix(parent.getAttribute("data-origin"), parent.getAttribute("start"), index)}${n}. `;
    }
    return prefix + body + (node.nextSibling && !/\n$/.test(body) ? "\n" : "");
  },
});
// Turndown has no built-in table support — it would flatten a <table> into
// flow text and destroy the structure on save/export. This rule converts a
// <table> back into a GFM Markdown table (header row + separator + body rows),
// matching what `marked` produces from the generated manuals. Cell content is
// run through Turndown so inline formatting (e.g. **bold**) is preserved.
turndown.addRule("table", {
  filter: "table",
  replacement(_content, node) {
    const table = node as HTMLTableElement;
    const rows = Array.from(table.querySelectorAll("tr"));
    if (!rows.length) return "";

    const cellText = (cell: Element) =>
      turndown
        .turndown(cell.innerHTML || "")
        .replace(/\s+/g, " ")
        .trim();

    const renderRow = (cells: string[]) =>
      `| ${cells.join(" | ")} |`;

    const headerCells = Array.from(rows[0].querySelectorAll("th, td")).map(cellText);
    const bodyRows = rows.slice(1).map((row) =>
      renderRow(Array.from(row.querySelectorAll("th, td")).map(cellText)),
    );

    const separator = headerCells.map(() => "---").join(" | ");
    const lines = [renderRow(headerCells), `| ${separator} |`, ...bodyRows];
    return `\n\n${lines.join("\n")}\n\n`;
  },
});

export function markdownToHtml(markdown: string): string {
  let html = marked.parse(markdown || "", { async: false }) as string;
  // The editor renders tables as atom nodes (TableExtension.tsx) that store
  // the full <table> HTML in a data-html attribute. `marked` (gfm) emits
  // <table>…</table>; wrap each one so TipTap keeps it intact instead of trying
  // to parse rows/cells into its own schema (which would drop them).
  html = html.replace(/<table>([\s\S]*?)<\/table>/g, (_m, inner) => {
    const full = `<table>${inner}</table>`;
    const encoded = full
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    return `<table data-html="${encoded}"></table>`;
  });
  return stampOrderedListOrigins(html);
}

export function htmlToMarkdown(html: string): string {
  // Restore the table HTML stored in the atom node's data-html attribute back
  // into a real <table> so turndown can convert it to a Markdown table.
  const restored = html.replace(
    /<table data-html="([^"]*)"><\/table>/g,
    (_m, encoded) => {
      const inner = encoded
        .replace(/&gt;/g, ">")
        .replace(/&lt;/g, "<")
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, "&");
      return inner;
    }
  );
  return turndown.turndown(restored || "");
}

export function filenameFromSrc(src: string, alt?: string): string {
  try {
    const path = src.split("?")[0];
    const base = decodeURIComponent(path.split("/").pop() || "");
    if (base) return base;
  } catch {
    /* ignore */
  }
  return alt || "picture.jpg";
}
