/**
 * Passage matching for the "Im Manual anzeigen" (show in manual) feature.
 *
 * The council points carry a `passage` (a quote/reference to the criticized
 * content) and a `section` (the heading of the relevant manual section). The
 * passage is often a paraphrase rather than a verbatim quote, and sometimes
 * describes content that is absent from the manual. This module resolves a
 * passage + section hint against the actual document into a concrete location
 * to jump to and highlight.
 *
 * The matching is tiered so that a sensible location is found even when the
 * passage wording does not appear verbatim:
 *   1. Heading match (passage or section names a real heading)
 *   2. Verbatim word run inside the hinted section
 *   3. Verbatim word run anywhere in the document
 *   4. Fuzzy word-overlap match (content words weighted), preferring the section
 *   5. Section fallback (jump to the hinted section heading)
 *   6. No match
 */

export type DocWord = { word: string; from: number; to: number };
export type DocHeading = { level: number; text: string; pos: number };

export type PassageMatch =
  | { status: "match"; from: number; to: number }
  | { status: "section"; headingPos: number }
  | { status: "none" };

/** Stopwords (EN + DE) that carry little meaning for locating a passage. */
const STOPWORDS = new Set([
  // English
  "the", "a", "an", "and", "or", "but", "of", "to", "in", "on", "at", "for",
  "with", "is", "are", "was", "were", "be", "been", "being", "it", "its",
  "this", "that", "these", "those", "as", "by", "from", "not", "no", "so",
  "if", "then", "than", "too", "very", "can", "will", "would", "should",
  "may", "must", "into", "over", "under", "between", "through", "during",
  "before", "after", "above", "below", "up", "down", "out", "off", "about",
  "also", "only", "just", "more", "most", "other", "some", "such", "each",
  "any", "all", "both", "own", "same", "there", "here", "when", "where",
  "which", "who", "whom", "whose", "what", "how", "why", "has", "have", "had",
  "do", "does", "did", "done", "shall", "could", "might", "per", "via",
  // German
  "der", "die", "das", "den", "dem", "des", "ein", "eine", "einer", "einem",
  "einen", "und", "oder", "aber", "zu", "in", "im", "an", "auf", "bei", "mit",
  "ist", "sind", "war", "waren", "sein", "seine", "seiner", "ihr", "ihre",
  "dies", "diese", "dieser", "diesem", "diesen", "als", "von", "vom", "aus",
  "nicht", "nein", "so", "wenn", "dann", "als", "auch", "nur", "noch", "mehr",
  "über", "unter", "zwischen", "durch", "während", "vor", "nach", "oben",
  "unten", "hinaus", "hin", "her", "etwa", "jede", "jeder", "jedes", "alle",
  "man", "wer", "was", "wie", "warum", "hat", "haben", "hatte", "kann",
  "können", "soll", "sollen", "muss", "müssen", "wird", "werden", "wurde",
]);

/** Normalize a string for matching: lowercase, strip punctuation, collapse whitespace. */
export function normalize(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s.-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Tokenize a string into matching tokens. Keeps technical terms with dots,
 * hyphens and ampersands (e.g. "192.168.29.2", "R&S", "EM200") as single
 * tokens where possible, and drops pure stopwords.
 */
export function tokenize(text: string): string[] {
  const normalized = normalize(text);
  if (!normalized) return [];
  // Split on whitespace, then further split tokens that mix a technical term
  // with surrounding words (e.g. "address'192.168.29.2'").
  const raw = normalized.split(" ");
  const tokens: string[] = [];
  for (const part of raw) {
    // Keep dotted/hyphenated/ampersand technical tokens whole.
    if (/^[\p{L}\p{N}][\p{L}\p{N}.\-&]*$/u.test(part)) {
      tokens.push(part);
    } else {
      // Otherwise split into alphanumeric runs.
      for (const m of part.match(/[\p{L}\p{N}]+/gu) || []) tokens.push(m);
    }
  }
  return tokens;
}

/** Content tokens (non-stopwords) of a string. */
export function contentTokens(text: string): string[] {
  return tokenize(text).filter((t) => !STOPWORDS.has(t));
}

/** Normalize a heading for comparison (lowercase, trim, collapse whitespace). */
function normHeading(text: string): string {
  return text.toLowerCase().replace(/\s+/g, " ").trim();
}

/**
 * Find the heading whose normalized text best matches the given hint.
 * Returns the heading index, or -1 if none matches well enough.
 */
function findHeading(headings: DocHeading[], hint: string): number {
  const target = normHeading(hint);
  if (!target) return -1;
  const targetTokens = contentTokens(target);
  if (targetTokens.length === 0) return -1;

  let bestIdx = -1;
  let bestScore = 0;
  for (let i = 0; i < headings.length; i++) {
    const hTokens = contentTokens(headings[i].text);
    if (hTokens.length === 0) continue;
    // Score = fraction of hint content tokens present in the heading.
    let hits = 0;
    for (const t of targetTokens) {
      if (hTokens.includes(t)) hits++;
    }
    const score = hits / targetTokens.length;
    // Require at least half the hint tokens to match, and at least one.
    if (score >= 0.5 && score > bestScore) {
      bestScore = score;
      bestIdx = i;
    }
  }
  return bestIdx;
}

/**
 * Find a heading whose text contains a distinctive content token of the
 * passage (e.g. "troubleshooting" -> "Troubleshooting"). Returns the heading
 * index, or -1. Only distinctive tokens (length >= 4, not a stopword) count,
 * to avoid matching on generic words like "manual" or "section".
 */
function findHeadingByToken(headings: DocHeading[], passageTokens: string[]): number {
  const distinctive = passageTokens.filter((t) => !STOPWORDS.has(t) && t.length >= 4);
  if (distinctive.length === 0) return -1;
  for (let i = 0; i < headings.length; i++) {
    const hTokens = contentTokens(headings[i].text);
    for (const t of distinctive) {
      if (hTokens.includes(t)) return i;
    }
  }
  return -1;
}

/** Word range (in doc-word indices) covered by a heading's section. */
function sectionWordRange(
  headings: DocHeading[],
  headingIdx: number,
  docWords: DocWord[],
): { start: number; end: number } {
  const startPos = headings[headingIdx].pos;
  const endPos =
    headingIdx + 1 < headings.length ? headings[headingIdx + 1].pos : Number.MAX_SAFE_INTEGER;
  let start = 0;
  let end = docWords.length;
  for (let i = 0; i < docWords.length; i++) {
    if (docWords[i].from >= startPos && start === 0) start = i;
    if (docWords[i].from >= endPos) {
      end = i;
      break;
    }
  }
  return { start, end };
}

/**
 * Find the longest contiguous run of passage tokens that appears verbatim in
 * the given doc-word range. Returns the doc-word index range, or null.
 */
function longestVerbatimRun(
  passageTokens: string[],
  docWords: DocWord[],
  range: { start: number; end: number },
): { start: number; len: number } | null {
  let bestStart = -1;
  let bestLen = 0;
  for (let s = 0; s < passageTokens.length; s++) {
    const first = passageTokens[s];
    for (let d = range.start; d < range.end; d++) {
      if (docWords[d].word !== first) continue;
      let run = 0;
      while (
        s + run < passageTokens.length &&
        d + run < range.end &&
        docWords[d + run].word === passageTokens[s + run]
      ) {
        run++;
      }
      if (run > bestLen) {
        bestLen = run;
        bestStart = d;
      }
    }
  }
  if (bestLen < 3 || bestStart < 0) return null;
  return { start: bestStart, len: bestLen };
}

/**
 * Fuzzy match: score each doc-word window by content-word overlap with the
 * passage, preferring the hinted section. Returns the best doc-word index
 * range, or null.
 */
function fuzzyMatch(
  passageTokens: string[],
  docWords: DocWord[],
  range: { start: number; end: number },
): { start: number; len: number } | null {
  const passageContent = passageTokens.filter((t) => !STOPWORDS.has(t));
  if (passageContent.length === 0) return null;

  // Window size ~ one sentence (up to 40 words).
  const windowSize = Math.min(40, Math.max(8, passageContent.length * 3));
  let bestStart = -1;
  let bestScore = 0;
  let bestLen = 0;

  for (let d = range.start; d < range.end; d++) {
    const end = Math.min(d + windowSize, range.end);
    let hits = 0;
    const seen = new Set<string>();
    for (let i = d; i < end; i++) {
      const w = docWords[i].word;
      if (STOPWORDS.has(w) || seen.has(w)) continue;
      if (passageContent.includes(w)) {
        hits++;
        seen.add(w);
      }
    }
    // Score by number of distinct content-word hits, with a small bonus for
    // longer runs.
    const score = hits + (end - d) / 1000;
    if (score > bestScore) {
      bestScore = score;
      bestStart = d;
      bestLen = end - d;
    }
  }

  // Require at least 2 distinct content-word hits.
  if (bestScore < 2 || bestStart < 0) return null;
  return { start: bestStart, len: bestLen };
}

export type MatchInput = {
  passage: string;
  section?: string;
  kind?: string;
  docWords: DocWord[];
  headings: DocHeading[];
};

/**
 * Resolve a passage + section hint to a concrete location in the document.
 * Returns a PassageMatch describing what to do.
 */
export function resolvePassage(input: MatchInput): PassageMatch {
  const { passage, section, docWords, headings } = input;
  const passageTokens = tokenize(passage || "");
  const sectionHint = (section || "").trim();

  // Tier 1 — heading match from the section hint or the passage itself.
  if (sectionHint) {
    const idx = findHeading(headings, sectionHint);
    if (idx >= 0) return { status: "section", headingPos: headings[idx].pos };
  }
  if (passageTokens.length > 0) {
    const idx = findHeading(headings, passage);
    if (idx >= 0) return { status: "section", headingPos: headings[idx].pos };
  }

  // Determine the section word range if a section hint resolves to a heading.
  let sectionRange: { start: number; end: number } | null = null;
  if (sectionHint) {
    const idx = findHeading(headings, sectionHint);
    if (idx >= 0) sectionRange = sectionWordRange(headings, idx, docWords);
  }

  // Tier 2 — verbatim run inside the hinted section.
  if (sectionRange && passageTokens.length > 0) {
    const run = longestVerbatimRun(passageTokens, docWords, sectionRange);
    if (run) {
      return {
        status: "match",
        from: docWords[run.start].from,
        to: docWords[run.start + run.len - 1].to,
      };
    }
  }

  // Tier 3 — verbatim run anywhere.
  if (passageTokens.length > 0) {
    const run = longestVerbatimRun(passageTokens, docWords, { start: 0, end: docWords.length });
    if (run) {
      return {
        status: "match",
        from: docWords[run.start].from,
        to: docWords[run.start + run.len - 1].to,
      };
    }
  }

  // Tier 4 — single distinctive heading token: if a distinctive content word of
  // the passage names a real heading (e.g. "troubleshooting" -> "Troubleshooting"),
  // navigate there. This trusts the manual over the passage's wording: if the
  // section exists, the user should see it even when the passage claims it is
  // absent. This runs BEFORE the fuzzy match because a heading name is a far
  // more precise signal than a fuzzy word-overlap window.
  if (passageTokens.length > 0) {
    const idx = findHeadingByToken(headings, passageTokens);
    if (idx >= 0) return { status: "section", headingPos: headings[idx].pos };
  }

  // Tier 5 — fuzzy match (prefer the section, then the whole doc).
  if (passageTokens.length > 0) {
    if (sectionRange) {
      const run = fuzzyMatch(passageTokens, docWords, sectionRange);
      if (run) {
        return {
          status: "match",
          from: docWords[run.start].from,
          to: docWords[run.start + run.len - 1].to,
        };
      }
    }
    const run = fuzzyMatch(passageTokens, docWords, { start: 0, end: docWords.length });
    if (run) {
      return {
        status: "match",
        from: docWords[run.start].from,
        to: docWords[run.start + run.len - 1].to,
      };
    }
  }

  // Tier 6 — section fallback: jump to the hinted section heading.
  if (sectionHint) {
    const idx = findHeading(headings, sectionHint);
    if (idx >= 0) return { status: "section", headingPos: headings[idx].pos };
  }

  // Tier 7 — no match.
  return { status: "none" };
}
