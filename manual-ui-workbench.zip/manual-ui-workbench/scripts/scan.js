#!/usr/bin/env node
/**
 * Sensitive-content scan for the sanitized UI workbench.
 *
 * Scans all files for restricted file types and sensitive terms. Reports any
 * hits so they can be removed or anonymized.
 *
 * Usage:
 *   node scripts/scan.js
 */
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");

// Restricted file extensions (never allowed in this workspace).
const BAD_EXT = /\.(pdf|docx?|xlsx?|pptx?|zip|7z|rar|mp4|mov|avi|mkv|wav|mp3|png|jpe?g|tiff?|bmp)$/i;

// Sensitive terms to search for in text files.
const BAD_TERMS = [
  "style_guide",
  "Redaktionshandbuch",
  "S1000D",
  "EAGLE",
  "COSIMA",
  "DIN ",
  "ASD-STE",
  "restricted",
  "confidential",
  "RS_Docu",
  "Venus",
  "PR200",
  "plm-ai-gateway",
  "npm.packages.rsint.net",
];

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".git") continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

// Meta-documentation files that legitimately describe the exclusions.
const META_FILES = new Set([
  "README.md",
  "SECURITY_NOTES.md",
  "EXCLUDED_FILES_REPORT.md",
  "INCLUDED_FILES_MANIFEST.json",
  "scripts/scan.js",
]);

const files = walk(ROOT);
let problems = 0;

console.log("Scanning", files.length, "files...\n");

// 1. Restricted file types
for (const f of files) {
  if (BAD_EXT.test(f)) {
    console.log(`[TYPE] ${path.relative(ROOT, f)}`);
    problems++;
  }
}

// 2. Sensitive terms in source files (skip meta-documentation)
for (const f of files) {
  const rel = path.relative(ROOT, f).replace(/\\/g, "/");
  if (META_FILES.has(rel)) continue;
  const ext = path.extname(f).toLowerCase();
  if (![".ts", ".tsx", ".js", ".json", ".md", ".html", ".css", ".txt"].includes(ext)) continue;
  const content = fs.readFileSync(f, "utf8");
  for (const term of BAD_TERMS) {
    if (content.includes(term)) {
      console.log(`[TERM "${term}"] ${rel}`);
      problems++;
    }
  }
}

console.log("\n" + (problems === 0 ? "OK — no sensitive content found." : `Found ${problems} potential issue(s).`));
process.exit(problems === 0 ? 0 : 1);
